CREATE DATABASE dbPAGTMS
go
USE dbPAGTMS
create table tbCustomer( 
CusID int primary key not null, 
CusName varchar(20) not null, 
CusAge smallint not null, 
CusGender varchar(7) not null, 
CusContactInfo varchar(20) not null
) 
go 
create table tbStaff( 
StaffID int primary key not null,  
StaffNameKH nvarchar (30) Collate  
SQL_Latin1_General_CP850_Bin not null,  
StaffNameEN varchar (30) not null,  
Gender varchar (7) not null,  
BirthDate date not null,  
StaffPosition varchar (50) not null,  
HouseNo varchar (50) not null, 
StreetNo varchar (50)not null, 
Sangkat varchar (50)not null, 
Khann varchar (50)not null, 
Province varchar(50)not null, 
ContactNumber varchar(50)not null, 
PersonalNumber varchar(50)not null, 
Salary money not null,  
HiredDate date not null, 
Photo varbinary(max), 
StopWork bit 
) 
go 
create table tbRoute( 
RouteID int primary key not null,  
Origin varchar(50) not null, 
Destination varchar(50) not null, 
Distance varchar(50) not null
) 
go 
create table tbVehicle( 
VehicleID int primary key not null,  
VType varchar(50) not null,  
Capacity varchar(50) not null, 
Lincense_Plate varchar (50) not null,  
VStatus varchar(50) 
) 
go
create table tbBooking( 
BookingID int primary key not null, 
BookingDate date not null, 
TotalPaid money not null, 
CusID int,CusName varchar(20),CusContactInfo varchar(20),
RouteID int,Destination varchar(50), 
VehicleID int,VType varchar(50),VStatus varchar(50), 
StaffID int,StaffNameKh nvarchar(50),StaffPosition varchar(100), 
constraint FK_CusID_tbBooking foreign key(CusID) references tbCustomer(CusID)  
on delete cascade on update cascade,
constraint FK_RouteID_tbBooking foreign key(RouteID) references tbRoute(RouteID) 
on delete cascade on update cascade, 
constraint FK_VehicleID_tbBooking foreign key(VehicleID) references tbVehicle(VehicleID) 
on delete cascade on update cascade,
constraint FK_StaffID_tbBooking foreign key(StaffID) references tbStaff(StaffID) 
on delete cascade on update cascade
)
go 
create table tbTicket( 
TicketID INT PRIMARY KEY not null, 
SeatNumber Varchar(25) not null, 
Price MONEY not null, 
TDate DATE, 
CusID INT,CusContactInfo varchar(20), 
StaffID INT, StaffPosition varchar(100), 
constraint FK_CusID_tbTicket foreign key(CusID) references tbCustomer(CusID) 
on delete cascade on update cascade, 
constraint FK_StaffID_tbTicket foreign key(StaffID) references tbStaff(StaffID) 
on delete cascade on update cascade, 
) 
go 
create table tbTransport( 
TransportID int primary key not null, 
TransportDate date , 
TStatus varchar(50) , 
CusID int,CusContactInfo varchar(20),
RouteID int,Destination varchar(50), 
StaffID int,StaffPosition varchar(100),   
constraint FK_CusID_tbTransport foreign key(CusID) references tbCustomer(CusID)  
on delete cascade on update cascade, 
constraint FK_Route_tbTransport foreign key(RouteID) references tbRoute(RouteID) 
on delete cascade on update cascade,
constraint FK_StaffID_tbTransport foreign key(StaffID) references tbStaff(StaffID) 
on delete cascade on update cascade    
) 
go 
create table tbItem( 
ItemID int primary key not null, 
Category varchar(50) , 
IDescription varchar(50) , 
IWeight varchar(10), 
CusID int,CusName varchar(50),CusContactInfo varchar(20), 
TransportID int,TransportDate date, 
constraint FK_CusID_tbItem foreign key(CusID) references tbCustomer(CusID) 
on delete cascade on update cascade, 
constraint FK_TransportID_tbItem foreign key(TransportID) references tbTransport(TransportID)
on delete no action on update no action 
)
go   
create table tbPayment( 
PaymentID INT PRIMARY KEY, 
PayDate DATE, 
PaidAmount money , 
CusID INT , CusName varchar(50), CusContactInfo varchar(20),
StaffID INT, StaffNameKh nvarchar(50), StaffPosition varchar(50),  
constraint FK_CusID_tbPayment foreign key(CusID) references tbCustomer(CusID) 
on delete cascade on update cascade, 
constraint FK_StaffID_tbPayment foreign key(StaffID) references tbStaff(StaffID) 
on delete cascade on update cascade 
) 
go 
create table tbInvoice( 
InvoiceID INT PRIMARY KEY not null, 
InvoiceDate DATE NOT NULL,
TotalAmount money NOT NULL,
PaidAmount money NOT NULL, 
CusID INT NOT NULL, CusName varchar(50), CusContactInfo varchar(20),
StaffID INT NOT NULL, StaffNameKh nvarchar(50), StaffPosition varchar(50),  
constraint FK_CusID_tbInvoice foreign key(CusID) references tbCustomer(CusID) on delete cascade on update cascade, 
constraint FK_StaffID_tbInvoice foreign key(StaffID) references tbStaff(StaffID) on delete cascade on update cascade 
) 

go  
create table tbUser(
UserID int primary key not null, 
UserName varchar(20), 
UserPassword varchar(20), 
StaffID INT NOT NULL, StaffNameKh nvarchar(50), StaffPosition varchar(100), 
constraint FK_StaffID_tbUser foreign key(StaffID) references tbStaff(StaffID) 
on delete cascade on update cascade 
)
