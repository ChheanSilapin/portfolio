CREATE PROCEDURE spReadALLStaff  
AS 
BEGIN 
	SELECT  StaffID,StaffNameKH FROM tbStaff
END;
GO
-- Read One Staff
CREATE PROCEDURE spReadOneStaff ( @sid INT ) 
AS 
BEGIN 
	SELECT TOP 1 * FROM tbStaff WHERE StaffID = @sid
END;
GO

-- Insert Staff
CREATE PROCEDURE spInsertStaff ( @sid INT, @snKH NVARCHAR (100), @snEN VARCHAR (100), 
@gen VARCHAR (6), @bd DATE, @pos VARCHAR (100), @hn VARCHAR (50), @sn varchar(50),
@sk varchar (50),@khn varchar (50),@pro varchar(50),
@cn VARCHAR (10), @pn VARCHAR (10) =  NULL, @sa money ,@hd DATE, @ph VARBINARY (max) = NULL ,@spw bit) 
AS 
BEGIN 
	INSERT INTO tbStaff VALUES  ( @sid, @snKH, @snEN, @gen, @bd, @pos, @hn, @sn,@sk,@khn,@pro,
	@cn, @pn,@sa, @hd, @ph ,@spw)
END;
GO

-- Update Staff
CREATE PROCEDURE spUpdateStaff ( @sid INT, @snKH NVARCHAR (100), @snEN VARCHAR (100), 
@gen VARCHAR (6), @bd DATE, @pos VARCHAR (100), @hn VARCHAR (50), @sn varchar(50),
@sk varchar (50),@khn varchar (50),@pro varchar(50),
@cn VARCHAR (10), @pn VARCHAR (10) =  NULL,@sa money ,@hd DATE, @ph VARBINARY (max) = NULL ,@spw bit )
AS 
BEGIN 
	
	UPDATE tbStaff SET  
		StaffNameKH = @snKH, 
		StaffNameEN = @snEN,
		Gender = @gen, 
		BirthDate = @bd, 
		StaffPosition = @pos, 
		HouseNo= @hn,
		StreetNo = @sn,
		Sangkat = @sk,
		Khann = @khn,
		Province = @pro,
		ContactNumber = @cn, 
		PersonalNumber = @pn, 
		Salary = @sa,
		HiredDate = @hd, 
		Photo = @ph, 
		StopWork = @spw
		WHERE StaffID = @sid
END;
go 
--Read all Customer
create proc spReadAllCustomer
as 
Begin
Select CusID,CusName from tbCustomer
end;
go
--Read one Customer
create proc spReadOneCustomer(@cid int)
as 
Begin
select top 1* From tbCustomer where CusID = @cid
end;
go
--Insert Customer
create proc spInsertCustomer(@cid int,@cn varchar(50),@ca smallint,@cg varchar(7),
@cci varchar(20))
as 
begin 
insert into tbCustomer values(@cid,@cn,@ca,@cg,@cci)
end;
go
--Update Customer
create proc spUpdateCustomer(@cid int,@cn varchar(50),@ca smallint,@cg varchar(7),
@cci varchar(20))
as 
begin 
update tbCustomer set 
CusName =@cn,
CusAge=@ca,
CusGender=@cg,
CusContactInfo = @cci
where CusID =@cid
end;
go

--Read all Vehicle
create proc spReadAllVehicle
as 
Begin
Select * from tbVehicle
end;
go
--Read one Vehicle
create proc spReadOneVehicle(@vid int)
as 
Begin
select top 1* From tbVehicle where VehicleID = @vid
end;
go
--Insert Vehicle
create proc spInsertVehicle(@vid int,@vt varchar(50),@cp varchar(50),
@lp varchar(50),@vs varchar(50))
as 
begin 
insert into tbVehicle values(@vid,@vt,@cp,@lp,@vs)
end;
go
--Update Vehicle
create proc spUpdateVehicle(@vid int,@vt varchar(50),@cp varchar(50),
@lp varchar(50),@vs varchar(50))
as 
begin 
update tbVehicle set 
VType = @vt,
Capacity = @cp,
Lincense_Plate =@lp,
VStatus= @vs
where VehicleID =@vid
end;
go

--Read all Route
create proc spReadAllRoute
as 
Begin
Select * from tbRoute
end;
go
--Read one Route
create proc spReadOneRoute(@rid int)
as 
Begin
select top 1* From tbRoute where RouteID = @rid
end;
go
--Insert Route
create proc spInsertRoute(@rid int,@ori varchar(50),@des varchar(50),
@dis varchar(50))
as 
begin 
insert into tbRoute values(@rid,@ori,@des,@dis)
end;
go
--Update Route
create proc spUpdateRoute(@rid int,@ori varchar(50),@des varchar(50),
@dis varchar(50))
as 
begin 
update tbRoute set 
Origin= @ori,
Destination = @des,
Distance =@dis
where RouteID =@rid
end;
go
--Read all Booking
CREATE PROCEDURE spReadALLBooking
AS 
BEGIN 
	SELECT * FROM tbBooking
END;
go
-- Read One Booking
CREATE PROCEDURE spReadOneBooking ( @bookingid INT ) 
AS 
BEGIN 
	SELECT TOP 1 * FROM tbBooking WHERE BookingID = @bookingid
END;
go
-- Insert booking
CREATE PROCEDURE spInsertBooking ( @bookingid int,@bookingdate date,@totalpaid money,
@cusid int,@cusname varchar(50),@cusinfo varchar(20),
@routeid int, @des varchar(20),
@vehicleid int, @vehicletype varchar(50),@vehiclestatus varchar(50),
@stid INT, @stkh NVARCHAR (50), @stpos VARCHAR (100)) 
AS 
BEGIN 
	INSERT INTO tbBooking VALUES  (@bookingid,@bookingdate,@totalpaid,
	@cusid,@cusname,@cusinfo,
	@routeid,@des,
	@vehicleid,@vehicletype,@vehiclestatus,
	@stid,@stkh,@stpos);
	
END;
go
-- Update Booking
Create PROCEDURE spUpdateBooking ( @bookingid int,@bookingdate date,@totalpaid money,
@cusid int,@cusname varchar(50),@cusinfo varchar(20),
@routeid int, @des varchar(20),
@vehicleid int, @vehicletype varchar(50),@vehiclestatus varchar(50),
@stid INT, @stkh NVARCHAR (50), @stpos VARCHAR (100)) 
AS 
BEGIN 
	UPDATE tbBooking SET
		 BookingDate = @bookingdate,
		 TotalPaid = @totalpaid,
		 CusID = @cusid,
		 CusName = @cusname,
		 CusContactInfo =@cusinfo,
		 RouteID = @routeid,
		 Destination=@des,
		 VehicleID =@vehicleid,
		 VType = @vehicletype,
		 VStatus = @vehiclestatus,
		 StaffID = @stid,
		 StaffNameKh = @stkh,
		 StaffPosition = @stpos
		WHERE BookingID = @bookingid
END;
GO
--Read all Ticket
CREATE PROCEDURE spReadALLTicket
AS 
BEGIN 
	SELECT * FROM tbTicket
END;
go
-- Read One Ticket
CREATE PROCEDURE spReadOneTicket ( @ticketid INT ) 
AS 
BEGIN 
	SELECT TOP 1 * FROM tbTicket WHERE TicketID = @ticketid
END;
go
-- Insert Ticket
CREATE PROCEDURE spInsertTicket (@ticketid int,@seatnum varchar(25),
@price money,@ticketdate date,
@cusid int,@cusinfo varchar(20),
@stid INT,@stpos VARCHAR (100)) 
AS 
BEGIN 
	INSERT INTO tbTicket VALUES ( @ticketid,@seatnum,@price,@ticketdate,
	@cusid,@cusinfo,
	@stid,@stpos)
	
END;
go
-- Update Ticket
Create PROCEDURE spUpdateTicket (@ticketid int,@seatnum varchar(50),
@price money,@ticketdate date,
@cusid int,@cusinfo varchar(20),
@stid INT,@stpos VARCHAR (100)) 
AS 
BEGIN 
	UPDATE tbTicket SET
		 SeatNumber =@seatnum,
		 Price =@price,
		 TDate = @ticketdate,
		 CusID = @cusid,
		 CusContactInfo =@cusinfo,
		 StaffID = @stid,
		 StaffPosition = @stpos
		WHERE TicketID = @ticketid
END;
GO
--Read all Transport
CREATE PROCEDURE spReadALLTransport
AS
BEGIN 
	SELECT * FROM tbTransport
END;
go
--Read one Transport
CREATE PROCEDURE spReadOneTransport(@tranid INT)
AS 
BEGIN
	SELECT TOP 1 * FROM tbTransport WHERE TransportID = @tranid
END;
go
--Insert Transport
CREATE PROCEDURE spInsertTransport(@tranid INT,@trandate date,@transtatus varchar(50),
@cusid INT,@cusinfo varchar(20),@routeid int,@rdes varchar(50),
@stid int,@stpos varchar(20))
AS
BEGIN
	INSERT INTO tbTransport VALUES(@tranid,@trandate,@transtatus,@cusid,@cusinfo,@routeid,@rdes,@stid,@stpos)
END;
go
--Update Transport
CREATE PROCEDURE spUpdateTransport(@tranid INT,@trandate date,@transtatus varchar(50),
@cusid INT,@cusinfo varchar(20),@routeid int,@rdes varchar(50),
@stid int,@stpos varchar(20))
AS
BEGIN
	UPDATE tbTransport SET
		TransportDate = @trandate,
		TStatus = @transtatus,
		CusID = @cusid,
		CusContactInfo = @cusinfo,
		RouteID = @routeid,
		Destination = @rdes,
		StaffID = @stid,
		StaffPosition = @stpos
		WHERE TransportID = @tranid
END;
go
-- insert Item
CREATE PROCEDURE spInsertItem(@itid INT ,@cate VARCHAR(50),@des VARCHAR(50) ,@wei varchar(10),@cusid INT ,@cusna varchar(50),@cusco varchar(20),@tid INT ,@td varchar(50))
AS
BEGIN
	INSERT INTO tbItem VALUES(@itid,@cate,@des,@wei,@cusid,@cusna,@cusco,@tid,@td)
END;
go
-- Read all Item
CREATE PROCEDURE spReadALLItem
AS
BEGIN 
	SELECT * FROM tbItem
END;
go
--Read one Item
CREATE PROCEDURE spReadOneItem(@itid INT)
AS 
BEGIN
	SELECT TOP 1 * FROM tbItem WHERE ItemID = @itid
END;
go
--update Item
CREATE PROCEDURE spUpdateItem(@itid INT ,@cate VARCHAR(50),@des VARCHAR(50) ,@wei varchar(10),@cusid INT ,@cusna varchar(50),@cusco varchar(20),@tid INT ,@td varchar(50))
AS
BEGIN
	UPDATE tbItem SET
		Category = @cate,
		IDescription = @des,
		IWeight = @wei,
		CusID = @cusid,
		CusName =@cusna,
		CusContactInfo = @cusco,
		TransportID = @tid,
		TransportDate = @td
		WHERE ItemID = @itid
END;
GO
-- Read all Payment
CREATE PROCEDURE spReadALLPayment  
AS 
BEGIN 
	SELECT PaymentID,CusName FROM tbPayment
END;
GO
-- Read One Payment
CREATE PROCEDURE spReadOnePayment ( @pid INT ) 
AS 
BEGIN 
	SELECT TOP 1 * FROM tbPayment WHERE PaymentID = @pid
END;
GO
-- Insert Payment
CREATE PROCEDURE spInsertPayment ( @pid int,@pdate date,@paidamount money,
@cusid int,@cusname varchar(50),@cusinfo varchar(20),
@stid INT, @stkh NVARCHAR (50), @stpos VARCHAR (100)) 
AS 
BEGIN 
	INSERT INTO tbPayment VALUES  (@pid,@pdate,@paidamount,@cusid,@cusname,@cusinfo,@stid,@stkh,@stpos);
END;
GO
-- Update Payment
Create PROCEDURE spUpdatePayment ( @pid int,@pdate date,@paidamount money,
@cusid int,@cusname varchar(50),@cusinfo varchar(20),
@stid INT, @stkh NVARCHAR (50), @stpos VARCHAR (100)) 
AS 
BEGIN 
	UPDATE tbPayment SET
		 PayDate =@pdate,
		 PaidAmount = @paidamount,
		 CusID = @cusid,
		 CusName = @cusname,
		 CusContactInfo =@cusinfo,
		 StaffID = @stid,
		 StaffNameKh = @stkh,
		 StaffPosition = @stpos
		WHERE PaymentID = @pid
END;
GO
--Read all Invoice
CREATE PROCEDURE spReadALLInvoice  
AS 
BEGIN 
	SELECT InvoiceID,CusName FROM tbInvoice
END;
GO
-- Read One Invoice
CREATE PROCEDURE spReadOneInvoice ( @iid INT ) 
AS 
BEGIN 
	SELECT TOP 1 * FROM tbInvoice WHERE InvoiceID = @iid
END;
GO
-- Insert Invoice
CREATE PROCEDURE spInsertInvoice ( @iid int,@idate date,@totalamount money,@paidamount money,
@cusid int,@cusname varchar(50),@cusinfo varchar(20),
@stid INT, @stkh NVARCHAR (50), @stpos VARCHAR (100)) 
AS 
BEGIN 
	INSERT INTO tbInvoice VALUES  (@iid,@idate,@totalamount,@paidamount,@cusid,@cusname,@cusinfo,@stid,@stkh,@stpos)
END;
GO

-- Update Invoice
CREATE PROCEDURE spUpdateInvoice ( @iid int,@idate date,@totalamount money,@paidamount money,
@cusid int,@cusname varchar(50),@cusinfo varchar(20),
@stid INT, @stkh NVARCHAR (50), @stpos VARCHAR (100))
AS 
BEGIN 
	
	UPDATE tbInvoice SET
		 InvoiceDate =@idate,
		 TotalAmount = @totalamount,
		 PaidAmount = @paidamount,
		 CusID = @cusid,
		 CusName = @cusname,
		 CusContactInfo =@cusinfo,
		 StaffID = @stid,
		 StaffNameKh = @stkh,
		 StaffPosition = @stpos
		WHERE InvoiceID = @iid
END;
go 
--Read all User
CREATE PROCEDURE spReadALLUser  
AS 
BEGIN 
	SELECT UserID,UserName FROM tbUser
END;
GO
-- Read One User
CREATE PROCEDURE spReadOneUser ( @uid INT ) 
AS 
BEGIN 
	SELECT TOP 1 * FROM tbUser WHERE UserID = @uid
END;
GO

-- Insert User
CREATE PROCEDURE spInsertUser ( @uid int,@uname varchar(20),@upass varchar(20) ,@stid INT, 
@stkh NVARCHAR (100), @stpos VARCHAR (100)) 
AS 
BEGIN 
	INSERT INTO tbUser VALUES  (@uid,@uname,@upass,@stid,@stkh,@stpos)
END;
GO

-- Update User
CREATE PROCEDURE spUpdateUser ( @uid int,@uname varchar(20),@upass varchar(20) ,@stid INT, 
@stkh NVARCHAR (100), @stpos VARCHAR (100))
AS 
BEGIN 
	
	UPDATE tbUser SET
		UserName = @uname,
		UserPassword = @upass,
		StaffID = @stid, 
		StaffNameKh = @stkh, 
		StaffPosition = @stpos 
		WHERE UserID = @uid
END;
go
CREATE PROCEDURE spLoginUser(@name VARCHAR(50), @password VARCHAR(50))
  AS
  BEGIN
    select UserName,UserPassword from tbUser
     WHERE UserName COLLATE Latin1_General_BIN = @name 
      AND UserPassword COLLATE Latin1_General_BIN = @password;
  END;
