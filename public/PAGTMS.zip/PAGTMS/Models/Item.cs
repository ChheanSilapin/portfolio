﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAGTMS.Models
{
    public class Item
    {
        public int ItemID { get; set; }
        public string? Category { get; set; }
        public string? Description { get; set; }
        public string? Weight { get; set; }
        public int CustomerID { get; set; }
        public string? CustomerName { get; set; }
        public string? CustomerContact { get; set; }
        public int TransportID { get; set; }
        public DateTime? TransportDate { get; set; }
        //public string? CustomerAge { get; internal set; }
    }
}
