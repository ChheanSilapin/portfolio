﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAGTMS.Models;

public class User
{
    public int UserID { get; set; }
    public string? Username { get; set; }
    public string? UserPassword { get; set; }
    public int StaffID { get; set; }
    public string? StaffNameKh { get; set; }
    public string? StaffPosition { get; set; }
}
