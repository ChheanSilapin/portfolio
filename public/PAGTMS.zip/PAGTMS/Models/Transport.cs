﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAGTMS.Models;

public class Transport
{
    public int TransportID { get; set; }
    public DateTime TransportDate { get; set; }
    public string? TransportStatus { get; set; }
    //public string? TransportType { get; set;}
    public int CustomerID { get; set; }
    public string? CustomerContactInfo { get; set; }
    public int RouteID { get; set; }
    public string? Destination {  get; set; }
    public int StaffID { get; set; }
    public string? StaffPosition { get; set; }
}
