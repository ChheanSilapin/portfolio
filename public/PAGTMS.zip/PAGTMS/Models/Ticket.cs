﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAGTMS.Models;

public class Ticket
{
    public int TicketID { get; set; }
    public string? SeatNum { get; set; }
    public decimal? Price { get; set; }
    public DateTime TicketDate{ get; set; }
    public int CustomerID {  get; set; }
    public string? CusContactInfo { get;set; }
    public int StaffID { get; set; }
    public string? StaffPosition { get; set; }
    //public int BookingID {  get; set; }
    
}
