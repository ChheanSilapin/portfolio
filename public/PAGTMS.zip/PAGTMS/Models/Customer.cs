﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAGTMS.Models;

public class Customer
{
    public int CustomerID { get; set; }
    public string? CustomerName { get; set; }
    public string? Gender { get; set; }
    public Int16? CusAge { get; set; }
    public string? CustomerContactInfo { get; set; }
}
