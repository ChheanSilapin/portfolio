﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAGTMS.Models;

public class Booking
{
    public int BookingID { get; set; }
    public DateTime BookingDate { get; set; }
    public decimal? TotalPaid  { get; set; }
    public int CustomerID { get; set; }
    public string? CustomerName { get; set; }
    public string? CustomerContactInfo { get; set; }
    public int RouteID { get; set; }
    public string? Destination { get; set; }
    public int VehicleID { get; set; }
    public string? VehicleType { get; set; }
    public string? VehicleStatus { get; set; }
    public int StaffID { get; set; }
    public string? StaffNameKh { get; set; }
    public string? StaffPosition { get; set; }
    
}
