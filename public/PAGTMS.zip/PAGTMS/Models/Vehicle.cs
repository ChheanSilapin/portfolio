﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAGTMS.Models;

public class Vehicle
{
    public int VehicleID { get; set; }
    public string? VehicleType { get; set; }
    public string? Capacity { get; set; }
    public string? LincensePlate {  get; set; }
    public string? VehicleStatus { get; set;}

}
