﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAGTMS.Models;

public class Payment
{
    public int PaymentID { get; set; }
    public DateTime PayDate { get; set; }
    public decimal? PaidAmount { get; set; }
    public int CustomerID {  get; set; }
    public string? CustomerName { get; set; }
    public string? CustomerContactInfo { get; set; }
    public int StaffID { get; set; }
    public string? StaffNameKh { get; set; }
    public string? StaffPosition { get; set; }
}
