using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using PAGTMS.Models;
using PAGTMS.Ultils;
using System.Runtime.CompilerServices;

namespace PAGTMS;

internal static class Program
{
    /// <summary>
    ///  The main entry point for the application.
    /// </summary>
    /// 
    public static SqlConnection Connection = default!;
    [STAThread]

    static void Main()
    {
        // To customize application configuration such as set high DPI settings or default font,
        // see https://aka.ms/applicationconfiguration.
        
        ApplicationConfiguration.Initialize();
        DatabaseConfigurationForm databaseConfigurationForm = new DatabaseConfigurationForm();

        if (File.Exists($"{Environment.CurrentDirectory}/appSettings.json"))
        {
            Application.Run(new LoginForm(databaseConfigurationForm));
        }
        else
        {
            Application.Run(new DatabaseConfigurationForm());
        }
    }


    public static void ConnectToDB()
    {
        Helper.ConnectionStringKey = "DBConnectionString";
        try
        {
            Helper.LoadConfiguration("appSettings.json");
            Connection = Helper.OpenConnection();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Connecting", MessageBoxButtons.OK, MessageBoxIcon.Error);
            Environment.Exit(0);
        }
    }
    
}
