﻿namespace PAGTMS
{
    partial class TicketForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TicketForm));
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            btnLogOut = new Button();
            btnClear = new Button();
            btnUpdate = new Button();
            btnInsert = new Button();
            txtTicketID = new TextBox();
            txtSeatNum = new TextBox();
            txtCusInfo = new TextBox();
            txtStpos = new TextBox();
            label9 = new Label();
            dtTicketdate = new DateTimePicker();
            cbStaffID = new ComboBox();
            iconPictureBox1 = new FontAwesome.Sharp.IconPictureBox();
            pictureBox1 = new PictureBox();
            label10 = new Label();
            label11 = new Label();
            panel2 = new Panel();
            pictureBox2 = new PictureBox();
            label13 = new Label();
            label12 = new Label();
            iconPictureBox2 = new FontAwesome.Sharp.IconPictureBox();
            cbCustomerID = new ComboBox();
            pictureBox3 = new PictureBox();
            btnBack = new Button();
            txtSearch = new TextBox();
            txtPrice = new TextBox();
            dvgTicket = new DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            Column4 = new DataGridViewTextBoxColumn();
            Column5 = new DataGridViewTextBoxColumn();
            Column6 = new DataGridViewTextBoxColumn();
            Column7 = new DataGridViewTextBoxColumn();
            Column8 = new DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dvgTicket).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(12, 343);
            label1.Name = "label1";
            label1.Size = new Size(127, 19);
            label1.TabIndex = 0;
            label1.Text = "Search TicketID :";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(341, 93);
            label2.Name = "label2";
            label2.Size = new Size(77, 19);
            label2.TabIndex = 0;
            label2.Text = "TicketID :\r\n";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(341, 126);
            label3.Name = "label3";
            label3.Size = new Size(106, 19);
            label3.TabIndex = 0;
            label3.Text = "Seat Number :";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(343, 159);
            label4.Name = "label4";
            label4.Size = new Size(55, 19);
            label4.TabIndex = 0;
            label4.Text = "Price :";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(343, 225);
            label5.Name = "label5";
            label5.Size = new Size(106, 19);
            label5.TabIndex = 0;
            label5.Text = "Customer ID :";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(341, 258);
            label6.Name = "label6";
            label6.Size = new Size(142, 19);
            label6.TabIndex = 0;
            label6.Text = "Customer Contact :";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label7.Location = new Point(343, 291);
            label7.Name = "label7";
            label7.Size = new Size(72, 19);
            label7.TabIndex = 0;
            label7.Text = "Staff ID :";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label8.Location = new Point(341, 322);
            label8.Name = "label8";
            label8.Size = new Size(113, 19);
            label8.TabIndex = 0;
            label8.Text = "Staff Position :";
            // 
            // btnLogOut
            // 
            btnLogOut.BackColor = Color.FromArgb(128, 255, 255);
            btnLogOut.BackgroundImageLayout = ImageLayout.Center;
            btnLogOut.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnLogOut.ForeColor = SystemColors.ActiveCaptionText;
            btnLogOut.Location = new Point(736, 367);
            btnLogOut.Name = "btnLogOut";
            btnLogOut.Size = new Size(94, 32);
            btnLogOut.TabIndex = 3;
            btnLogOut.Text = "Log Out\r\n";
            btnLogOut.UseVisualStyleBackColor = false;
            // 
            // btnClear
            // 
            btnClear.BackColor = Color.FromArgb(128, 255, 255);
            btnClear.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnClear.Location = new Point(521, 367);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(94, 32);
            btnClear.TabIndex = 3;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = false;
            // 
            // btnUpdate
            // 
            btnUpdate.BackColor = Color.FromArgb(128, 255, 255);
            btnUpdate.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnUpdate.Location = new Point(401, 366);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(94, 32);
            btnUpdate.TabIndex = 3;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = false;
            // 
            // btnInsert
            // 
            btnInsert.BackColor = Color.FromArgb(128, 255, 255);
            btnInsert.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnInsert.Location = new Point(292, 365);
            btnInsert.Name = "btnInsert";
            btnInsert.Size = new Size(94, 32);
            btnInsert.TabIndex = 3;
            btnInsert.Text = "Insert";
            btnInsert.UseVisualStyleBackColor = false;
            // 
            // txtTicketID
            // 
            txtTicketID.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtTicketID.Location = new Point(502, 83);
            txtTicketID.Name = "txtTicketID";
            txtTicketID.Size = new Size(254, 27);
            txtTicketID.TabIndex = 4;
            // 
            // txtSeatNum
            // 
            txtSeatNum.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtSeatNum.Location = new Point(502, 116);
            txtSeatNum.Name = "txtSeatNum";
            txtSeatNum.Size = new Size(254, 27);
            txtSeatNum.TabIndex = 4;
            // 
            // txtCusInfo
            // 
            txtCusInfo.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtCusInfo.Location = new Point(502, 248);
            txtCusInfo.Name = "txtCusInfo";
            txtCusInfo.ReadOnly = true;
            txtCusInfo.Size = new Size(254, 27);
            txtCusInfo.TabIndex = 4;
            // 
            // txtStpos
            // 
            txtStpos.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtStpos.Location = new Point(502, 312);
            txtStpos.Name = "txtStpos";
            txtStpos.ReadOnly = true;
            txtStpos.Size = new Size(254, 27);
            txtStpos.TabIndex = 4;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label9.Location = new Point(343, 192);
            label9.Name = "label9";
            label9.Size = new Size(96, 19);
            label9.TabIndex = 0;
            label9.Text = "Ticket Date :";
            // 
            // dtTicketdate
            // 
            dtTicketdate.CustomFormat = "MM/dd/yyyy";
            dtTicketdate.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            dtTicketdate.Location = new Point(502, 182);
            dtTicketdate.Name = "dtTicketdate";
            dtTicketdate.Size = new Size(254, 27);
            dtTicketdate.TabIndex = 5;
            // 
            // cbStaffID
            // 
            cbStaffID.DropDownStyle = ComboBoxStyle.DropDownList;
            cbStaffID.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            cbStaffID.FormattingEnabled = true;
            cbStaffID.Location = new Point(502, 281);
            cbStaffID.Name = "cbStaffID";
            cbStaffID.Size = new Size(254, 27);
            cbStaffID.TabIndex = 6;
            // 
            // iconPictureBox1
            // 
            iconPictureBox1.BackColor = Color.FromArgb(255, 255, 128);
            iconPictureBox1.ForeColor = SystemColors.ControlText;
            iconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.Copyright;
            iconPictureBox1.IconColor = SystemColors.ControlText;
            iconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox1.IconSize = 25;
            iconPictureBox1.Location = new Point(141, 47);
            iconPictureBox1.Name = "iconPictureBox1";
            iconPictureBox1.Size = new Size(25, 26);
            iconPictureBox1.TabIndex = 7;
            iconPictureBox1.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(3, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(132, 73);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(172, 52);
            label10.Name = "label10";
            label10.Size = new Size(238, 17);
            label10.TabIndex = 9;
            label10.Text = "Copyright ISAD_M3_25_Group(Roza)";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Times New Roman", 20F, FontStyle.Regular, GraphicsUnit.Point);
            label11.Location = new Point(186, 3);
            label11.Name = "label11";
            label11.Size = new Size(202, 39);
            label11.TabIndex = 9;
            label11.Text = "Ticket's Form";
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(255, 255, 128);
            panel2.Controls.Add(pictureBox2);
            panel2.Controls.Add(label13);
            panel2.Controls.Add(label12);
            panel2.Controls.Add(iconPictureBox2);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(854, 76);
            panel2.TabIndex = 7;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(0, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(153, 76);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 3;
            pictureBox2.TabStop = false;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Times New Roman", 20F, FontStyle.Regular, GraphicsUnit.Point);
            label13.Location = new Point(195, 9);
            label13.Name = "label13";
            label13.Size = new Size(202, 39);
            label13.TabIndex = 2;
            label13.Text = "Ticket's Form";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(195, 56);
            label12.Name = "label12";
            label12.Size = new Size(223, 17);
            label12.TabIndex = 2;
            label12.Text = "Copyright ISAD_M3_Group5(Roza)";
            // 
            // iconPictureBox2
            // 
            iconPictureBox2.BackColor = Color.FromArgb(255, 255, 128);
            iconPictureBox2.ForeColor = SystemColors.ControlText;
            iconPictureBox2.IconChar = FontAwesome.Sharp.IconChar.Copyright;
            iconPictureBox2.IconColor = SystemColors.ControlText;
            iconPictureBox2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox2.IconSize = 23;
            iconPictureBox2.Location = new Point(159, 50);
            iconPictureBox2.Name = "iconPictureBox2";
            iconPictureBox2.Size = new Size(30, 23);
            iconPictureBox2.TabIndex = 1;
            iconPictureBox2.TabStop = false;
            // 
            // cbCustomerID
            // 
            cbCustomerID.DropDownStyle = ComboBoxStyle.DropDownList;
            cbCustomerID.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            cbCustomerID.FormattingEnabled = true;
            cbCustomerID.Location = new Point(502, 215);
            cbCustomerID.Name = "cbCustomerID";
            cbCustomerID.Size = new Size(254, 27);
            cbCustomerID.TabIndex = 8;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(12, 110);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(293, 192);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 11;
            pictureBox3.TabStop = false;
            // 
            // btnBack
            // 
            btnBack.BackColor = Color.FromArgb(128, 255, 255);
            btnBack.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnBack.Location = new Point(636, 367);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(94, 32);
            btnBack.TabIndex = 12;
            btnBack.Text = "Back";
            btnBack.UseVisualStyleBackColor = false;
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(12, 372);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(260, 25);
            txtSearch.TabIndex = 13;
            // 
            // txtPrice
            // 
            txtPrice.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtPrice.Location = new Point(502, 149);
            txtPrice.Name = "txtPrice";
            txtPrice.Size = new Size(254, 27);
            txtPrice.TabIndex = 14;
            // 
            // dvgTicket
            // 
            dvgTicket.AllowUserToAddRows = false;
            dvgTicket.AllowUserToDeleteRows = false;
            dvgTicket.BackgroundColor = SystemColors.ButtonHighlight;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dvgTicket.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dvgTicket.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dvgTicket.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column3, Column4, Column5, Column6, Column7, Column8 });
            dvgTicket.Location = new Point(12, 413);
            dvgTicket.Name = "dvgTicket";
            dvgTicket.ReadOnly = true;
            dvgTicket.RowHeadersWidth = 51;
            dvgTicket.RowTemplate.Height = 29;
            dvgTicket.Size = new Size(818, 134);
            dvgTicket.TabIndex = 45;
            // 
            // Column1
            // 
            Column1.HeaderText = "TicketID";
            Column1.MinimumWidth = 6;
            Column1.Name = "Column1";
            Column1.ReadOnly = true;
            Column1.Width = 125;
            // 
            // Column2
            // 
            Column2.HeaderText = "SeatNumber";
            Column2.MinimumWidth = 6;
            Column2.Name = "Column2";
            Column2.ReadOnly = true;
            Column2.Width = 125;
            // 
            // Column3
            // 
            Column3.HeaderText = "Price";
            Column3.MinimumWidth = 6;
            Column3.Name = "Column3";
            Column3.ReadOnly = true;
            Column3.Width = 125;
            // 
            // Column4
            // 
            dataGridViewCellStyle2.Format = "d";
            dataGridViewCellStyle2.NullValue = null;
            Column4.DefaultCellStyle = dataGridViewCellStyle2;
            Column4.HeaderText = "TickeDate";
            Column4.MinimumWidth = 6;
            Column4.Name = "Column4";
            Column4.ReadOnly = true;
            Column4.Width = 125;
            // 
            // Column5
            // 
            Column5.HeaderText = "CustomerID";
            Column5.MinimumWidth = 6;
            Column5.Name = "Column5";
            Column5.ReadOnly = true;
            Column5.Width = 125;
            // 
            // Column6
            // 
            Column6.HeaderText = "CustomerContactInfo";
            Column6.MinimumWidth = 6;
            Column6.Name = "Column6";
            Column6.ReadOnly = true;
            Column6.Width = 125;
            // 
            // Column7
            // 
            Column7.HeaderText = "StaffID";
            Column7.MinimumWidth = 6;
            Column7.Name = "Column7";
            Column7.ReadOnly = true;
            Column7.Width = 125;
            // 
            // Column8
            // 
            Column8.HeaderText = "StaffPosition";
            Column8.MinimumWidth = 6;
            Column8.Name = "Column8";
            Column8.ReadOnly = true;
            Column8.Width = 125;
            // 
            // TicketForm
            // 
            AutoScaleDimensions = new SizeF(8F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(854, 561);
            Controls.Add(dvgTicket);
            Controls.Add(txtPrice);
            Controls.Add(txtSearch);
            Controls.Add(btnBack);
            Controls.Add(pictureBox3);
            Controls.Add(cbCustomerID);
            Controls.Add(panel2);
            Controls.Add(cbStaffID);
            Controls.Add(dtTicketdate);
            Controls.Add(txtStpos);
            Controls.Add(txtCusInfo);
            Controls.Add(txtSeatNum);
            Controls.Add(txtTicketID);
            Controls.Add(btnInsert);
            Controls.Add(btnUpdate);
            Controls.Add(btnClear);
            Controls.Add(btnLogOut);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label9);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Times New Roman", 9F, FontStyle.Regular, GraphicsUnit.Point);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "TicketForm";
            Text = "Ticket's Form";
            Load += TicketForm_Load;
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)dvgTicket).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Button btnLogOut;
        private Button btnClear;
        private Button btnUpdate;
        private Button btnInsert;
        private TextBox txtTicketID;
        private TextBox txtSeatNum;
        private TextBox txtCusInfo;
        private TextBox txtStpos;
        private Label label9;
        private DateTimePicker dtTicketdate;
        private ComboBox cbStaffID;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox1;
#pragma warning disable CS0169 // The field 'Ticket.panel1' is never used
#pragma warning restore CS0169 // The field 'Ticket.panel1' is never used
        private Label label10;
        private PictureBox pictureBox1;
        private Label label11;
#pragma warning disable CS0649 // Field 'Ticket.panel1_Paint' is never assigned to, and will always have its default value null
        private Panel panel2;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox2;
        private Label label13;
        private Label label12;
        private ComboBox cbCustomerID;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private Button btnBack;
        private TextBox txtSearch;
        private TextBox txtPrice;
        private DataGridView dvgTicket;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column4;
        private DataGridViewTextBoxColumn Column5;
        private DataGridViewTextBoxColumn Column6;
        private DataGridViewTextBoxColumn Column7;
        private DataGridViewTextBoxColumn Column8;
#pragma warning restore CS0649
    }
}