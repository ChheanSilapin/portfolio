﻿using PAGTMS.Models;
using PAGTMS.Ultils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAGTMS;

public partial class UserForm : Form
{
    private MainForm mainFormReference;
    Staff? effectedStaff = null;
    User? effectedUser = null;
    List<string> ListUser = new List<string>();
    int UserCount = 0;
    int IndexOfUpdateUser;
    private LoginForm loginFormReference;
    public UserForm(MainForm mainForm,LoginForm loginForm)
    {
        InitializeComponent();
        mainFormReference = mainForm;
        loginFormReference = loginForm;
        this.FormClosed += new FormClosedEventHandler((_, _) => mainFormReference.Show());
        btnClear.Click += DoClickNewFormInput;
        btnBack.Click += (_, _) => this.Close();
        cbStid.SelectedValueChanged += Select_Handling_StaffID;
        LsUser.SelectedValueChanged += Select_Handling_User;
        txtSearch.TextChanged += SearchFunction;
        btnInsert.Click += DoClickInsertUser;
        btnUpdate.Click += DoClickUpdateUser;
        ListUser.Clear();
        btnLogOut.Click += (_, _) => { this.Hide(); loginFormReference.Show(); };
    }
    private void SearchFunction(object? sender, EventArgs e)
    {
        if (string.IsNullOrEmpty(txtSearch.Text) == false)
        {
            LsUser.Items.Clear();
            foreach (string user in ListUser)

            {
                string[] splitText = user.Split('.');
                if (splitText[1].Trim().StartsWith(txtSearch.Text, StringComparison.OrdinalIgnoreCase))
                {
                    LsUser.Items.Add(user);
                }
            }
        }
        else if (txtSearch.Text == "")
        {
            LsUser.Items.Clear();
            foreach (string staff in ListUser)
            {
                LsUser.Items.Add(staff);
            }
        }
    }
    private void DoClickUpdateUser(object? sender, EventArgs e)
    {
        if (effectedUser != null)
        {
            effectedUser.UserID = int.Parse(txtUid.Text.Trim());
            effectedUser.Username = txtUname.Text.Trim();
            effectedUser.UserPassword = txtPass.Text.Trim();
            effectedUser.StaffID = int.Parse(cbStid.SelectedValue.ToString().Trim());
            effectedUser.StaffNameKh = txtStna.Text.Trim();
            effectedUser.StaffPosition = txtStpos.Text.Trim();
            try
            {
                var result = UserFunc.UpdateUser(Program.Connection, effectedUser);
                if (result == true)
                    MessageBox.Show($"Successfully updated!!", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                foreach (string checkuser in ListUser)
                {
                    string[] splitText = checkuser.Split('.');
                    if (splitText[0].Trim().Equals(effectedUser.UserID.ToString()))
                    {
                        IndexOfUpdateUser = ListUser.IndexOf(checkuser);
                        ListUser.Remove(checkuser);
                        break;
                    }
                }
                ListUser.Insert(IndexOfUpdateUser, $"{effectedUser.UserID}.{effectedUser.Username}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message} Update Failed");

            }
        }
        LoadingDataUser();
    }

    private void DoClickInsertUser(object? sender, EventArgs e)
    {
        if (int.TryParse(txtUid.Text, out int userID) == false)
        {
            MessageBox.Show("User ID is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (txtUname.Text == "")
        {
            MessageBox.Show("Username is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (txtPass.Text == "")
        {
            MessageBox.Show("Password is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (cbStid.SelectedItem == null)
        {
            MessageBox.Show("Staff ID is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (txtStna.Text == "")
        {
            MessageBox.Show("Staff Name KH is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (txtStpos.Text == "")
        {
            MessageBox.Show("Staff Position is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        string? staffID = cbStid.SelectedItem.ToString();
        if (staffID == null) return;
        User newUser = new User()
        {
            UserID = userID,
            Username = txtUname.Text.Trim(),
            UserPassword = txtPass.Text.Trim(),
            StaffID = int.Parse(staffID.Trim()),
            StaffNameKh = txtStna.Text.Trim(),
            StaffPosition = txtStpos.Text.Trim(),
        };
        try
        {
            UserFunc.AddUser(Program.Connection, newUser);
            MessageBox.Show($"Successfully Inserted!!", "Inserted", MessageBoxButtons.OK, MessageBoxIcon.Information);
            ListUser.Add($"{txtUid.Text}.{newUser.Username}");
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Submitting", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        LoadingDataUser();
    }
    private void DoClickNewFormInput(object? sender, EventArgs e)
    {

        txtUid.Text = (UserCount + 1).ToString();
        txtUname.Clear();
        txtPass.Clear();
        cbStid.SelectedItem = null;
        txtStna.Clear();
        txtStpos.Clear();
    }
    private void Select_Handling_StaffID(object? sender, EventArgs e)
    {
        if (cbStid.SelectedItem != null)
        {
            string? staffID = cbStid.SelectedItem.ToString();
            if (staffID == null) return;
            try
            {
                effectedStaff = StaffFunc.GetOneStaff(Program.Connection, int.Parse(staffID.Trim()));
                txtStna.Text = effectedStaff.StaffNameKH;
                txtStpos.Text = effectedStaff.StaffPosition;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}");
            }
        }
    }
    private void Select_Handling_User(object? sender, EventArgs e)
    {

        if (LsUser.SelectedItem != null)
        {
            string? userData = LsUser.SelectedItems[0].ToString();
            if (userData == null) return;
            string[] tempData = userData.Split('.');
            try
            {
                effectedUser = UserFunc.GetOneUser(Program.Connection, int.Parse(tempData[0].Trim()));
                txtUid.Text = effectedUser.UserID.ToString();
                txtUname.Text = effectedUser.Username;
                txtPass.Text = effectedUser.UserPassword;
                cbStid.SelectedItem = effectedUser.StaffID.ToString();
                txtStna.Text = effectedUser.StaffNameKh;
                txtStpos.Text = effectedUser.StaffPosition;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}");
            }
        }
    }
    private void UserForm_Load(object sender, EventArgs e)
    {
        LoadingDataStaffID();
        LoadingDataUser();
        txtUid.Text = (UserCount + 1).ToString();
        foreach (string user in LsUser.Items)
        {
            ListUser.Add(user);
            txtSearch.CharacterCasing = CharacterCasing.Normal;
        }
    }
    private void LoadingDataStaffID()
    {
        try
        {
            var result = StaffFunc.GetAllStaff(Program.Connection);
            List<string> ls = new List<string>();
            foreach (var staff in result)
            {
                ls.Add(staff.StaffID.ToString());

            }
            cbStid.DataSource = ls;
            cbStid.SelectedIndex = -1;
            txtStna.Clear();
            txtStpos.Clear();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Retriving User", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
    private void LoadingDataUser()
    {
        try
        {
            var result = UserFunc.GetAllUser(Program.Connection);
            if (result.LastOrDefault() != null) { UserCount = result.LastOrDefault().UserID; }
            else { UserCount = 0; }
            LsUser.Items.Clear();
            foreach (var user in result)
            {
                LsUser.Items.Add($"{user.UserID}. {user.Username}");
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Retriving User", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
