﻿namespace PAGTMS
{
    partial class ItemForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ItemForm));
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            label1 = new Label();
            label5 = new Label();
            btnLogOut = new Button();
            btnClear = new Button();
            btnUpdate = new Button();
            btnInsert = new Button();
            iconPictureBox1 = new FontAwesome.Sharp.IconPictureBox();
            pictureBox1 = new PictureBox();
            label10 = new Label();
            label11 = new Label();
            panel2 = new Panel();
            label13 = new Label();
            label12 = new Label();
            iconPictureBox2 = new FontAwesome.Sharp.IconPictureBox();
            pictureBox3 = new PictureBox();
            txtCate = new TextBox();
            label3 = new Label();
            btnBack = new Button();
            txtDescription = new TextBox();
            label2 = new Label();
            txtWeight = new TextBox();
            label4 = new Label();
            txtItemID = new TextBox();
            txtCusInfo = new TextBox();
            label6 = new Label();
            txtCusname = new TextBox();
            label9 = new Label();
            cbCustomerID = new ComboBox();
            label14 = new Label();
            label8 = new Label();
            cbTransID = new ComboBox();
            label7 = new Label();
            dtTd = new DateTimePicker();
            txtSearch = new TextBox();
            dgvItem = new DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column5 = new DataGridViewTextBoxColumn();
            Column6 = new DataGridViewTextBoxColumn();
            Column8 = new DataGridViewTextBoxColumn();
            Column9 = new DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvItem).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(13, 260);
            label1.Name = "label1";
            label1.Size = new Size(87, 19);
            label1.TabIndex = 0;
            label1.Text = "Search By :";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(13, 98);
            label5.Name = "label5";
            label5.Size = new Size(70, 19);
            label5.TabIndex = 0;
            label5.Text = "Item ID :";
            // 
            // btnLogOut
            // 
            btnLogOut.BackColor = Color.FromArgb(128, 255, 255);
            btnLogOut.BackgroundImageLayout = ImageLayout.Center;
            btnLogOut.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnLogOut.ForeColor = Color.Black;
            btnLogOut.Location = new Point(609, 290);
            btnLogOut.Name = "btnLogOut";
            btnLogOut.Size = new Size(94, 37);
            btnLogOut.TabIndex = 3;
            btnLogOut.Text = "Log Out\r\n";
            btnLogOut.UseVisualStyleBackColor = false;
            // 
            // btnClear
            // 
            btnClear.BackColor = Color.FromArgb(128, 255, 255);
            btnClear.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnClear.ForeColor = Color.Black;
            btnClear.Location = new Point(409, 290);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(94, 37);
            btnClear.TabIndex = 3;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = false;
            // 
            // btnUpdate
            // 
            btnUpdate.BackColor = Color.FromArgb(128, 255, 255);
            btnUpdate.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnUpdate.ForeColor = Color.Black;
            btnUpdate.Location = new Point(309, 290);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(94, 37);
            btnUpdate.TabIndex = 3;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = false;
            // 
            // btnInsert
            // 
            btnInsert.BackColor = Color.FromArgb(128, 255, 255);
            btnInsert.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnInsert.ForeColor = Color.Black;
            btnInsert.Location = new Point(209, 290);
            btnInsert.Name = "btnInsert";
            btnInsert.Size = new Size(94, 37);
            btnInsert.TabIndex = 3;
            btnInsert.Text = "Insert";
            btnInsert.UseVisualStyleBackColor = false;
            // 
            // iconPictureBox1
            // 
            iconPictureBox1.BackColor = Color.FromArgb(255, 255, 128);
            iconPictureBox1.ForeColor = SystemColors.ControlText;
            iconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.Copyright;
            iconPictureBox1.IconColor = SystemColors.ControlText;
            iconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox1.IconSize = 25;
            iconPictureBox1.Location = new Point(141, 47);
            iconPictureBox1.Name = "iconPictureBox1";
            iconPictureBox1.Size = new Size(25, 26);
            iconPictureBox1.TabIndex = 7;
            iconPictureBox1.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(3, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(132, 73);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(172, 52);
            label10.Name = "label10";
            label10.Size = new Size(238, 17);
            label10.TabIndex = 9;
            label10.Text = "Copyright ISAD_M3_25_Group(Roza)";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Times New Roman", 20F, FontStyle.Regular, GraphicsUnit.Point);
            label11.Location = new Point(186, 3);
            label11.Name = "label11";
            label11.Size = new Size(202, 39);
            label11.TabIndex = 9;
            label11.Text = "Ticket's Form";
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(255, 255, 128);
            panel2.Controls.Add(label13);
            panel2.Controls.Add(label12);
            panel2.Controls.Add(iconPictureBox2);
            panel2.Controls.Add(pictureBox3);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(874, 76);
            panel2.TabIndex = 7;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Times New Roman", 20F, FontStyle.Regular, GraphicsUnit.Point);
            label13.Location = new Point(195, 9);
            label13.Name = "label13";
            label13.Size = new Size(178, 39);
            label13.TabIndex = 2;
            label13.Text = "Item's Form";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(195, 56);
            label12.Name = "label12";
            label12.Size = new Size(221, 17);
            label12.TabIndex = 2;
            label12.Text = "Copyright ISAD_M3_Group5(2024)";
            // 
            // iconPictureBox2
            // 
            iconPictureBox2.BackColor = Color.FromArgb(255, 255, 128);
            iconPictureBox2.ForeColor = SystemColors.ControlText;
            iconPictureBox2.IconChar = FontAwesome.Sharp.IconChar.Copyright;
            iconPictureBox2.IconColor = SystemColors.ControlText;
            iconPictureBox2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox2.IconSize = 23;
            iconPictureBox2.Location = new Point(159, 50);
            iconPictureBox2.Name = "iconPictureBox2";
            iconPictureBox2.Size = new Size(30, 23);
            iconPictureBox2.TabIndex = 1;
            iconPictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(0, 1);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(153, 75);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 36;
            pictureBox3.TabStop = false;
            // 
            // txtCate
            // 
            txtCate.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtCate.Location = new Point(159, 123);
            txtCate.Name = "txtCate";
            txtCate.Size = new Size(252, 27);
            txtCate.TabIndex = 13;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(13, 129);
            label3.Name = "label3";
            label3.Size = new Size(80, 19);
            label3.TabIndex = 12;
            label3.Text = "Category :";
            // 
            // btnBack
            // 
            btnBack.BackColor = Color.FromArgb(128, 255, 255);
            btnBack.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnBack.ForeColor = Color.Black;
            btnBack.Location = new Point(509, 290);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(94, 37);
            btnBack.TabIndex = 24;
            btnBack.Text = "Back";
            btnBack.UseVisualStyleBackColor = false;
            // 
            // txtDescription
            // 
            txtDescription.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtDescription.Location = new Point(159, 154);
            txtDescription.Multiline = true;
            txtDescription.Name = "txtDescription";
            txtDescription.Size = new Size(252, 60);
            txtDescription.TabIndex = 27;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(13, 181);
            label2.Name = "label2";
            label2.Size = new Size(99, 19);
            label2.TabIndex = 26;
            label2.Text = "Description :";
            // 
            // txtWeight
            // 
            txtWeight.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtWeight.Location = new Point(159, 220);
            txtWeight.Name = "txtWeight";
            txtWeight.Size = new Size(252, 27);
            txtWeight.TabIndex = 29;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(13, 226);
            label4.Name = "label4";
            label4.Size = new Size(67, 19);
            label4.TabIndex = 28;
            label4.Text = "Weight :";
            // 
            // txtItemID
            // 
            txtItemID.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtItemID.Location = new Point(159, 92);
            txtItemID.Name = "txtItemID";
            txtItemID.ReadOnly = true;
            txtItemID.Size = new Size(252, 27);
            txtItemID.TabIndex = 37;
            // 
            // txtCusInfo
            // 
            txtCusInfo.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtCusInfo.Location = new Point(609, 154);
            txtCusInfo.Name = "txtCusInfo";
            txtCusInfo.ReadOnly = true;
            txtCusInfo.Size = new Size(256, 27);
            txtCusInfo.TabIndex = 40;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(438, 160);
            label6.Name = "label6";
            label6.Size = new Size(166, 19);
            label6.TabIndex = 39;
            label6.Text = "CustomerContactInfo :";
            // 
            // txtCusname
            // 
            txtCusname.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtCusname.Location = new Point(609, 123);
            txtCusname.Name = "txtCusname";
            txtCusname.ReadOnly = true;
            txtCusname.Size = new Size(256, 27);
            txtCusname.TabIndex = 45;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label9.Location = new Point(438, 129);
            label9.Name = "label9";
            label9.Size = new Size(125, 19);
            label9.TabIndex = 44;
            label9.Text = "Customer Name:";
            // 
            // cbCustomerID
            // 
            cbCustomerID.DropDownStyle = ComboBoxStyle.DropDownList;
            cbCustomerID.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            cbCustomerID.FormattingEnabled = true;
            cbCustomerID.Location = new Point(609, 92);
            cbCustomerID.Name = "cbCustomerID";
            cbCustomerID.Size = new Size(256, 27);
            cbCustomerID.TabIndex = 43;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label14.Location = new Point(438, 98);
            label14.Name = "label14";
            label14.Size = new Size(102, 19);
            label14.TabIndex = 42;
            label14.Text = "CustomerID :";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label8.Location = new Point(438, 222);
            label8.Name = "label8";
            label8.Size = new Size(114, 19);
            label8.TabIndex = 48;
            label8.Text = "Transport Date:";
            // 
            // cbTransID
            // 
            cbTransID.DropDownStyle = ComboBoxStyle.DropDownList;
            cbTransID.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            cbTransID.FormattingEnabled = true;
            cbTransID.Location = new Point(609, 185);
            cbTransID.Name = "cbTransID";
            cbTransID.Size = new Size(256, 27);
            cbTransID.TabIndex = 47;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label7.Location = new Point(438, 191);
            label7.Name = "label7";
            label7.Size = new Size(99, 19);
            label7.TabIndex = 46;
            label7.Text = "TransportID :";
            // 
            // dtTd
            // 
            dtTd.CustomFormat = "yyyy/MM/dd";
            dtTd.Enabled = false;
            dtTd.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            dtTd.Location = new Point(609, 218);
            dtTd.Name = "dtTd";
            dtTd.Size = new Size(256, 27);
            dtTd.TabIndex = 49;
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(12, 290);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(177, 25);
            txtSearch.TabIndex = 50;
            // 
            // dgvItem
            // 
            dgvItem.AllowUserToAddRows = false;
            dgvItem.AllowUserToDeleteRows = false;
            dgvItem.BackgroundColor = SystemColors.ButtonFace;
            dgvItem.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvItem.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column5, Column6, Column8, Column9 });
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = SystemColors.Window;
            dataGridViewCellStyle2.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            dgvItem.DefaultCellStyle = dataGridViewCellStyle2;
            dgvItem.Location = new Point(12, 346);
            dgvItem.Name = "dgvItem";
            dgvItem.ReadOnly = true;
            dgvItem.RowHeadersWidth = 51;
            dgvItem.Size = new Size(853, 173);
            dgvItem.TabIndex = 51;
            // 
            // Column1
            // 
            Column1.HeaderText = "ItemID";
            Column1.MinimumWidth = 6;
            Column1.Name = "Column1";
            Column1.ReadOnly = true;
            Column1.Width = 125;
            // 
            // Column2
            // 
            Column2.HeaderText = "Category";
            Column2.MinimumWidth = 6;
            Column2.Name = "Column2";
            Column2.ReadOnly = true;
            Column2.Width = 140;
            // 
            // Column5
            // 
            Column5.HeaderText = "CustomerID";
            Column5.MinimumWidth = 6;
            Column5.Name = "Column5";
            Column5.ReadOnly = true;
            Column5.Width = 125;
            // 
            // Column6
            // 
            Column6.HeaderText = "CustomerName";
            Column6.MinimumWidth = 6;
            Column6.Name = "Column6";
            Column6.ReadOnly = true;
            Column6.Width = 125;
            // 
            // Column8
            // 
            Column8.HeaderText = "TransportID";
            Column8.MinimumWidth = 6;
            Column8.Name = "Column8";
            Column8.ReadOnly = true;
            Column8.Width = 125;
            // 
            // Column9
            // 
            dataGridViewCellStyle1.Format = "d";
            dataGridViewCellStyle1.NullValue = null;
            Column9.DefaultCellStyle = dataGridViewCellStyle1;
            Column9.HeaderText = "TransportDate";
            Column9.MinimumWidth = 6;
            Column9.Name = "Column9";
            Column9.ReadOnly = true;
            Column9.Width = 125;
            // 
            // ItemForm
            // 
            AutoScaleDimensions = new SizeF(8F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(874, 520);
            Controls.Add(dgvItem);
            Controls.Add(txtSearch);
            Controls.Add(dtTd);
            Controls.Add(label8);
            Controls.Add(cbTransID);
            Controls.Add(label7);
            Controls.Add(txtCusname);
            Controls.Add(label9);
            Controls.Add(cbCustomerID);
            Controls.Add(label14);
            Controls.Add(txtCusInfo);
            Controls.Add(label6);
            Controls.Add(txtItemID);
            Controls.Add(txtWeight);
            Controls.Add(label4);
            Controls.Add(txtDescription);
            Controls.Add(label2);
            Controls.Add(btnBack);
            Controls.Add(txtCate);
            Controls.Add(label3);
            Controls.Add(panel2);
            Controls.Add(btnInsert);
            Controls.Add(btnUpdate);
            Controls.Add(btnClear);
            Controls.Add(btnLogOut);
            Controls.Add(label5);
            Controls.Add(label1);
            Font = new Font("Times New Roman", 9F, FontStyle.Regular, GraphicsUnit.Point);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "ItemForm";
            Text = "Item's Form";
            Load += ItemForm_Load;
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvItem).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private Label label1;
        private Label label5;
        private Button btnLogOut;
        private Button btnClear;
        private Button btnUpdate;
        private Button btnInsert;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox1;
#pragma warning disable CS0169 // The field 'Ticket.panel1' is never used
#pragma warning restore CS0169 // The field 'Ticket.panel1' is never used
        private Label label10;
        private PictureBox pictureBox1;
        private Label label11;
#pragma warning disable CS0649 // Field 'Ticket.panel1_Paint' is never assigned to, and will always have its default value null
        private Panel panel2;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox2;
        private Label label13;
        private Label label12;
        private TextBox txtCate;
        private Label label3;
        private Button btnBack;
        private TextBox txtDescription;
        private Label label2;
        private TextBox txtWeight;
        private Label label4;
        private TextBox txtItemID;
        private TextBox txtCusInfo;
        private Label label6;
        private PictureBox pictureBox3;
        private TextBox txtCusname;
        private Label label9;
        private ComboBox cbCustomerID;
        private Label label14;
        private Label label8;
        private ComboBox cbTransID;
        private Label label7;
        private DateTimePicker dtTd;
        private TextBox txtSearch;
        private DataGridView dgvItem;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column5;
        private DataGridViewTextBoxColumn Column6;
        private DataGridViewTextBoxColumn Column8;
        private DataGridViewTextBoxColumn Column9;
    }
}