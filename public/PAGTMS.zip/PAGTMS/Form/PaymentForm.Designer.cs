﻿namespace PAGTMS
{
    partial class PaymentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PaymentForm));
            label1 = new Label();
            label5 = new Label();
            label6 = new Label();
            btnLogOut = new Button();
            btnClear = new Button();
            btnUpdate = new Button();
            btnInsert = new Button();
            iconPictureBox1 = new FontAwesome.Sharp.IconPictureBox();
            pictureBox1 = new PictureBox();
            label10 = new Label();
            label11 = new Label();
            panel2 = new Panel();
            pictureBox3 = new PictureBox();
            label13 = new Label();
            label12 = new Label();
            iconPictureBox2 = new FontAwesome.Sharp.IconPictureBox();
            cbCustomerID = new ComboBox();
            txtPid = new TextBox();
            label3 = new Label();
            btnBack = new Button();
            txtCusInfo = new TextBox();
            label2 = new Label();
            label4 = new Label();
            dtPd = new DateTimePicker();
            txtCusname = new TextBox();
            label7 = new Label();
            txtStna = new TextBox();
            label8 = new Label();
            label9 = new Label();
            txtStpos = new TextBox();
            cbStaffID = new ComboBox();
            label14 = new Label();
            LsPayment = new ListBox();
            txtSearch = new TextBox();
            txtPamt = new TextBox();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(12, 92);
            label1.Name = "label1";
            label1.Size = new Size(175, 19);
            label1.TabIndex = 0;
            label1.Text = "Search CustomerName :";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(322, 115);
            label5.Name = "label5";
            label5.Size = new Size(94, 19);
            label5.TabIndex = 0;
            label5.Text = "PaymentID :";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(322, 270);
            label6.Name = "label6";
            label6.Size = new Size(166, 19);
            label6.TabIndex = 0;
            label6.Text = "Customer ContactInfo:";
            // 
            // btnLogOut
            // 
            btnLogOut.BackColor = Color.FromArgb(128, 255, 255);
            btnLogOut.BackgroundImageLayout = ImageLayout.Center;
            btnLogOut.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnLogOut.ForeColor = Color.Black;
            btnLogOut.Location = new Point(686, 422);
            btnLogOut.Name = "btnLogOut";
            btnLogOut.Size = new Size(94, 37);
            btnLogOut.TabIndex = 3;
            btnLogOut.Text = "Log Out\r\n";
            btnLogOut.UseVisualStyleBackColor = false;
            // 
            // btnClear
            // 
            btnClear.BackColor = Color.FromArgb(128, 255, 255);
            btnClear.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnClear.ForeColor = Color.Black;
            btnClear.Location = new Point(486, 420);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(94, 37);
            btnClear.TabIndex = 3;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = false;
            // 
            // btnUpdate
            // 
            btnUpdate.BackColor = Color.FromArgb(128, 255, 255);
            btnUpdate.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnUpdate.ForeColor = Color.Black;
            btnUpdate.Location = new Point(386, 420);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(94, 37);
            btnUpdate.TabIndex = 3;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = false;
            // 
            // btnInsert
            // 
            btnInsert.BackColor = Color.FromArgb(128, 255, 255);
            btnInsert.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnInsert.ForeColor = Color.Black;
            btnInsert.Location = new Point(286, 420);
            btnInsert.Name = "btnInsert";
            btnInsert.Size = new Size(94, 37);
            btnInsert.TabIndex = 3;
            btnInsert.Text = "Insert";
            btnInsert.UseVisualStyleBackColor = false;
            // 
            // iconPictureBox1
            // 
            iconPictureBox1.BackColor = Color.FromArgb(255, 255, 128);
            iconPictureBox1.ForeColor = SystemColors.ControlText;
            iconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.Copyright;
            iconPictureBox1.IconColor = SystemColors.ControlText;
            iconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox1.IconSize = 25;
            iconPictureBox1.Location = new Point(141, 47);
            iconPictureBox1.Name = "iconPictureBox1";
            iconPictureBox1.Size = new Size(25, 26);
            iconPictureBox1.TabIndex = 7;
            iconPictureBox1.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(3, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(132, 73);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(172, 52);
            label10.Name = "label10";
            label10.Size = new Size(238, 17);
            label10.TabIndex = 9;
            label10.Text = "Copyright ISAD_M3_25_Group(Roza)";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Times New Roman", 20F, FontStyle.Regular, GraphicsUnit.Point);
            label11.Location = new Point(186, 3);
            label11.Name = "label11";
            label11.Size = new Size(202, 39);
            label11.TabIndex = 9;
            label11.Text = "Ticket's Form";
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(255, 255, 128);
            panel2.Controls.Add(pictureBox3);
            panel2.Controls.Add(label13);
            panel2.Controls.Add(label12);
            panel2.Controls.Add(iconPictureBox2);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(784, 76);
            panel2.TabIndex = 7;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(3, 0);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(150, 76);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 30;
            pictureBox3.TabStop = false;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Times New Roman", 20F, FontStyle.Regular, GraphicsUnit.Point);
            label13.Location = new Point(195, 9);
            label13.Name = "label13";
            label13.Size = new Size(234, 39);
            label13.TabIndex = 2;
            label13.Text = "Payment's Form";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(195, 56);
            label12.Name = "label12";
            label12.Size = new Size(221, 17);
            label12.TabIndex = 2;
            label12.Text = "Copyright ISAD_M3_Group5(2024)";
            // 
            // iconPictureBox2
            // 
            iconPictureBox2.BackColor = Color.FromArgb(255, 255, 128);
            iconPictureBox2.ForeColor = SystemColors.ControlText;
            iconPictureBox2.IconChar = FontAwesome.Sharp.IconChar.Copyright;
            iconPictureBox2.IconColor = SystemColors.ControlText;
            iconPictureBox2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox2.IconSize = 23;
            iconPictureBox2.Location = new Point(159, 50);
            iconPictureBox2.Name = "iconPictureBox2";
            iconPictureBox2.Size = new Size(30, 23);
            iconPictureBox2.TabIndex = 1;
            iconPictureBox2.TabStop = false;
            // 
            // cbCustomerID
            // 
            cbCustomerID.DropDownStyle = ComboBoxStyle.DropDownList;
            cbCustomerID.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            cbCustomerID.FormattingEnabled = true;
            cbCustomerID.Location = new Point(499, 202);
            cbCustomerID.Name = "cbCustomerID";
            cbCustomerID.Size = new Size(252, 27);
            cbCustomerID.TabIndex = 8;
            // 
            // txtPid
            // 
            txtPid.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtPid.Location = new Point(499, 109);
            txtPid.Name = "txtPid";
            txtPid.ReadOnly = true;
            txtPid.Size = new Size(254, 27);
            txtPid.TabIndex = 13;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(322, 146);
            label3.Name = "label3";
            label3.Size = new Size(80, 19);
            label3.TabIndex = 12;
            label3.Text = "PaidDate :";
            // 
            // btnBack
            // 
            btnBack.BackColor = Color.FromArgb(128, 255, 255);
            btnBack.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnBack.ForeColor = Color.Black;
            btnBack.Location = new Point(586, 420);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(94, 37);
            btnBack.TabIndex = 24;
            btnBack.Text = "Back";
            btnBack.UseVisualStyleBackColor = false;
            // 
            // txtCusInfo
            // 
            txtCusInfo.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtCusInfo.Location = new Point(499, 264);
            txtCusInfo.Name = "txtCusInfo";
            txtCusInfo.ReadOnly = true;
            txtCusInfo.Size = new Size(252, 27);
            txtCusInfo.TabIndex = 27;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(322, 177);
            label2.Name = "label2";
            label2.Size = new Size(101, 19);
            label2.TabIndex = 26;
            label2.Text = "Paid Amount:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(322, 208);
            label4.Name = "label4";
            label4.Size = new Size(106, 19);
            label4.TabIndex = 28;
            label4.Text = "CustomerID  :";
            // 
            // dtPd
            // 
            dtPd.CustomFormat = "yyyy/MM/dd";
            dtPd.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            dtPd.Location = new Point(499, 140);
            dtPd.Name = "dtPd";
            dtPd.Size = new Size(254, 27);
            dtPd.TabIndex = 30;
            // 
            // txtCusname
            // 
            txtCusname.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtCusname.Location = new Point(499, 233);
            txtCusname.Name = "txtCusname";
            txtCusname.ReadOnly = true;
            txtCusname.Size = new Size(252, 27);
            txtCusname.TabIndex = 32;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label7.Location = new Point(322, 239);
            label7.Name = "label7";
            label7.Size = new Size(125, 19);
            label7.TabIndex = 31;
            label7.Text = "CustomerName :";
            // 
            // txtStna
            // 
            txtStna.Font = new Font("Khmer OS Siemreap", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtStna.Location = new Point(499, 326);
            txtStna.Name = "txtStna";
            txtStna.ReadOnly = true;
            txtStna.Size = new Size(252, 35);
            txtStna.TabIndex = 39;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label8.Location = new Point(322, 332);
            label8.Name = "label8";
            label8.Size = new Size(111, 19);
            label8.TabIndex = 38;
            label8.Text = "StaffNameKh :";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label9.Location = new Point(322, 301);
            label9.Name = "label9";
            label9.Size = new Size(72, 19);
            label9.TabIndex = 37;
            label9.Text = "StaffID  :";
            // 
            // txtStpos
            // 
            txtStpos.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtStpos.Location = new Point(499, 367);
            txtStpos.Name = "txtStpos";
            txtStpos.ReadOnly = true;
            txtStpos.Size = new Size(250, 27);
            txtStpos.TabIndex = 36;
            // 
            // cbStaffID
            // 
            cbStaffID.DropDownStyle = ComboBoxStyle.DropDownList;
            cbStaffID.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            cbStaffID.FormattingEnabled = true;
            cbStaffID.Location = new Point(499, 295);
            cbStaffID.Name = "cbStaffID";
            cbStaffID.Size = new Size(252, 27);
            cbStaffID.TabIndex = 35;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label14.Location = new Point(322, 373);
            label14.Name = "label14";
            label14.Size = new Size(109, 19);
            label14.TabIndex = 33;
            label14.Text = "StaffPosition :";
            // 
            // LsPayment
            // 
            LsPayment.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            LsPayment.FormattingEnabled = true;
            LsPayment.ItemHeight = 19;
            LsPayment.Location = new Point(12, 146);
            LsPayment.Name = "LsPayment";
            LsPayment.Size = new Size(248, 308);
            LsPayment.TabIndex = 40;
            // 
            // txtSearch
            // 
            txtSearch.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtSearch.Location = new Point(12, 114);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(248, 27);
            txtSearch.TabIndex = 41;
            // 
            // txtPamt
            // 
            txtPamt.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtPamt.Location = new Point(499, 171);
            txtPamt.Name = "txtPamt";
            txtPamt.Size = new Size(252, 27);
            txtPamt.TabIndex = 42;
            // 
            // PaymentForm
            // 
            AutoScaleDimensions = new SizeF(8F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(784, 478);
            Controls.Add(txtPamt);
            Controls.Add(txtSearch);
            Controls.Add(LsPayment);
            Controls.Add(txtStna);
            Controls.Add(label8);
            Controls.Add(label9);
            Controls.Add(txtStpos);
            Controls.Add(cbStaffID);
            Controls.Add(label14);
            Controls.Add(txtCusname);
            Controls.Add(label7);
            Controls.Add(dtPd);
            Controls.Add(label4);
            Controls.Add(txtCusInfo);
            Controls.Add(label2);
            Controls.Add(btnBack);
            Controls.Add(txtPid);
            Controls.Add(label3);
            Controls.Add(cbCustomerID);
            Controls.Add(panel2);
            Controls.Add(btnInsert);
            Controls.Add(btnUpdate);
            Controls.Add(btnClear);
            Controls.Add(btnLogOut);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label1);
            Font = new Font("Times New Roman", 9F, FontStyle.Regular, GraphicsUnit.Point);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "PaymentForm";
            Text = "Payment's Form";
            Load += PaymentForm_Load;
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private Label label1;
        private Label label5;
        private Label label6;
        private Button btnLogOut;
        private Button btnClear;
        private Button btnUpdate;
        private Button btnInsert;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox1;
#pragma warning disable CS0169 // The field 'Ticket.panel1' is never used
#pragma warning restore CS0169 // The field 'Ticket.panel1' is never used
        private Label label10;
        private PictureBox pictureBox1;
        private Label label11;
#pragma warning disable CS0649 // Field 'Ticket.panel1_Paint' is never assigned to, and will always have its default value null
        private Panel panel2;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox2;
        private Label label13;
        private Label label12;
        private ComboBox cbCustomerID;
        private TextBox txtPid;
        private Label label3;
        private Button btnBack;
        private TextBox txtCusInfo;
        private Label label2;
        private Label label4;
        private PictureBox pictureBox3;
        private DateTimePicker dtPd;
        private TextBox txtCusname;
        private Label label7;
        private TextBox txtStna;
        private Label label8;
        private Label label9;
        private TextBox txtStpos;
        private ComboBox cbStaffID;
        private Label label14;
        private ListBox LsPayment;
        private TextBox txtSearch;
        private TextBox txtPamt;
    }
}