﻿using PAGTMS.Models;
using PAGTMS.Ultils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAGTMS;

public partial class BookingForm : Form
{
    private MainForm mainFormReference;
    Customer? EffectedCustomer = null;
    Staff? EffectedStaff = null;
    Route? EffectedRoute = null;
    Vehicle? effectedVehicle = null;
    Booking? effectedBooking = null;
    List<DataGridViewRow> DataBooking = new List<DataGridViewRow>();
    int BookingCount = 0;
    int IndexOfUpdateBooking;
    private LoginForm loginFormReference;
    public BookingForm(MainForm mainForm, LoginForm loginForm)
    {
        InitializeComponent();
        mainFormReference = mainForm;
        loginFormReference = loginForm;
        this.FormClosed += new FormClosedEventHandler((_, _) => mainFormReference.Show());
        btnClear.Click += DoClickNewFormInput;
        btnBack.Click += (_, _) => this.Close();
        cbStaffID.SelectedValueChanged += Select_Handling_StaffID;
        cbVehicleID.SelectedValueChanged += Select_Handling_VehicleID;
        cbRouteID.SelectedValueChanged += Select_Handling_RouteID;
        cbCustomerID.SelectedValueChanged += Select_Handling_CusID;
        dvgBooking.Click += Select_Handling_Booking;
        txtSearch.TextChanged += SearchFuntion;
        btnInsert.Click += DoClickInsertBooking;
        btnUpdate.Click += DoClickUpdateBooking;
        dtBd.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
        DataBooking.Clear();
        btnLogOut.Click += (_, _) => { this.Hide(); loginFormReference.Show(); };
    }
    private void SearchFuntion(object? sender, EventArgs e)
    {
        if (string.IsNullOrEmpty(txtSearch.Text) == false)
        {
            dvgBooking.Rows.Clear();
            foreach (DataGridViewRow booking in DataBooking)
            {
                if (booking.Cells[0].Value.ToString().StartsWith(txtSearch.Text))
                {
                    dvgBooking.Rows.Add(booking);
                }
            }
        }
        else if (txtSearch.Text == "")
        {
            dvgBooking.Rows.Clear();
            foreach (DataGridViewRow booking in DataBooking)
            {
                dvgBooking.Rows.Add(booking);
            }
        }
    }
    private void Select_Handling_Booking(object? sender, EventArgs e)
    {
        if (dvgBooking.CurrentRow == null) return;
        int id = (int)dvgBooking.CurrentRow.Cells["BookingID"].Value;
        try
        {
            effectedBooking = BookingFunc.GetOneBooking(Program.Connection, id);
            txtBid.Text = effectedBooking.BookingID.ToString();
            dtBd.Value = (DateTime)effectedBooking.BookingDate;
            txtTotatpaid.Text = effectedBooking.TotalPaid.ToString();
            cbCustomerID.Text = effectedBooking.CustomerID.ToString();
            txtCusInfo.Text = effectedBooking.CustomerContactInfo;
            cbRouteID.Text = effectedBooking.RouteID.ToString();
            txtDes.Text = effectedBooking.Destination;
            cbVehicleID.Text = effectedBooking.VehicleID.ToString();
            txtVehicleType.Text = effectedBooking.VehicleType;
            txtStatus.Text = effectedBooking.VehicleStatus;
            cbStaffID.Text = effectedBooking.StaffID.ToString();
            txtStna.Text = effectedBooking.StaffNameKh;
            txtStpos.Text = effectedBooking.StaffPosition;

        }
        catch (Exception ex)
        {
            MessageBox.Show($"Here: {ex.Message}");
        }
    }
    private void DoClickUpdateBooking(object? sender, EventArgs e)
    {
        if (effectedBooking != null)
        {
            effectedBooking.BookingID = int.Parse(txtBid.Text.Trim());
            effectedBooking.BookingDate = dtBd.Value;
            effectedBooking.TotalPaid = decimal.Parse(txtTotatpaid.Text.Trim());
            effectedBooking.CustomerID = int.Parse(cbCustomerID.SelectedValue.ToString().Trim());
            effectedBooking.CustomerName = txtCusname.Text.Trim();
            effectedBooking.CustomerContactInfo = txtCusInfo.Text.Trim();
            effectedBooking.RouteID = int.Parse(cbRouteID.SelectedValue.ToString().Trim());
            effectedBooking.Destination = txtDes.Text.Trim();
            effectedBooking.VehicleID = int.Parse(cbVehicleID.SelectedValue.ToString().Trim());
            effectedBooking.VehicleType = txtVehicleType.Text.Trim();
            effectedBooking.VehicleStatus = txtStatus.Text.Trim();
            effectedBooking.StaffID = int.Parse(cbStaffID.SelectedValue.ToString().Trim());
            effectedBooking.StaffNameKh = txtStna.Text.Trim();
            effectedBooking.StaffPosition = txtStpos.Text.Trim();
            try
            {
                var result = BookingFunc.UpdateBooking(Program.Connection, effectedBooking);
                if (result == true)
                    MessageBox.Show($"Successfully Update a Booking!", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DataGridViewRow tempDataGridViewRow = new DataGridViewRow();
                tempDataGridViewRow.CreateCells(dvgBooking);
                tempDataGridViewRow.Cells[0].Value = effectedBooking.BookingID;
                tempDataGridViewRow.Cells[1].Value = effectedBooking.BookingDate;
                tempDataGridViewRow.Cells[2].Value = effectedBooking.TotalPaid;
                tempDataGridViewRow.Cells[3].Value = effectedBooking.CustomerID;
                tempDataGridViewRow.Cells[4].Value = effectedBooking.RouteID;
                tempDataGridViewRow.Cells[5].Value = effectedBooking.VehicleID;
                tempDataGridViewRow.Cells[6].Value = effectedBooking.StaffID;
                tempDataGridViewRow.Cells[7].Value = effectedBooking.StaffPosition;
                foreach (DataGridViewRow checkBooking in DataBooking)
                {
                    if (int.Parse(checkBooking.Cells[0].Value.ToString()) == effectedBooking.BookingID)
                    {
                        checkBooking.Cells[1].Value = tempDataGridViewRow.Cells[1].Value;
                        checkBooking.Cells[2].Value = tempDataGridViewRow.Cells[2].Value;
                        checkBooking.Cells[3].Value = tempDataGridViewRow.Cells[3].Value;
                        checkBooking.Cells[4].Value = tempDataGridViewRow.Cells[4].Value;
                        checkBooking.Cells[5].Value = tempDataGridViewRow.Cells[5].Value;
                        checkBooking.Cells[6].Value = tempDataGridViewRow.Cells[6].Value;
                        checkBooking.Cells[7].Value = tempDataGridViewRow.Cells[7].Value;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Update Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
        LoadingDataBooking();
    }
    private void DoClickInsertBooking(object? sender, EventArgs e)
    {
        if (int.TryParse(txtBid.Text, out int bookingID) == false)
        {
            MessageBox.Show("Booking ID is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (dtBd.Text == "")
        {
            MessageBox.Show("BookingDate is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (decimal.TryParse(txtTotatpaid.Text, out decimal totalPaid) == false)
        {
            MessageBox.Show("TotalPaid is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
        }
        if (cbCustomerID.SelectedItem == null)
        {
            MessageBox.Show("Customer ID is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (cbRouteID.SelectedItem == null)
        {
            MessageBox.Show("Route ID is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (cbVehicleID.SelectedItem == null)
        {
            MessageBox.Show("Vehicle ID is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (cbStaffID.SelectedItem == null)
        {
            MessageBox.Show("Staff ID is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }

        string? customerID = cbCustomerID.SelectedItem.ToString();
        if (customerID == null) return;

        string? routeID = cbRouteID.SelectedItem.ToString();
        if (routeID == null) return;

        string? vehicleID = cbVehicleID.SelectedItem.ToString();
        if (vehicleID == null) return;

        string? staffID = cbStaffID.SelectedItem.ToString();
        if (staffID == null) return;
        Booking newBooking = new Booking()
        {
            BookingID = bookingID,
            BookingDate = dtBd.Value,
            TotalPaid = totalPaid,
            CustomerID = int.Parse(customerID.Trim()),
            CustomerName = txtCusname.Text.Trim(),
            CustomerContactInfo = txtCusInfo.Text.Trim(),
            RouteID = int.Parse(routeID.Trim()),
            Destination = txtDes.Text.Trim(),
            VehicleID = int.Parse(vehicleID.Trim()),
            VehicleType = txtVehicleType.Text.Trim(),
            VehicleStatus = txtStatus.Text.Trim(),
            StaffID = int.Parse(staffID.Trim()),
            StaffNameKh = txtStna.Text.Trim(),
            StaffPosition = txtStpos.Text.Trim(),
        };
        try
        {
            BookingFunc.AddBooking(Program.Connection, newBooking);
            MessageBox.Show($"Successfully Inserted a New Booking!", "Inserted", MessageBoxButtons.OK, MessageBoxIcon.Information);
            DataGridViewRow tempDataGridViewRow = new DataGridViewRow();
            tempDataGridViewRow.CreateCells(dvgBooking);
            tempDataGridViewRow.Cells[0].Value = txtBid.Text;
            tempDataGridViewRow.Cells[1].Value = newBooking.BookingDate;
            tempDataGridViewRow.Cells[2].Value = newBooking.TotalPaid;
            tempDataGridViewRow.Cells[3].Value = cbCustomerID.Text;           
            tempDataGridViewRow.Cells[4].Value = cbRouteID.Text;
            tempDataGridViewRow.Cells[5].Value = cbVehicleID.Text;
            tempDataGridViewRow.Cells[6].Value = cbStaffID.Text;
            tempDataGridViewRow.Cells[7].Value = newBooking.StaffPosition;
            DataBooking.Add(tempDataGridViewRow);
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Submitting", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        LoadingDataBooking();
    }
    private void Select_Handling_CusID(object? sender, EventArgs e)
    {
        if (cbCustomerID.SelectedItem != null)
        {
            string? customerID = cbCustomerID.SelectedItem.ToString();
            if (customerID == null) return;
            try
            {
                EffectedCustomer = CustomerFunc.GetOneCustomer(Program.Connection, int.Parse(customerID.Trim()));
                txtCusname.Text = EffectedCustomer.CustomerName;
                txtCusInfo.Text = EffectedCustomer.CustomerContactInfo;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}");
            }
        }
    }

    private void Select_Handling_RouteID(object? sender, EventArgs e)
    {
        if (cbRouteID.SelectedItem != null)
        {
            string? routeID = cbRouteID.SelectedItem.ToString();
            if (routeID == null) return;
            try
            {
                EffectedRoute = RouteFunc.GetOneRoute(Program.Connection, int.Parse(routeID.Trim()));
                txtDes.Text = EffectedRoute.Destination;
            }
            catch (Exception ex) { MessageBox.Show($"{ex.Message}"); }
        }
    }

    private void Select_Handling_VehicleID(object? sender, EventArgs e)
    {
        if (cbVehicleID.SelectedItem != null)
        {
            string? vehicleID = cbVehicleID.SelectedItem.ToString();
            if (vehicleID == null) return;
            try
            {
                effectedVehicle = VehicleFunc.GetOneVehicle(Program.Connection, int.Parse(vehicleID.Trim()));
                txtVehicleType.Text = effectedVehicle.VehicleType;
                txtStatus.Text = effectedVehicle.VehicleStatus;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}");
            }
        }
    }

    private void Select_Handling_StaffID(object? sender, EventArgs e)
    {
        if (cbStaffID.SelectedItem != null)
        {
            string? staffID = cbStaffID.SelectedItem.ToString();
            if (staffID == null) return;
            try
            {
                EffectedStaff = StaffFunc.GetOneStaff(Program.Connection, int.Parse(staffID.Trim()));
                txtStna.Text = EffectedStaff.StaffNameKH;
                txtStpos.Text = EffectedStaff.StaffPosition;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}");
            }
        }
    }

    private void LoadingDataVehicleID()
    {
        try
        {
            var result = VehicleFunc.GetAllVehicle(Program.Connection);
            List<string> ls = new List<string>();
            foreach (var vehicle in result)
            {
                ls.Add(vehicle.VehicleID.ToString());

            }
            cbVehicleID.DataSource = ls;
            cbVehicleID.SelectedIndex = -1;
            txtVehicleType.Clear();
            txtStatus.Clear();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Retriving Vehicle", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void LoadingDataRouteID()
    {
        try
        {
            var result = RouteFunc.GetAllRoute(Program.Connection);
            List<string> ls = new List<string>();
            foreach (var route in result)
            {
                ls.Add(route.RouteID.ToString());

            }
            cbRouteID.DataSource = ls;
            cbRouteID.SelectedIndex = -1;
            txtDes.Clear();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Retriving Route", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void LoadingDataStaffID()
    {
        try
        {
            var result = StaffFunc.GetAllStaff(Program.Connection);
            List<string> ls = new List<string>();
            foreach (var staff in result)
            {
                ls.Add(staff.StaffID.ToString());

            }
            cbStaffID.DataSource = ls;
            cbStaffID.SelectedIndex = -1;
            txtStna.Clear();
            txtStpos.Clear();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Retriving Staff", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void LoadingDataCustomerID()
    {
        try
        {
            var result = CustomerFunc.GetAllCustomer(Program.Connection);
            List<string> ls = new List<string>();
            foreach (var customer in result)
            {
                ls.Add(customer.CustomerID.ToString());

            }
            cbCustomerID.DataSource = ls;
            cbCustomerID.SelectedIndex = -1;
            txtCusname.Clear();
            txtCusInfo.Clear();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Retriving User", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void LoadingDataBooking()
    {
        try
        {
            var result = BookingFunc.GetAllBooking(Program.Connection);
            if (result.LastOrDefault() != null) { BookingCount = result.LastOrDefault().BookingID; }
            else { BookingCount = 0; }
            dvgBooking.Rows.Clear();
            foreach (var booking in result)
            {
                dvgBooking.Rows.Add(booking.BookingID, booking.BookingDate, booking.TotalPaid, booking.CustomerID,
                    booking.RouteID, booking.VehicleID, booking.StaffID,
                    booking.StaffPosition);
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Retriving Booking", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
    private void DoClickNewFormInput(object? sender, EventArgs e)
    {
        txtBid.Text = (BookingCount + 1).ToString();
        dtBd.ResetText();
        txtTotatpaid.Clear();
        cbCustomerID.SelectedItem = null;
        txtCusname.Clear();
        txtCusInfo.Clear();
        cbRouteID.SelectedItem = null;
        txtDes.Clear();
        cbVehicleID.SelectedItem = null;
        txtVehicleType.Clear();
        txtStatus.Clear();
        cbStaffID.SelectedItem = null;
        txtStna.Clear();
        txtStpos.Clear();
    }

    private void BookingForm_Load(object sender, EventArgs e)
    {
        LoadingDataCustomerID();
        LoadingDataRouteID();
        LoadingDataVehicleID();
        LoadingDataStaffID();
        LoadingDataBooking();
        txtBid.Text = (BookingCount + 1).ToString();
        foreach (DataGridViewRow booking in dvgBooking.Rows)
        {
            this.DataBooking.Add(booking);
            txtSearch.CharacterCasing = CharacterCasing.Normal;
        }
    }
}
