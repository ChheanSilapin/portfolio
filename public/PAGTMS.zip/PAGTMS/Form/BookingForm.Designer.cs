﻿namespace PAGTMS
{
    partial class BookingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BookingForm));
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            label1 = new Label();
            label2 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            txtTotatpaid = new TextBox();
            txtCusInfo = new TextBox();
            txtStpos = new TextBox();
            label9 = new Label();
            dtBd = new DateTimePicker();
            cbStaffID = new ComboBox();
            iconPictureBox1 = new FontAwesome.Sharp.IconPictureBox();
            pictureBox1 = new PictureBox();
            label10 = new Label();
            label11 = new Label();
            panel2 = new Panel();
            label13 = new Label();
            label12 = new Label();
            iconPictureBox2 = new FontAwesome.Sharp.IconPictureBox();
            cbCustomerID = new ComboBox();
            pictureBox4 = new PictureBox();
            txtCusname = new TextBox();
            label3 = new Label();
            label14 = new Label();
            label15 = new Label();
            cbRouteID = new ComboBox();
            txtDes = new TextBox();
            label16 = new Label();
            label17 = new Label();
            label18 = new Label();
            btnInsert = new Button();
            btnLogOut = new Button();
            btnBack = new Button();
            btnClear = new Button();
            btnUpdate = new Button();
            txtSearch = new TextBox();
            txtStna = new TextBox();
            label19 = new Label();
            dvgBooking = new DataGridView();
            txtBid = new TextBox();
            txtVehicleType = new TextBox();
            txtStatus = new TextBox();
            cbVehicleID = new ComboBox();
            BookingID = new DataGridViewTextBoxColumn();
            BookingDate = new DataGridViewTextBoxColumn();
            Column10 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            Column5 = new DataGridViewTextBoxColumn();
            Column7 = new DataGridViewTextBoxColumn();
            Column8 = new DataGridViewTextBoxColumn();
            Column9 = new DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dvgBooking).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(14, 325);
            label1.Name = "label1";
            label1.Size = new Size(143, 19);
            label1.TabIndex = 0;
            label1.Text = "Search BookingID :";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(12, 106);
            label2.Name = "label2";
            label2.Size = new Size(93, 19);
            label2.TabIndex = 0;
            label2.Text = "BookingID :\r\n";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(12, 167);
            label4.Name = "label4";
            label4.Size = new Size(86, 19);
            label4.TabIndex = 0;
            label4.Text = "Total Paid :";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(12, 195);
            label5.Name = "label5";
            label5.Size = new Size(106, 19);
            label5.TabIndex = 0;
            label5.Text = "Customer ID :";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(12, 254);
            label6.Name = "label6";
            label6.Size = new Size(142, 19);
            label6.TabIndex = 0;
            label6.Text = "Customer Contact :";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label7.Location = new Point(473, 230);
            label7.Name = "label7";
            label7.Size = new Size(72, 19);
            label7.TabIndex = 0;
            label7.Text = "Staff ID :";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label8.Location = new Point(473, 302);
            label8.Name = "label8";
            label8.Size = new Size(113, 19);
            label8.TabIndex = 0;
            label8.Text = "Staff Position :";
            // 
            // txtTotatpaid
            // 
            txtTotatpaid.Location = new Point(175, 161);
            txtTotatpaid.Name = "txtTotatpaid";
            txtTotatpaid.Size = new Size(252, 25);
            txtTotatpaid.TabIndex = 4;
            // 
            // txtCusInfo
            // 
            txtCusInfo.Location = new Point(175, 251);
            txtCusInfo.Name = "txtCusInfo";
            txtCusInfo.ReadOnly = true;
            txtCusInfo.Size = new Size(252, 25);
            txtCusInfo.TabIndex = 4;
            // 
            // txtStpos
            // 
            txtStpos.Location = new Point(636, 296);
            txtStpos.Name = "txtStpos";
            txtStpos.ReadOnly = true;
            txtStpos.Size = new Size(252, 25);
            txtStpos.TabIndex = 4;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label9.Location = new Point(12, 136);
            label9.Name = "label9";
            label9.Size = new Size(108, 19);
            label9.TabIndex = 0;
            label9.Text = "BookingDate :";
            // 
            // dtBd
            // 
            dtBd.CustomFormat = "MM/dd/yyyy";
            dtBd.Format = DateTimePickerFormat.Custom;
            dtBd.Location = new Point(175, 130);
            dtBd.Name = "dtBd";
            dtBd.Size = new Size(252, 25);
            dtBd.TabIndex = 5;
            // 
            // cbStaffID
            // 
            cbStaffID.DropDownStyle = ComboBoxStyle.DropDownList;
            cbStaffID.FormattingEnabled = true;
            cbStaffID.Location = new Point(636, 224);
            cbStaffID.Name = "cbStaffID";
            cbStaffID.Size = new Size(252, 25);
            cbStaffID.TabIndex = 6;
            // 
            // iconPictureBox1
            // 
            iconPictureBox1.BackColor = Color.FromArgb(255, 255, 128);
            iconPictureBox1.ForeColor = SystemColors.ControlText;
            iconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.Copyright;
            iconPictureBox1.IconColor = SystemColors.ControlText;
            iconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox1.IconSize = 25;
            iconPictureBox1.Location = new Point(141, 47);
            iconPictureBox1.Name = "iconPictureBox1";
            iconPictureBox1.Size = new Size(25, 26);
            iconPictureBox1.TabIndex = 7;
            iconPictureBox1.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(3, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(132, 73);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(172, 52);
            label10.Name = "label10";
            label10.Size = new Size(238, 17);
            label10.TabIndex = 9;
            label10.Text = "Copyright ISAD_M3_25_Group(Roza)";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Times New Roman", 20F, FontStyle.Regular, GraphicsUnit.Point);
            label11.Location = new Point(186, 3);
            label11.Name = "label11";
            label11.Size = new Size(202, 39);
            label11.TabIndex = 9;
            label11.Text = "Ticket's Form";
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(255, 255, 128);
            panel2.Controls.Add(label13);
            panel2.Controls.Add(label12);
            panel2.Controls.Add(iconPictureBox2);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(899, 76);
            panel2.TabIndex = 7;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Times New Roman", 20F, FontStyle.Regular, GraphicsUnit.Point);
            label13.Location = new Point(203, 9);
            label13.Name = "label13";
            label13.Size = new Size(232, 39);
            label13.TabIndex = 2;
            label13.Text = "Booking's Form";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(203, 56);
            label12.Name = "label12";
            label12.Size = new Size(221, 17);
            label12.TabIndex = 2;
            label12.Text = "Copyright ISAD_M3_Group5(2024)";
            // 
            // iconPictureBox2
            // 
            iconPictureBox2.BackColor = Color.FromArgb(255, 255, 128);
            iconPictureBox2.ForeColor = SystemColors.ControlText;
            iconPictureBox2.IconChar = FontAwesome.Sharp.IconChar.Copyright;
            iconPictureBox2.IconColor = SystemColors.ControlText;
            iconPictureBox2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox2.IconSize = 23;
            iconPictureBox2.Location = new Point(167, 50);
            iconPictureBox2.Name = "iconPictureBox2";
            iconPictureBox2.Size = new Size(30, 23);
            iconPictureBox2.TabIndex = 1;
            iconPictureBox2.TabStop = false;
            // 
            // cbCustomerID
            // 
            cbCustomerID.DropDownStyle = ComboBoxStyle.DropDownList;
            cbCustomerID.FormattingEnabled = true;
            cbCustomerID.Location = new Point(175, 189);
            cbCustomerID.Name = "cbCustomerID";
            cbCustomerID.Size = new Size(252, 25);
            cbCustomerID.TabIndex = 8;
            // 
            // pictureBox4
            // 
            pictureBox4.BackColor = Color.FromArgb(255, 255, 128);
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(0, 0);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(161, 76);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 11;
            pictureBox4.TabStop = false;
            // 
            // txtCusname
            // 
            txtCusname.Location = new Point(175, 220);
            txtCusname.Name = "txtCusname";
            txtCusname.ReadOnly = true;
            txtCusname.Size = new Size(252, 25);
            txtCusname.TabIndex = 13;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(12, 226);
            label3.Name = "label3";
            label3.Size = new Size(129, 19);
            label3.TabIndex = 12;
            label3.Text = "Customer Name :";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label14.Location = new Point(473, 199);
            label14.Name = "label14";
            label14.Size = new Size(59, 19);
            label14.TabIndex = 14;
            label14.Text = "Status :";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label15.Location = new Point(473, 137);
            label15.Name = "label15";
            label15.Size = new Size(90, 19);
            label15.TabIndex = 15;
            label15.Text = "Vehicle ID :";
            // 
            // cbRouteID
            // 
            cbRouteID.DropDownStyle = ComboBoxStyle.DropDownList;
            cbRouteID.FormattingEnabled = true;
            cbRouteID.Location = new Point(175, 282);
            cbRouteID.Name = "cbRouteID";
            cbRouteID.Size = new Size(252, 25);
            cbRouteID.TabIndex = 21;
            // 
            // txtDes
            // 
            txtDes.Location = new Point(636, 100);
            txtDes.Name = "txtDes";
            txtDes.ReadOnly = true;
            txtDes.Size = new Size(252, 25);
            txtDes.TabIndex = 20;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label16.Location = new Point(473, 106);
            label16.Name = "label16";
            label16.Size = new Size(97, 19);
            label16.TabIndex = 18;
            label16.Text = "Destination :";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label17.Location = new Point(14, 288);
            label17.Name = "label17";
            label17.Size = new Size(80, 19);
            label17.TabIndex = 19;
            label17.Text = "Route ID :";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label18.Location = new Point(473, 168);
            label18.Name = "label18";
            label18.Size = new Size(50, 19);
            label18.TabIndex = 22;
            label18.Text = "Type :";
            // 
            // btnInsert
            // 
            btnInsert.BackColor = Color.FromArgb(128, 255, 255);
            btnInsert.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnInsert.ForeColor = Color.Black;
            btnInsert.Location = new Point(14, 578);
            btnInsert.Name = "btnInsert";
            btnInsert.Size = new Size(94, 37);
            btnInsert.TabIndex = 3;
            btnInsert.Text = "Insert";
            btnInsert.UseVisualStyleBackColor = false;
            // 
            // btnLogOut
            // 
            btnLogOut.BackColor = Color.FromArgb(128, 255, 255);
            btnLogOut.BackgroundImageLayout = ImageLayout.Center;
            btnLogOut.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnLogOut.ForeColor = Color.Black;
            btnLogOut.Location = new Point(793, 578);
            btnLogOut.Name = "btnLogOut";
            btnLogOut.Size = new Size(94, 37);
            btnLogOut.TabIndex = 3;
            btnLogOut.Text = "Log Out\r\n";
            btnLogOut.UseVisualStyleBackColor = false;
            // 
            // btnBack
            // 
            btnBack.BackColor = Color.FromArgb(128, 255, 255);
            btnBack.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnBack.ForeColor = Color.Black;
            btnBack.Location = new Point(622, 578);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(94, 37);
            btnBack.TabIndex = 24;
            btnBack.Text = "Back";
            btnBack.UseVisualStyleBackColor = false;
            // 
            // btnClear
            // 
            btnClear.BackColor = Color.FromArgb(128, 255, 255);
            btnClear.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnClear.ForeColor = Color.Black;
            btnClear.Location = new Point(411, 578);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(94, 37);
            btnClear.TabIndex = 3;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = false;
            // 
            // btnUpdate
            // 
            btnUpdate.BackColor = Color.FromArgb(128, 255, 255);
            btnUpdate.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnUpdate.ForeColor = Color.Black;
            btnUpdate.Location = new Point(212, 578);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(94, 37);
            btnUpdate.TabIndex = 3;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = false;
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(14, 356);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(185, 25);
            txtSearch.TabIndex = 26;
            // 
            // txtStna
            // 
            txtStna.Font = new Font("Khmer OS Siemreap", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtStna.Location = new Point(636, 255);
            txtStna.Name = "txtStna";
            txtStna.ReadOnly = true;
            txtStna.Size = new Size(252, 35);
            txtStna.TabIndex = 41;
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label19.Location = new Point(473, 271);
            label19.Name = "label19";
            label19.Size = new Size(111, 19);
            label19.TabIndex = 40;
            label19.Text = "StaffNameKh :";
            // 
            // dvgBooking
            // 
            dvgBooking.AllowUserToAddRows = false;
            dvgBooking.AllowUserToDeleteRows = false;
            dvgBooking.BackgroundColor = SystemColors.ButtonHighlight;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dvgBooking.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dvgBooking.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dvgBooking.Columns.AddRange(new DataGridViewColumn[] { BookingID, BookingDate, Column10, Column3, Column5, Column7, Column8, Column9 });
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = SystemColors.Window;
            dataGridViewCellStyle3.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle3.NullValue = null;
            dataGridViewCellStyle3.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            dvgBooking.DefaultCellStyle = dataGridViewCellStyle3;
            dvgBooking.Location = new Point(12, 387);
            dvgBooking.Name = "dvgBooking";
            dvgBooking.ReadOnly = true;
            dvgBooking.RowHeadersWidth = 51;
            dvgBooking.RowTemplate.Height = 29;
            dvgBooking.Size = new Size(875, 185);
            dvgBooking.TabIndex = 44;
            // 
            // txtBid
            // 
            txtBid.Location = new Point(175, 99);
            txtBid.Name = "txtBid";
            txtBid.ReadOnly = true;
            txtBid.Size = new Size(252, 25);
            txtBid.TabIndex = 45;
            // 
            // txtVehicleType
            // 
            txtVehicleType.Location = new Point(636, 162);
            txtVehicleType.Name = "txtVehicleType";
            txtVehicleType.ReadOnly = true;
            txtVehicleType.Size = new Size(252, 25);
            txtVehicleType.TabIndex = 46;
            // 
            // txtStatus
            // 
            txtStatus.Location = new Point(636, 193);
            txtStatus.Name = "txtStatus";
            txtStatus.ReadOnly = true;
            txtStatus.Size = new Size(252, 25);
            txtStatus.TabIndex = 47;
            // 
            // cbVehicleID
            // 
            cbVehicleID.DropDownStyle = ComboBoxStyle.DropDownList;
            cbVehicleID.FormattingEnabled = true;
            cbVehicleID.Location = new Point(635, 131);
            cbVehicleID.Name = "cbVehicleID";
            cbVehicleID.Size = new Size(252, 25);
            cbVehicleID.TabIndex = 48;
            // 
            // BookingID
            // 
            BookingID.HeaderText = "BookingID";
            BookingID.MinimumWidth = 6;
            BookingID.Name = "BookingID";
            BookingID.ReadOnly = true;
            BookingID.Width = 125;
            // 
            // BookingDate
            // 
            dataGridViewCellStyle2.Format = "d";
            dataGridViewCellStyle2.NullValue = null;
            BookingDate.DefaultCellStyle = dataGridViewCellStyle2;
            BookingDate.HeaderText = "BookingDate";
            BookingDate.MinimumWidth = 6;
            BookingDate.Name = "BookingDate";
            BookingDate.ReadOnly = true;
            BookingDate.Width = 125;
            // 
            // Column10
            // 
            Column10.HeaderText = "TotalPaid";
            Column10.MinimumWidth = 6;
            Column10.Name = "Column10";
            Column10.ReadOnly = true;
            Column10.Width = 125;
            // 
            // Column3
            // 
            Column3.HeaderText = "CustomerID";
            Column3.MinimumWidth = 6;
            Column3.Name = "Column3";
            Column3.ReadOnly = true;
            Column3.Width = 125;
            // 
            // Column5
            // 
            Column5.HeaderText = "RouteID";
            Column5.MinimumWidth = 6;
            Column5.Name = "Column5";
            Column5.ReadOnly = true;
            Column5.Width = 125;
            // 
            // Column7
            // 
            Column7.HeaderText = "VehicleID";
            Column7.MinimumWidth = 6;
            Column7.Name = "Column7";
            Column7.ReadOnly = true;
            Column7.Width = 125;
            // 
            // Column8
            // 
            Column8.HeaderText = "StaffID";
            Column8.MinimumWidth = 6;
            Column8.Name = "Column8";
            Column8.ReadOnly = true;
            Column8.Width = 125;
            // 
            // Column9
            // 
            Column9.HeaderText = "StaffPosition";
            Column9.MinimumWidth = 6;
            Column9.Name = "Column9";
            Column9.ReadOnly = true;
            Column9.Width = 125;
            // 
            // BookingForm
            // 
            AutoScaleDimensions = new SizeF(8F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(899, 627);
            Controls.Add(cbVehicleID);
            Controls.Add(txtStatus);
            Controls.Add(txtVehicleType);
            Controls.Add(txtBid);
            Controls.Add(dvgBooking);
            Controls.Add(txtStna);
            Controls.Add(label19);
            Controls.Add(txtSearch);
            Controls.Add(btnBack);
            Controls.Add(label18);
            Controls.Add(cbRouteID);
            Controls.Add(txtDes);
            Controls.Add(label16);
            Controls.Add(label17);
            Controls.Add(label14);
            Controls.Add(label15);
            Controls.Add(txtCusname);
            Controls.Add(label3);
            Controls.Add(pictureBox4);
            Controls.Add(cbCustomerID);
            Controls.Add(panel2);
            Controls.Add(cbStaffID);
            Controls.Add(dtBd);
            Controls.Add(txtStpos);
            Controls.Add(txtCusInfo);
            Controls.Add(txtTotatpaid);
            Controls.Add(btnInsert);
            Controls.Add(btnUpdate);
            Controls.Add(btnClear);
            Controls.Add(btnLogOut);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label9);
            Controls.Add(label4);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Times New Roman", 9F, FontStyle.Regular, GraphicsUnit.Point);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "BookingForm";
            Text = "Booking's Form";
            Load += BookingForm_Load;
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)dvgBooking).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private TextBox txtTotatpaid;
        private TextBox txtCusInfo;
        private TextBox txtStpos;
        private Label label9;
        private DateTimePicker dtBd;
        private ComboBox cbStaffID;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox1;
#pragma warning disable CS0169 // The field 'Ticket.panel1' is never used
#pragma warning restore CS0169 // The field 'Ticket.panel1' is never used
        private Label label10;
        private PictureBox pictureBox1;
        private Label label11;
#pragma warning disable CS0649 // Field 'Ticket.panel1_Paint' is never assigned to, and will always have its default value null
        private Panel panel2;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox2;
        private Label label13;
        private Label label12;
        private ComboBox cbCustomerID;

        #endregion
        private PictureBox pictureBox4;
        private TextBox txtCusname;
        private Label label3;
        private Label label14;
        private Label label15;
        private ComboBox cbRouteID;
        private TextBox txtDes;
        private Label label16;
        private Label label17;
        private Label label18;
        private Button btnInsert;
        private Button btnLogOut;
        private Button btnBack;
        private Button btnClear;
        private Button btnUpdate;
        private TextBox txtSearch;
        private TextBox txtStna;
        private Label label19;
        private DataGridView dvgBooking;
        private TextBox txtBid;
        private TextBox txtVehicleType;
        private TextBox txtStatus;
        private ComboBox cbVehicleID;
        private DataGridViewTextBoxColumn BookingID;
        private DataGridViewTextBoxColumn BookingDate;
        private DataGridViewTextBoxColumn Column10;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column5;
        private DataGridViewTextBoxColumn Column7;
        private DataGridViewTextBoxColumn Column8;
        private DataGridViewTextBoxColumn Column9;
    }
}