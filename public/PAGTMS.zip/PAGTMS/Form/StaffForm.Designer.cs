﻿namespace PAGTMS
{
    partial class StaffForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StaffForm));
            label1 = new Label();
            label5 = new Label();
            label6 = new Label();
            btnLogOut = new Button();
            btnClear = new Button();
            btnUpdate = new Button();
            btnInsert = new Button();
            iconPictureBox1 = new FontAwesome.Sharp.IconPictureBox();
            pictureBox1 = new PictureBox();
            label10 = new Label();
            label11 = new Label();
            panel2 = new Panel();
            label13 = new Label();
            label12 = new Label();
            iconPictureBox2 = new FontAwesome.Sharp.IconPictureBox();
            pictureBox4 = new PictureBox();
            txtKh = new TextBox();
            label3 = new Label();
            btnBack = new Button();
            txtEn = new TextBox();
            label2 = new Label();
            label4 = new Label();
            txtSid = new TextBox();
            cbSex = new ComboBox();
            LsStaff = new ListBox();
            dtSbd = new DateTimePicker();
            cbPos = new ComboBox();
            label7 = new Label();
            groupBox1 = new GroupBox();
            txtKhn = new TextBox();
            txtSnk = new TextBox();
            label15 = new Label();
            label16 = new Label();
            txtProv = new TextBox();
            label14 = new Label();
            txtHn = new TextBox();
            txtSn = new TextBox();
            label8 = new Label();
            label9 = new Label();
            txtCn = new TextBox();
            txtPn = new TextBox();
            label17 = new Label();
            label18 = new Label();
            txtSa = new TextBox();
            label19 = new Label();
            dtHd = new DateTimePicker();
            label20 = new Label();
            ckSw = new CheckBox();
            btnUpload = new Button();
            picStaff = new PictureBox();
            txtSearch = new TextBox();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)picStaff).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(12, 87);
            label1.Name = "label1";
            label1.Size = new Size(108, 19);
            label1.TabIndex = 0;
            label1.Text = "Search Name :";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(282, 100);
            label5.Name = "label5";
            label5.Size = new Size(72, 19);
            label5.TabIndex = 0;
            label5.Text = "Staff ID :";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(282, 236);
            label6.Name = "label6";
            label6.Size = new Size(81, 19);
            label6.TabIndex = 0;
            label6.Text = "BirthDate:";
            // 
            // btnLogOut
            // 
            btnLogOut.BackColor = Color.FromArgb(128, 255, 255);
            btnLogOut.BackgroundImageLayout = ImageLayout.Center;
            btnLogOut.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnLogOut.ForeColor = Color.Black;
            btnLogOut.Location = new Point(696, 619);
            btnLogOut.Name = "btnLogOut";
            btnLogOut.Size = new Size(94, 37);
            btnLogOut.TabIndex = 3;
            btnLogOut.Text = "Log Out\r\n";
            btnLogOut.UseVisualStyleBackColor = false;
            // 
            // btnClear
            // 
            btnClear.BackColor = Color.FromArgb(128, 255, 255);
            btnClear.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnClear.ForeColor = Color.Black;
            btnClear.Location = new Point(341, 619);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(94, 37);
            btnClear.TabIndex = 3;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = false;
            // 
            // btnUpdate
            // 
            btnUpdate.BackColor = Color.FromArgb(128, 255, 255);
            btnUpdate.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnUpdate.ForeColor = Color.Black;
            btnUpdate.Location = new Point(178, 619);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(94, 37);
            btnUpdate.TabIndex = 3;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = false;
            // 
            // btnInsert
            // 
            btnInsert.BackColor = Color.FromArgb(128, 255, 255);
            btnInsert.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnInsert.ForeColor = Color.Black;
            btnInsert.Location = new Point(13, 619);
            btnInsert.Name = "btnInsert";
            btnInsert.Size = new Size(94, 37);
            btnInsert.TabIndex = 3;
            btnInsert.Text = "Insert";
            btnInsert.UseVisualStyleBackColor = false;
            // 
            // iconPictureBox1
            // 
            iconPictureBox1.BackColor = Color.FromArgb(255, 255, 128);
            iconPictureBox1.ForeColor = SystemColors.ControlText;
            iconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.Copyright;
            iconPictureBox1.IconColor = SystemColors.ControlText;
            iconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox1.IconSize = 25;
            iconPictureBox1.Location = new Point(141, 47);
            iconPictureBox1.Name = "iconPictureBox1";
            iconPictureBox1.Size = new Size(25, 26);
            iconPictureBox1.TabIndex = 7;
            iconPictureBox1.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(3, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(132, 73);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(172, 52);
            label10.Name = "label10";
            label10.Size = new Size(238, 17);
            label10.TabIndex = 9;
            label10.Text = "Copyright ISAD_M3_25_Group(Roza)";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Times New Roman", 20F, FontStyle.Regular, GraphicsUnit.Point);
            label11.Location = new Point(186, 3);
            label11.Name = "label11";
            label11.Size = new Size(202, 39);
            label11.TabIndex = 9;
            label11.Text = "Ticket's Form";
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(255, 255, 128);
            panel2.Controls.Add(label13);
            panel2.Controls.Add(label12);
            panel2.Controls.Add(iconPictureBox2);
            panel2.Controls.Add(pictureBox4);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(904, 76);
            panel2.TabIndex = 7;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Times New Roman", 20F, FontStyle.Regular, GraphicsUnit.Point);
            label13.Location = new Point(214, 9);
            label13.Name = "label13";
            label13.Size = new Size(181, 39);
            label13.TabIndex = 2;
            label13.Text = "Staff's Form";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(214, 56);
            label12.Name = "label12";
            label12.Size = new Size(221, 17);
            label12.TabIndex = 2;
            label12.Text = "Copyright ISAD_M3_Group5(2024)";
            // 
            // iconPictureBox2
            // 
            iconPictureBox2.BackColor = Color.FromArgb(255, 255, 128);
            iconPictureBox2.ForeColor = SystemColors.ControlText;
            iconPictureBox2.IconChar = FontAwesome.Sharp.IconChar.Copyright;
            iconPictureBox2.IconColor = SystemColors.ControlText;
            iconPictureBox2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox2.IconSize = 23;
            iconPictureBox2.Location = new Point(178, 50);
            iconPictureBox2.Name = "iconPictureBox2";
            iconPictureBox2.Size = new Size(30, 23);
            iconPictureBox2.TabIndex = 1;
            iconPictureBox2.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.BackColor = Color.FromArgb(255, 255, 128);
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(0, 0);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(163, 76);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 30;
            pictureBox4.TabStop = false;
            // 
            // txtKh
            // 
            txtKh.Font = new Font("Khmer OS Siemreap", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtKh.Location = new Point(401, 125);
            txtKh.Name = "txtKh";
            txtKh.Size = new Size(252, 35);
            txtKh.TabIndex = 13;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(282, 131);
            label3.Name = "label3";
            label3.Size = new Size(102, 19);
            label3.TabIndex = 12;
            label3.Text = "StaffNameKh";
            // 
            // btnBack
            // 
            btnBack.BackColor = Color.FromArgb(128, 255, 255);
            btnBack.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnBack.ForeColor = Color.Black;
            btnBack.Location = new Point(518, 619);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(94, 37);
            btnBack.TabIndex = 24;
            btnBack.Text = "Back";
            btnBack.UseVisualStyleBackColor = false;
            // 
            // txtEn
            // 
            txtEn.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtEn.Location = new Point(401, 168);
            txtEn.Name = "txtEn";
            txtEn.Size = new Size(252, 27);
            txtEn.TabIndex = 27;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(282, 174);
            label2.Name = "label2";
            label2.Size = new Size(105, 19);
            label2.TabIndex = 26;
            label2.Text = "StaffNameEn:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(282, 205);
            label4.Name = "label4";
            label4.Size = new Size(68, 19);
            label4.TabIndex = 28;
            label4.Text = "Gender :";
            // 
            // txtSid
            // 
            txtSid.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtSid.Location = new Point(401, 94);
            txtSid.Name = "txtSid";
            txtSid.ReadOnly = true;
            txtSid.Size = new Size(252, 27);
            txtSid.TabIndex = 31;
            // 
            // cbSex
            // 
            cbSex.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            cbSex.FormattingEnabled = true;
            cbSex.Items.AddRange(new object[] { "Male", "Female" });
            cbSex.Location = new Point(401, 199);
            cbSex.Name = "cbSex";
            cbSex.Size = new Size(252, 27);
            cbSex.TabIndex = 32;
            // 
            // LsStaff
            // 
            LsStaff.Font = new Font("Khmer OS Siemreap", 9F, FontStyle.Regular, GraphicsUnit.Point);
            LsStaff.FormattingEnabled = true;
            LsStaff.ItemHeight = 27;
            LsStaff.Location = new Point(13, 170);
            LsStaff.Name = "LsStaff";
            LsStaff.Size = new Size(228, 409);
            LsStaff.TabIndex = 34;
            // 
            // dtSbd
            // 
            dtSbd.CustomFormat = "yyyy/MM/dd";
            dtSbd.Location = new Point(401, 230);
            dtSbd.Name = "dtSbd";
            dtSbd.Size = new Size(252, 25);
            dtSbd.TabIndex = 35;
            // 
            // cbPos
            // 
            cbPos.FormattingEnabled = true;
            cbPos.Items.AddRange(new object[] { "Manager", "Cashier", "Customer Service", "IT", "Driver" });
            cbPos.Location = new Point(401, 261);
            cbPos.Name = "cbPos";
            cbPos.Size = new Size(252, 25);
            cbPos.TabIndex = 37;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label7.Location = new Point(282, 267);
            label7.Name = "label7";
            label7.Size = new Size(76, 19);
            label7.TabIndex = 36;
            label7.Text = "Position :";
            // 
            // groupBox1
            // 
            groupBox1.BackColor = SystemColors.GradientInactiveCaption;
            groupBox1.Controls.Add(txtKhn);
            groupBox1.Controls.Add(txtSnk);
            groupBox1.Controls.Add(label15);
            groupBox1.Controls.Add(label16);
            groupBox1.Controls.Add(txtProv);
            groupBox1.Controls.Add(label14);
            groupBox1.Controls.Add(txtHn);
            groupBox1.Controls.Add(txtSn);
            groupBox1.Controls.Add(label8);
            groupBox1.Controls.Add(label9);
            groupBox1.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            groupBox1.Location = new Point(282, 324);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(598, 160);
            groupBox1.TabIndex = 38;
            groupBox1.TabStop = false;
            groupBox1.Text = "Address";
            // 
            // txtKhn
            // 
            txtKhn.Location = new Point(132, 108);
            txtKhn.Name = "txtKhn";
            txtKhn.Size = new Size(126, 27);
            txtKhn.TabIndex = 41;
            // 
            // txtSnk
            // 
            txtSnk.Location = new Point(361, 108);
            txtSnk.Name = "txtSnk";
            txtSnk.Size = new Size(214, 27);
            txtSnk.TabIndex = 40;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label15.Location = new Point(285, 116);
            label15.Name = "label15";
            label15.Size = new Size(70, 19);
            label15.TabIndex = 39;
            label15.Text = "Sangkat :";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label16.Location = new Point(11, 116);
            label16.Name = "label16";
            label16.Size = new Size(57, 19);
            label16.TabIndex = 38;
            label16.Text = "Khann:";
            // 
            // txtProv
            // 
            txtProv.Location = new Point(132, 65);
            txtProv.Name = "txtProv";
            txtProv.Size = new Size(443, 27);
            txtProv.TabIndex = 37;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label14.Location = new Point(12, 73);
            label14.Name = "label14";
            label14.Size = new Size(104, 19);
            label14.TabIndex = 36;
            label14.Text = "Province\\City";
            // 
            // txtHn
            // 
            txtHn.Location = new Point(132, 26);
            txtHn.Name = "txtHn";
            txtHn.Size = new Size(126, 27);
            txtHn.TabIndex = 35;
            // 
            // txtSn
            // 
            txtSn.Location = new Point(361, 26);
            txtSn.Name = "txtSn";
            txtSn.Size = new Size(214, 27);
            txtSn.TabIndex = 34;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label8.Location = new Point(280, 34);
            label8.Name = "label8";
            label8.Size = new Size(75, 19);
            label8.TabIndex = 33;
            label8.Text = "Street No";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label9.Location = new Point(11, 34);
            label9.Name = "label9";
            label9.Size = new Size(83, 19);
            label9.TabIndex = 32;
            label9.Text = "House No:";
            // 
            // txtCn
            // 
            txtCn.Location = new Point(392, 501);
            txtCn.Name = "txtCn";
            txtCn.Size = new Size(174, 25);
            txtCn.TabIndex = 42;
            // 
            // txtPn
            // 
            txtPn.Location = new Point(693, 501);
            txtPn.Name = "txtPn";
            txtPn.Size = new Size(187, 25);
            txtPn.TabIndex = 41;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label17.Location = new Point(572, 507);
            label17.Name = "label17";
            label17.Size = new Size(115, 19);
            label17.TabIndex = 40;
            label17.Text = "Personal Num :";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label18.Location = new Point(282, 507);
            label18.Name = "label18";
            label18.Size = new Size(104, 19);
            label18.TabIndex = 39;
            label18.Text = "Contact Num:";
            // 
            // txtSa
            // 
            txtSa.Location = new Point(392, 546);
            txtSa.Name = "txtSa";
            txtSa.Size = new Size(174, 25);
            txtSa.TabIndex = 44;
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label19.Location = new Point(282, 552);
            label19.Name = "label19";
            label19.Size = new Size(60, 19);
            label19.TabIndex = 43;
            label19.Text = "Salary :";
            // 
            // dtHd
            // 
            dtHd.CustomFormat = "yyyy/MM/dd";
            dtHd.Location = new Point(392, 580);
            dtHd.Name = "dtHd";
            dtHd.Size = new Size(252, 25);
            dtHd.TabIndex = 46;
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label20.Location = new Point(282, 586);
            label20.Name = "label20";
            label20.Size = new Size(81, 19);
            label20.TabIndex = 45;
            label20.Text = "Hire Date:";
            // 
            // ckSw
            // 
            ckSw.AutoSize = true;
            ckSw.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            ckSw.Location = new Point(583, 546);
            ckSw.Name = "ckSw";
            ckSw.Size = new Size(104, 23);
            ckSw.TabIndex = 47;
            ckSw.Text = "Stop Work";
            ckSw.UseVisualStyleBackColor = true;
            // 
            // btnUpload
            // 
            btnUpload.BackColor = Color.Yellow;
            btnUpload.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnUpload.Location = new Point(696, 251);
            btnUpload.Name = "btnUpload";
            btnUpload.Size = new Size(161, 34);
            btnUpload.TabIndex = 48;
            btnUpload.Text = "SelectPhoto";
            btnUpload.UseVisualStyleBackColor = false;
            // 
            // picStaff
            // 
            picStaff.BackColor = SystemColors.ButtonHighlight;
            picStaff.Location = new Point(696, 94);
            picStaff.Name = "picStaff";
            picStaff.Size = new Size(161, 147);
            picStaff.SizeMode = PictureBoxSizeMode.StretchImage;
            picStaff.TabIndex = 33;
            picStaff.TabStop = false;
            // 
            // txtSearch
            // 
            txtSearch.Font = new Font("Khmer OS Siemreap", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtSearch.Location = new Point(12, 112);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(229, 35);
            txtSearch.TabIndex = 49;
            // 
            // StaffForm
            // 
            AutoScaleDimensions = new SizeF(8F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(904, 668);
            Controls.Add(txtSearch);
            Controls.Add(btnUpload);
            Controls.Add(ckSw);
            Controls.Add(dtHd);
            Controls.Add(label20);
            Controls.Add(txtSa);
            Controls.Add(label19);
            Controls.Add(txtCn);
            Controls.Add(txtPn);
            Controls.Add(label17);
            Controls.Add(label18);
            Controls.Add(groupBox1);
            Controls.Add(cbPos);
            Controls.Add(label7);
            Controls.Add(dtSbd);
            Controls.Add(LsStaff);
            Controls.Add(picStaff);
            Controls.Add(cbSex);
            Controls.Add(txtSid);
            Controls.Add(label4);
            Controls.Add(txtEn);
            Controls.Add(label2);
            Controls.Add(btnBack);
            Controls.Add(txtKh);
            Controls.Add(label3);
            Controls.Add(panel2);
            Controls.Add(btnInsert);
            Controls.Add(btnUpdate);
            Controls.Add(btnClear);
            Controls.Add(btnLogOut);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label1);
            Font = new Font("Times New Roman", 9F, FontStyle.Regular, GraphicsUnit.Point);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "StaffForm";
            Text = "Staff's Form";
            Load += StaffForm_Load;
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)picStaff).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private Label label1;
        private Label label5;
        private Label label6;
        private Button btnLogOut;
        private Button btnClear;
        private Button btnUpdate;
        private Button btnInsert;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox1;
#pragma warning disable CS0169 // The field 'Ticket.panel1' is never used
#pragma warning restore CS0169 // The field 'Ticket.panel1' is never used
        private Label label10;
        private PictureBox pictureBox1;
        private Label label11;
#pragma warning disable CS0649 // Field 'Ticket.panel1_Paint' is never assigned to, and will always have its default value null
        private Panel panel2;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox2;
        private Label label13;
        private Label label12;
        private TextBox txtKh;
        private Label label3;
        private Button btnBack;
        private TextBox txtEn;
        private Label label2;
        private Label label4;
        private PictureBox pictureBox4;
        private TextBox txtSid;
        private ComboBox cbSex;
        private ListBox LsStaff;
        private DateTimePicker dtSbd;
        private ComboBox cbPos;
        private Label label7;
        private GroupBox groupBox1;
        private TextBox txtHn;
        private TextBox txtSn;
        private Label label8;
        private Label label9;
        private TextBox txtKhn;
        private TextBox txtSnk;
        private Label label15;
        private Label label16;
        private TextBox txtProv;
        private Label label14;
        private TextBox txtCn;
        private TextBox txtPn;
        private Label label17;
        private Label label18;
        private TextBox txtSa;
        private Label label19;
        private DateTimePicker dtHd;
        private Label label20;
        private CheckBox ckSw;
        private Button btnUpload;
        private PictureBox picStaff;
        private TextBox txtSearch;
    }
}