﻿using Microsoft.Data.SqlClient;
using Microsoft.VisualBasic.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAGTMS;

public partial class LoginForm : Form
{
    private DatabaseConfigurationForm databaseConfigurationFormReference;
    public LoginForm(DatabaseConfigurationForm databaseConfigurationForm)
    {
        InitializeComponent();
        Program.ConnectToDB();
        btnLogin.Click += DoClickLogin;
        ckShow.CheckedChanged += DoClickShowPassword;
        this.databaseConfigurationFormReference = databaseConfigurationForm;
        this.FormClosed += new FormClosedEventHandler(LoginForm_FormClosed);
    }

    private void DoClickLogin(object? sender, EventArgs e)
    {
        if (txtUserName.Text == "" && txtPassword.Text == "")
        {
            MessageBox.Show($"Invalid Username and Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        using (SqlCommand cmd = new SqlCommand("spLoginUser", Program.Connection))
        {
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@name", txtUserName.Text.Trim());
            cmd.Parameters.AddWithValue("@password", txtPassword.Text.Trim());

            try
            {

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        string userName = reader["UserName"].ToString();
                        MessageBox.Show($"Welcome {userName}", "Log in Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Hide();
                        (new MainForm(databaseConfigurationFormReference, this)).Show();
                        txtUserName.Clear();
                        txtPassword.Clear();
                        ckShow.Checked = false;
                    }
                    else
                    {
                        MessageBox.Show("Invalid credentials. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}", "Logging", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            finally
            {
                cmd.Dispose();
            }
        }
    }
    private void DoClickShowPassword(object? sender, EventArgs e)
    {
        if (ckShow.Checked)
        {
            txtPassword.UseSystemPasswordChar = false;
        }
        else
        {
            txtPassword.UseSystemPasswordChar = true;
        }
    }
    private void LoginForm_FormClosed(object sender, FormClosedEventArgs e)
    {
        databaseConfigurationFormReference.Close();

    }
}
