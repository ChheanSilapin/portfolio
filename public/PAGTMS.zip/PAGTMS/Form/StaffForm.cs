﻿using Microsoft.VisualBasic.ApplicationServices;
using PAGTMS.Models;
using PAGTMS.Ultils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity.Infrastructure.Annotations;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAGTMS;

public partial class StaffForm : Form
{
    private MainForm mainFormReference;
    string? imgLocation = "";
    Staff? effectedStaff = null;
    List<string> ListBoxStaff = new List<string>();
    int StaffCount = 0;
    int IndexOfUpdateStaff;
    private LoginForm loginFormReference;
    public StaffForm(MainForm mainForm, LoginForm loginForm)
    {
        InitializeComponent();
        mainFormReference = mainForm;
        loginFormReference = loginForm;
        this.FormClosed += new FormClosedEventHandler((_, _) => mainFormReference.Show());
        btnInsert.Click += DoClickInsertStaff;
        btnUpload.Click += DoClickUploadPhoto;
        btnClear.Click += DoClickNewFormInput;
        btnUpdate.Click += DoClickUpdateStaff;
        btnBack.Click += (_, _) => this.Close();
        LsStaff.SelectedIndexChanged += Select_Handling_Staff;
        txtSearch.TextChanged += SearchChangedFunc;
        dtSbd.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
        dtHd.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
        ListBoxStaff.Clear();
        btnLogOut.Click += (_, _) => { this.Hide(); loginFormReference.Show(); };
    }
    private void SearchChangedFunc(object? sender, EventArgs e)
    {
        if (string.IsNullOrEmpty(txtSearch.Text) == false)
        {
            LsStaff.Items.Clear();
            foreach (string staff in ListBoxStaff)

            {
                string[] splitText = staff.Split('.');
                if (splitText[1].Trim().StartsWith(txtSearch.Text))
                {
                    LsStaff.Items.Add(staff);
                }
            }
        }
        else if (txtSearch.Text == "")
        {
            LsStaff.Items.Clear();
            foreach (string staff in ListBoxStaff)
            {
                LsStaff.Items.Add(staff);
            }
        }
    }
    private void DoClickUpdateStaff(object? sender, EventArgs e)
    {
        byte[]? image = null;

        if (effectedStaff != null)
        {
            effectedStaff.StaffNameKH = txtKh.Text.Trim();
            effectedStaff.StaffNameEN = txtEn.Text.Trim();
            effectedStaff.Gender = cbSex.SelectedItem.ToString();
            effectedStaff.BirthDate = dtSbd.Value;
            effectedStaff.StaffPosition = cbPos.SelectedItem.ToString();
            effectedStaff.HouseNo = txtHn.Text.Trim();
            effectedStaff.StreetNo = txtSn.Text.Trim();
            effectedStaff.Sangkat = txtSnk.Text.Trim();
            effectedStaff.Khann = txtKhn.Text.Trim();
            effectedStaff.Province = txtProv.Text.Trim();
            effectedStaff.ContactNumber = txtCn.Text.Trim();
            effectedStaff.PersonalNumber = txtPn.Text.Trim();
            effectedStaff.Salary = decimal.Parse(txtSa.Text.Trim());
            effectedStaff.HiredDate = dtHd.Value;
            effectedStaff.StopWork = ckSw.Checked;
            if (picStaff.Image != null)
            {
                Image images = picStaff.Image;
                MemoryStream ms =  new MemoryStream();
                images.Save(ms, ImageFormat.Png);
                image = ms.ToArray();
                //FileStream stream = new FileStream(imgLocation, FileMode.Open, FileAccess.Read);
                //BinaryReader breader = new BinaryReader(stream);
                //image = breader.ReadBytes((int)stream.Length);
            }
            effectedStaff.Photo = image;
            try
            {
                var result = StaffFunc.UpdateStaff(Program.Connection, effectedStaff);
                if (result == true)
                    MessageBox.Show($"Successfully Updated a Staff!", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                foreach (string checkstaff in ListBoxStaff)
                {
                    string[] splitText = checkstaff.Split('.');
                    if (splitText[0].Trim().Equals(effectedStaff.StaffID.ToString()))
                    {
                        IndexOfUpdateStaff = ListBoxStaff.IndexOf(checkstaff);
                        ListBoxStaff.Remove(checkstaff);
                        break;
                    }
                }
                ListBoxStaff.Insert(IndexOfUpdateStaff, $"{effectedStaff.StaffID}.{effectedStaff.StaffNameKH}");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Update Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }

        }
        LoadingDataStaff();

    }
    private void DoClickInsertStaff(object? sender, EventArgs e)
    {
        byte[]? images = null;
        if (int.TryParse(txtSid.Text, out int staffID) == false)
        {
            MessageBox.Show("Staff ID is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (txtKh.Text == "")
        {
            MessageBox.Show("Staff Name KH is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (txtEn.Text == "")
        {
            MessageBox.Show("Staff Name EN is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (cbSex.SelectedItem == null)
        {
            MessageBox.Show("Staff Gender is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (txtHn.Text == "")
        {
            MessageBox.Show("Staff HouseNo is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (txtSn.Text == "")
        {
            MessageBox.Show("Staff StreetNo is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (txtSnk.Text == "")
        {
            MessageBox.Show("Staff Sangkat is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (txtKhn.Text == "")
        {
            MessageBox.Show("Staff Khann is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (txtProv.Text == "")
        {
            MessageBox.Show("Staff Province is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (txtCn.Text == "")
        {
            MessageBox.Show("Staff Contact Number is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (cbPos.Text == "")
        {
            MessageBox.Show("Staff Position is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (dtSbd.Text == "")
        {
            MessageBox.Show("Staff BirthDate is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (dtHd.Text == "")
        {
            MessageBox.Show("Staff Hired Date is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (txtSa.Text == "")
        {
            MessageBox.Show("Staff Salary is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (picStaff.Image == null)
        {
            MessageBox.Show("Staff Image is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (decimal.TryParse(txtSa.Text, out decimal staffSalary) == false)
        {
            MessageBox.Show("Staff Salary is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
        }
        if (!string.IsNullOrWhiteSpace(imgLocation))
        {
            FileStream stream = new FileStream(imgLocation, FileMode.Open, FileAccess.Read);
            BinaryReader breader = new BinaryReader(stream);
            images = breader.ReadBytes((int)stream.Length);
        }
        Staff newStaff = new Staff()
        {
            StaffID = staffID,
            StaffNameKH = txtKh.Text.Trim(),
            StaffNameEN = txtEn.Text.Trim(),
            Gender = cbSex.SelectedItem.ToString(),
            BirthDate = dtSbd.Value,
            StreetNo = txtSn.Text.Trim(),
            HouseNo = txtHn.Text.Trim(),
            Sangkat = txtSnk.Text.Trim(),
            Khann = txtKhn.Text.Trim(),
            Province = txtProv.Text.Trim(),
            ContactNumber = txtCn.Text.Trim(),
            PersonalNumber = txtPn.Text.Trim(),
            Salary = staffSalary,
            StaffPosition = cbPos.SelectedItem.ToString(),
            HiredDate = dtHd.Value,
            Photo = images,
            StopWork = ckSw.Checked,
        };
        try
        {
            var result = StaffFunc.AddStaff(Program.Connection, newStaff);
            if (result == true)
                MessageBox.Show($"Successfully Inserted a New Staff!", "Inserted", MessageBoxButtons.OK, MessageBoxIcon.Information);
            ListBoxStaff.Add($"{txtSid.Text}.{newStaff.StaffNameKH}");
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Submitting", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        LoadingDataStaff();
    }

    private void DoClickUploadPhoto(object? sender, EventArgs e)
    {
        OpenFileDialog dialog = new OpenFileDialog();
        dialog.Filter = " png files(*.png)|*.png|jpg files(*.jpg)|*.jpg|All files(*.*)|*.*";
        if (dialog.ShowDialog() == DialogResult.OK)
        {
            imgLocation = dialog.FileName.ToString();
            picStaff.ImageLocation = imgLocation;
        }
    }
    private void Select_Handling_Staff(object? sender, EventArgs e)
    {

        if (LsStaff.SelectedItem != null)
        {
            string? staffData = LsStaff.SelectedItems[0].ToString();
            if (staffData == null) return;
            string[] tempData = staffData.Split('.');
            try
            {
                effectedStaff = StaffFunc.GetOneStaff(Program.Connection, int.Parse(tempData[0].Trim()));

                txtSid.Text = effectedStaff.StaffID.ToString();
                txtKh.Text = effectedStaff.StaffNameKH;
                txtEn.Text = effectedStaff.StaffNameEN;
                cbSex.Text = effectedStaff.Gender;
                txtHn.Text = effectedStaff.HouseNo;
                txtSn.Text = effectedStaff.StreetNo;
                txtSnk.Text = effectedStaff.Sangkat;
                txtKhn.Text = effectedStaff.Khann;
                txtProv.Text = effectedStaff.Province;
                txtSa.Text = effectedStaff.Salary.ToString();
                ckSw.Checked = effectedStaff.StopWork;
                txtCn.Text = effectedStaff.ContactNumber;
                txtPn.Text = effectedStaff.PersonalNumber;
                cbPos.Text = effectedStaff.StaffPosition;
                dtSbd.Value = (DateTime)effectedStaff.BirthDate;
                dtHd.Value = (DateTime)effectedStaff.HiredDate;
                if (effectedStaff.Photo == null)
                {
                    picStaff.Image = null;
                }
                else
                {
                    MemoryStream ms = new MemoryStream(effectedStaff.Photo);
                    picStaff.Image = Image.FromStream(ms);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}");
            }

        }
    }
    private void StaffForm_Load(object sender, EventArgs e)
    {
        LoadingDataStaff();
        txtSid.Text = (StaffCount + 1).ToString();
        foreach (string staff in LsStaff.Items)
        {
            ListBoxStaff.Add(staff);
            txtSearch.CharacterCasing = CharacterCasing.Lower;
        }
    }
    private void LoadingDataStaff()
    {

        try
        {
            var result = StaffFunc.GetAllStaff(Program.Connection);
            if (result.LastOrDefault() != null) { StaffCount = result.LastOrDefault().StaffID; }
            else { StaffCount = 0; }

            LsStaff.Items.Clear();
            foreach (var staff in result)
            {

                LsStaff.Items.Add($"{staff.StaffID}. {staff.StaffNameKH}");

            }
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Retriving students", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
    private void DoClickNewFormInput(object? sender, EventArgs e)
    {
        txtSid.Text = (StaffCount + 1).ToString();
        txtKh.Clear();
        txtEn.Clear();
        cbSex.SelectedItem = null;
        cbPos.SelectedItem = null;
        dtHd.ResetText();
        dtSbd.ResetText();
        txtHn.Clear();
        txtSn.Clear();
        txtSnk.Clear();
        txtProv.Clear();
        txtKhn.Clear();
        txtCn.Clear();
        txtPn.Clear();
        txtSa.Clear();
        picStaff.Image = null;
        ckSw.Checked = false;
        imgLocation = "";
    }
}

