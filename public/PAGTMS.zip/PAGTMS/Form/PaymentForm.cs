﻿using Microsoft.VisualBasic.ApplicationServices;
using PAGTMS.Models;
using PAGTMS.Ultils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAGTMS;

public partial class PaymentForm : Form
{
    MainForm mainFormReference;
    Customer? effectedCustomer = null;
    Staff? effectedStaff = null;
    Payment? effectedPayment = null;
    List<string> ListPayment = new List<string>();
    int PaymentCount = 0;
    int IndexOfUpdatePayment;
    private LoginForm loginFormReference;
    public PaymentForm(MainForm mainForm, LoginForm loginForm)
    {
        InitializeComponent();
        mainFormReference = mainForm;
        loginFormReference = loginForm;
        this.FormClosed += new FormClosedEventHandler((_, _) => mainFormReference.Show());
        btnClear.Click += DoClickNewFormInput;
        btnBack.Click += (_, _) => this.Close();
        cbStaffID.SelectedValueChanged += Select_Handling_StaffID;
        cbCustomerID.SelectedValueChanged += Select_Handling_CusID;
        LsPayment.SelectedValueChanged += Select_Handling_Payment;
        btnInsert.Click += DoClickInsertPayment;
        btnUpdate.Click += DoClickUpdatePayment;
        txtSearch.TextChanged += SearchFunction;
        dtPd.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
        ListPayment.Clear();
        btnLogOut.Click += (_, _) => { this.Hide(); loginFormReference.Show(); };
    }
    private void SearchFunction(object? sender, EventArgs e)
    {
        if (string.IsNullOrEmpty(txtSearch.Text) == false)
        {
            LsPayment.Items.Clear();
            foreach (string payment in ListPayment)

            {
                string[] splitText = payment.Split('.');
                if (splitText[1].Trim().StartsWith(txtSearch.Text, StringComparison.OrdinalIgnoreCase))
                {
                    LsPayment.Items.Add(payment);
                }
            }
        }
        else if (txtSearch.Text == "")
        {
            LsPayment.Items.Clear();
            foreach (string payment in ListPayment)
            {
                LsPayment.Items.Add(payment);
            }
        }
    }
    private void DoClickUpdatePayment(object? sender, EventArgs e)
    {

        if (effectedPayment != null)
        {
            effectedPayment.PaymentID = int.Parse(txtPid.Text.Trim());
            effectedPayment.PayDate = dtPd.Value;
            effectedPayment.PaidAmount = decimal.Parse(txtPamt.Text.Trim());
            effectedPayment.CustomerID = int.Parse(cbCustomerID.SelectedValue.ToString().Trim());
            effectedPayment.CustomerName = txtCusname.Text.Trim();
            effectedPayment.CustomerContactInfo = txtCusInfo.Text.Trim();
            effectedPayment.StaffID = int.Parse(cbStaffID.SelectedValue.ToString().Trim());
            effectedPayment.StaffNameKh = txtStna.Text.Trim();
            effectedPayment.StaffPosition = txtStpos.Text.Trim();
            try
            {
                var result = PaymentFunc.UpdatePayment(Program.Connection, effectedPayment);
                if (result == true)
                    MessageBox.Show($"Successfully updated!!", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                foreach (string checkpayment in ListPayment)
                {
                    string[] splitText = checkpayment.Split('.');
                    if (splitText[0].Trim().Equals(effectedPayment.PaymentID.ToString()))
                    {
                        IndexOfUpdatePayment = ListPayment.IndexOf(checkpayment);
                        ListPayment.Remove(checkpayment);
                        break;
                    }
                }
                ListPayment.Insert(IndexOfUpdatePayment, $"{effectedPayment.PaymentID}.{effectedPayment.CustomerName}");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Update Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
        LoadingDataPayment();
    }
    private void DoClickInsertPayment(object? sender, EventArgs e)
    {
        if (int.TryParse(txtPid.Text, out int paymentID) == false)
        {
            MessageBox.Show("Payment ID is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (dtPd.Text == "")
        {
            MessageBox.Show("PayDate is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (decimal.TryParse(txtPamt.Text, out decimal paidAmount) == false)
        {
            MessageBox.Show("PaidAmount is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
        }
        if (cbStaffID.SelectedItem == null)
        {
            MessageBox.Show("Staff Gender is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (txtStna.Text == "")
        {
            MessageBox.Show("Staff Name KH is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (txtStpos.Text == "")
        {
            MessageBox.Show("Staff Position is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        string? customerID = cbCustomerID.SelectedItem.ToString();
        if (customerID == null) return;
        string? staffID = cbStaffID.SelectedItem.ToString();
        if (staffID == null) return;
        Payment newPayment = new Payment()
        {
            PaymentID = paymentID,
            PayDate = dtPd.Value,
            PaidAmount = paidAmount,
            CustomerID = int.Parse(customerID.Trim()),
            CustomerName = txtCusname.Text.Trim(),
            CustomerContactInfo = txtCusInfo.Text.Trim(),
            StaffID = int.Parse(staffID.Trim()),
            StaffNameKh = txtStna.Text.Trim(),
            StaffPosition = txtStpos.Text.Trim(),
        };
        try
        {
            PaymentFunc.AddPayment(Program.Connection, newPayment);
            MessageBox.Show("Successfully Inserted!!", "Inserted", MessageBoxButtons.OK, MessageBoxIcon.Information);
            ListPayment.Add($"{txtPid.Text}.{newPayment.CustomerName}");
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Submitting", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        LoadingDataPayment();
    }
    private void Select_Handling_Payment(object? sender, EventArgs e)
    {
        if (LsPayment.SelectedItem != null)
        {
            string? paymentData = LsPayment.SelectedItems[0].ToString();
            if (paymentData == null) return;
            string[] tempData = paymentData.Split('.');
            try
            {
                effectedPayment = PaymentFunc.GetOnePayment(Program.Connection, int.Parse(tempData[0].Trim()));
                txtPid.Text = effectedPayment.PaymentID.ToString();
                dtPd.Value = (DateTime)effectedPayment.PayDate;
                txtPamt.Text = effectedPayment.PaidAmount.ToString();
                cbCustomerID.SelectedItem = effectedPayment.CustomerID.ToString();
                txtCusname.Text = effectedPayment.CustomerName;
                txtCusInfo.Text = effectedPayment.CustomerContactInfo;
                cbStaffID.SelectedItem = effectedPayment.StaffID.ToString();
                txtStna.Text = effectedPayment.StaffNameKh;
                txtStpos.Text = effectedPayment.StaffPosition;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}");
            }
        }
    }
    private void Select_Handling_CusID(object? sender, EventArgs e)
    {
        if (cbCustomerID.SelectedItem != null)
        {
            string? customerID = cbCustomerID.SelectedItem.ToString();
            if (customerID == null) return;
            try
            {
                effectedCustomer = CustomerFunc.GetOneCustomer(Program.Connection, int.Parse(customerID.Trim()));
                txtCusname.Text = effectedCustomer.CustomerName;
                txtCusInfo.Text = effectedCustomer.CustomerContactInfo;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}");
            }
        }
    }
    private void Select_Handling_StaffID(object? sender, EventArgs e)
    {
        if (cbStaffID.SelectedItem != null)
        {
            string? staffID = cbStaffID.SelectedItem.ToString();
            if (staffID == null) return;
            try
            {
                effectedStaff = StaffFunc.GetOneStaff(Program.Connection, int.Parse(staffID.Trim()));
                txtStna.Text = effectedStaff.StaffNameKH;
                txtStpos.Text = effectedStaff.StaffPosition;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}");
            }
        }
    }
    private void DoClickNewFormInput(object? sender, EventArgs e)
    {
        txtPid.Text = (PaymentCount + 1).ToString();
        dtPd.ResetText();
        txtPamt.Clear();
        cbCustomerID.SelectedItem = null;
        txtCusname.Clear();
        txtCusInfo.Clear();
        cbStaffID.SelectedItem = null;
        txtStna.Clear();
        txtStpos.Clear();
    }
    private void PaymentForm_Load(object sender, EventArgs e)
    {
        LoadingDataStaffID();
        LoadingDataCustomerID();
        LoadingDataPayment();
        txtPid.Text = (PaymentCount + 1).ToString();
        foreach (string payment in LsPayment.Items)
        {
            ListPayment.Add(payment);
            txtSearch.CharacterCasing = CharacterCasing.Normal;
        }
    }
    private void LoadingDataStaffID()
    {
        try
        {
            var result = StaffFunc.GetAllStaff(Program.Connection);
            List<string> ls = new List<string>();
            foreach (var staff in result)
            {
                ls.Add(staff.StaffID.ToString());

            }
            cbStaffID.DataSource = ls;
            cbStaffID.SelectedIndex = -1;
            txtStna.Clear();
            txtStpos.Clear();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Retriving Staff", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
    private void LoadingDataCustomerID()
    {
        try
        {
            var result = CustomerFunc.GetAllCustomer(Program.Connection);
            List<string> ls = new List<string>();
            foreach (var customer in result)
            {
                ls.Add(customer.CustomerID.ToString());

            }
            cbCustomerID.DataSource = ls;
            cbCustomerID.SelectedIndex = -1;
            txtCusname.Clear();
            txtCusInfo.Clear();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Retriving User", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void LoadingDataPayment()
    {
        try
        {
            var result = PaymentFunc.GetAllPayment(Program.Connection);
            if (result.LastOrDefault() != null) { PaymentCount = result.LastOrDefault().PaymentID; }
            else { PaymentCount = 0; }
            LsPayment.Items.Clear();
            foreach (var payment in result)
            {
                LsPayment.Items.Add($"{payment.PaymentID}.{payment.CustomerName}");
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Retriving Payment", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }


}
