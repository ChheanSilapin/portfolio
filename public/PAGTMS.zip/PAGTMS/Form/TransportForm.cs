﻿using PAGTMS.Models;
using PAGTMS.Ultils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAGTMS
{
    public partial class TransportForm : Form
    {
        private MainForm mainFormReference;
        Customer? effectedCustomer = null;
        Staff? effectedStaff = null;
        Route? effectedRoute = null;
        Transport? effectedTransport = null;
        List<DataGridViewRow> Datatransport = new List<DataGridViewRow>();
        int TransportCount = 0;
        private LoginForm loginFormReference;
        public TransportForm(MainForm mainForm, LoginForm loginForm)
        {
            InitializeComponent();
            mainFormReference = mainForm;
            loginFormReference = loginForm;
            this.FormClosed += new FormClosedEventHandler((_, _) => mainFormReference.Show());
            btnClear.Click += DoClickNewFormInput;
            btnBack.Click += (_, _) => this.Close();
            cbStaffID.SelectedValueChanged += Select_Handling_StaffID;
            cbRouteID.SelectedValueChanged += Select_Handling_RouteID;
            cbCustomerID.SelectedValueChanged += Select_Handling_CusID;
            btnInsert.Click += DoClickInsertTransport;
            btnUpdate.Click += DoClickUpdateTransport;
            dgvTransport.Click += Select_Handling_Transport;
            txtSearch.TextChanged += SearchFuntion;
            dtTd.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            Datatransport.Clear();
            btnLogOut.Click += (_, _) => { this.Hide(); loginFormReference.Show(); };
        }

        private void SearchFuntion(object? sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtSearch.Text) == false)
            {
                dgvTransport.Rows.Clear();
                foreach (DataGridViewRow transport in Datatransport)
                {
                    if (transport.Cells[0].Value.ToString().StartsWith(txtSearch.Text))
                    {
                        dgvTransport.Rows.Add(transport);
                    }
                }
            }
            else if (txtSearch.Text == "")
            {
                dgvTransport.Rows.Clear();
                foreach (DataGridViewRow transport in Datatransport)
                {
                    dgvTransport.Rows.Add(transport);
                }
            }

        }

        private void DoClickUpdateTransport(object? sender, EventArgs e)
        {
            if (effectedTransport != null)
            {
                effectedTransport.TransportID = int.Parse(txtTid.Text.Trim());
                effectedTransport.TransportDate = dtTd.Value;
                effectedTransport.TransportStatus = cbStatus.SelectedItem.ToString();
                effectedTransport.CustomerID = int.Parse(cbCustomerID.SelectedValue.ToString().Trim());
                effectedTransport.CustomerContactInfo = txtCusInfo.Text.Trim();
                effectedTransport.RouteID = int.Parse(cbRouteID.SelectedValue.ToString().Trim());
                effectedTransport.Destination = txtDes.Text.Trim();
                effectedTransport.StaffID = int.Parse(cbStaffID.SelectedValue.ToString().Trim());
                effectedTransport.StaffPosition = txtStpos.Text.Trim();
                try
                {
                    var result = TransportFunc.UpdateTransport(Program.Connection, effectedTransport);
                    if (result == true)
                        MessageBox.Show($"Successfully Updated a Transport!", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    DataGridViewRow tempDataGridViewRow = new DataGridViewRow();
                    tempDataGridViewRow.CreateCells(dgvTransport);
                    tempDataGridViewRow.Cells[0].Value = effectedTransport.TransportID;
                    tempDataGridViewRow.Cells[1].Value = effectedTransport.TransportDate;
                    tempDataGridViewRow.Cells[2].Value = effectedTransport.TransportStatus;
                    tempDataGridViewRow.Cells[3].Value = effectedTransport.CustomerID;
                    tempDataGridViewRow.Cells[4].Value = effectedTransport.CustomerContactInfo;
                    tempDataGridViewRow.Cells[5].Value = effectedTransport.RouteID;
                    tempDataGridViewRow.Cells[6].Value = effectedTransport.Destination;
                    tempDataGridViewRow.Cells[7].Value = effectedTransport.StaffID;
                    tempDataGridViewRow.Cells[8].Value = effectedTransport.StaffPosition;
                    foreach (DataGridViewRow checkTicket in Datatransport)
                    {
                        if (int.Parse(checkTicket.Cells[0].Value.ToString()) == effectedTransport.TransportID)
                        {
                            checkTicket.Cells[1].Value = tempDataGridViewRow.Cells[1].Value;
                            checkTicket.Cells[2].Value = tempDataGridViewRow.Cells[2].Value;
                            checkTicket.Cells[3].Value = tempDataGridViewRow.Cells[3].Value;
                            checkTicket.Cells[4].Value = tempDataGridViewRow.Cells[4].Value;
                            checkTicket.Cells[5].Value = tempDataGridViewRow.Cells[5].Value;
                            checkTicket.Cells[6].Value = tempDataGridViewRow.Cells[6].Value;
                            checkTicket.Cells[7].Value = tempDataGridViewRow.Cells[7].Value; 
                            checkTicket.Cells[8].Value = tempDataGridViewRow.Cells[8].Value;
                            break;
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Update Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
            LoadingDataTransport();
        }

        private void DoClickInsertTransport(object? sender, EventArgs e)
        {
            if (int.TryParse(txtTid.Text, out int transportID) == false)
            {
                MessageBox.Show("Transport ID is required", "Creating",
                MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
            if (dtTd.Text == "")
            {
                MessageBox.Show("TransportDate is required", "Creating",
                MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
            if (cbStatus.Text == "")
            {
                MessageBox.Show("TransportStatus is required", "Creating",
                MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
            if (cbCustomerID.SelectedItem == null)
            {
                MessageBox.Show("Customer ID is required", "Creating",
                MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
            if (txtCusInfo.Text == "")
            {
                MessageBox.Show("CustomerInfo is required", "Creating",
                MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
            if (cbRouteID.SelectedItem == null)
            {
                MessageBox.Show("Route ID is required", "Creating",
                MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
            if (cbStaffID.SelectedItem == null)
            {
                MessageBox.Show("Staff IDs is required", "Creating",
                MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
            string? customerID = cbCustomerID.SelectedItem.ToString();
            if (customerID == null) return;

            string? routeID = cbRouteID.SelectedItem.ToString();
            if (routeID == null) return;

            string? staffID = cbStaffID.SelectedItem.ToString();
            if (staffID == null) return;
            DateTime trandate = dtTd.Value;
            Transport newTransport = new Transport()
            {
                TransportID = transportID,
                TransportDate = trandate,
                TransportStatus = cbStatus.Text.Trim(),
                CustomerID = int.Parse(customerID.Trim()),
                CustomerContactInfo = txtCusInfo.Text.Trim(),
                RouteID = int.Parse(routeID.Trim()),
                Destination = txtDes.Text.Trim(),
                StaffID = int.Parse(staffID.Trim()),
                StaffPosition = txtStpos.Text.Trim(),
            };
            try
            {
                TransportFunc.AddTransport(Program.Connection, newTransport);
                MessageBox.Show($"Successfully Inserted!!", "Inserted", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DataGridViewRow tempDataGridViewRow = new DataGridViewRow();
                tempDataGridViewRow.CreateCells(dgvTransport);
                tempDataGridViewRow.Cells[0].Value = txtTid.Text;
                tempDataGridViewRow.Cells[1].Value = newTransport.TransportDate;
                tempDataGridViewRow.Cells[2].Value = newTransport.TransportStatus;
                tempDataGridViewRow.Cells[3].Value = cbCustomerID.Text;
                tempDataGridViewRow.Cells[4].Value = newTransport.CustomerContactInfo;
                tempDataGridViewRow.Cells[5].Value = cbRouteID.Text;
                tempDataGridViewRow.Cells[6].Value = newTransport.Destination;
                tempDataGridViewRow.Cells[7].Value = cbStaffID;
                tempDataGridViewRow.Cells[8].Value = newTransport.StaffPosition;
                Datatransport.Add(tempDataGridViewRow);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Submitting", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            LoadingDataTransport();
        }
        private void Select_Handling_Transport(object? sender, EventArgs e)
        {
            if (dgvTransport.CurrentRow == null) return;
            int id = (int)dgvTransport.CurrentRow.Cells[0].Value;
            try
            {

                effectedTransport = TransportFunc.GetOneTransport(Program.Connection, id);
                txtTid.Text = effectedTransport.TransportID.ToString();
                dtTd.Value = (DateTime)effectedTransport.TransportDate;
                cbStatus.Text = effectedTransport.TransportStatus;
                cbCustomerID.Text = effectedTransport.CustomerID.ToString();
                txtCusInfo.Text = effectedTransport.CustomerContactInfo;
                cbRouteID.Text = effectedTransport.RouteID.ToString();
                txtDes.Text = effectedTransport.Destination;
                cbStaffID.Text = effectedTransport.StaffID.ToString();
                txtStpos.Text = effectedTransport.StaffPosition;

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Here: {ex.Message}");
            }
        }
        private void Select_Handling_CusID(object? sender, EventArgs e)
        {
            if (cbCustomerID.SelectedItem != null)
            {
                string? customerID = cbCustomerID.SelectedItem.ToString();
                if (customerID == null) return;
                try
                {
                    effectedCustomer = CustomerFunc.GetOneCustomer(Program.Connection, int.Parse(customerID.Trim()));
                    txtCusInfo.Text = effectedCustomer.CustomerContactInfo;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"{ex.Message}");
                }
            }
        }

        private void Select_Handling_RouteID(object? sender, EventArgs e)
        {
            if (cbRouteID.SelectedItem != null)
            {
                string? routeID = cbRouteID.SelectedItem.ToString();
                if (routeID == null) return;
                try
                {
                    effectedRoute = RouteFunc.GetOneRoute(Program.Connection, int.Parse(routeID.Trim()));
                    txtDes.Text = effectedRoute.Destination;
                }
                catch (Exception ex) { MessageBox.Show($"{ex.Message}"); }
            }
        }

        private void Select_Handling_StaffID(object? sender, EventArgs e)
        {
            if (cbStaffID.SelectedItem != null)
            {
                string? staffID = cbStaffID.SelectedItem.ToString();
                if (staffID == null) return;
                try
                {
                    effectedStaff = StaffFunc.GetOneStaff(Program.Connection, int.Parse(staffID.Trim()));
                    txtStpos.Text = effectedStaff.StaffPosition;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"{ex.Message}");
                }
            }
        }

        private void DoClickNewFormInput(object? sender, EventArgs e)
        {
            txtTid.Text = (TransportCount + 1).ToString();
            dtTd.ResetText();
            cbStatus.ResetText();
            cbCustomerID.SelectedItem = null;
            txtCusInfo.Clear();
            cbRouteID.SelectedItem = null;
            txtDes.Clear();
            cbStaffID.SelectedItem = null;
            txtStpos.Clear();
        }
        private void TransportForm_Load(object sender, EventArgs e)
        {

            LoadingDataCustomerID();
            LoadingDataRouteID();
            LoadingDataStaffID();
            LoadingDataTransport();
            txtTid.Text = (TransportCount + 1).ToString();
            foreach (DataGridViewRow transport in dgvTransport.Rows)
            {
                this.Datatransport.Add(transport);
                txtSearch.CharacterCasing = CharacterCasing.Normal;
            }
        }
        private void LoadingDataStaffID()
        {
            try
            {
                var result = StaffFunc.GetAllStaff(Program.Connection);
                List<string> ls = new List<string>();
                foreach (var staff in result)
                {
                    ls.Add(staff.StaffID.ToString());

                }
                cbStaffID.DataSource = ls;
                cbStaffID.SelectedIndex = -1;
                txtStpos.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Retriving Staff", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadingDataRouteID()
        {
            try
            {
                var result = RouteFunc.GetAllRoute(Program.Connection);
                List<string> ls = new List<string>();
                foreach (var route in result)
                {
                    ls.Add(route.RouteID.ToString());

                }
                cbRouteID.DataSource = ls;
                cbRouteID.SelectedIndex = -1;
                txtDes.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Retriving Route", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadingDataCustomerID()
        {
            try
            {
                var result = CustomerFunc.GetAllCustomer(Program.Connection);
                List<string> ls = new List<string>();
                foreach (var customer in result)
                {
                    ls.Add(customer.CustomerID.ToString());

                }
                cbCustomerID.DataSource = ls;
                cbCustomerID.SelectedIndex = -1;
                txtCusInfo.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Retriving Customer", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadingDataTransport()
        {
            try
            {

                var result = TransportFunc.GetAllTransport(Program.Connection);
                if (result.LastOrDefault() != null) { TransportCount = result.LastOrDefault().TransportID; }
                else { TransportCount = 0; }
                dgvTransport.Rows.Clear();
                foreach (var transport in result)
                {
                    dgvTransport.Rows.Add(transport.TransportID, transport.TransportDate, transport.TransportStatus, transport.CustomerID,
                        transport.CustomerContactInfo, transport.RouteID, transport.Destination,
                        transport.StaffID, transport.StaffPosition);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Retriving Transport", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


    }
}
