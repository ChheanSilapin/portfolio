﻿namespace PAGTMS
{
    partial class DatabaseConfigurationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DatabaseConfigurationForm));
            label6 = new Label();
            btnConnect = new Button();
            txtPassword = new TextBox();
            iconPictureBox1 = new FontAwesome.Sharp.IconPictureBox();
            pictureBox1 = new PictureBox();
            label10 = new Label();
            label11 = new Label();
            panel2 = new Panel();
            label13 = new Label();
            label12 = new Label();
            iconPictureBox2 = new FontAwesome.Sharp.IconPictureBox();
            txtServerName = new TextBox();
            label3 = new Label();
            txtUserName = new TextBox();
            label2 = new Label();
            label4 = new Label();
            cbAthor = new ComboBox();
            txtDatabaseName = new TextBox();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).BeginInit();
            SuspendLayout();
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(149, 277);
            label6.Name = "label6";
            label6.Size = new Size(79, 19);
            label6.TabIndex = 0;
            label6.Text = "Password:";
            // 
            // btnConnect
            // 
            btnConnect.BackColor = Color.FromArgb(128, 255, 255);
            btnConnect.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnConnect.ForeColor = Color.Black;
            btnConnect.Location = new Point(470, 315);
            btnConnect.Name = "btnConnect";
            btnConnect.Size = new Size(106, 41);
            btnConnect.TabIndex = 3;
            btnConnect.Text = "Connect";
            btnConnect.UseVisualStyleBackColor = false;
            // 
            // txtPassword
            // 
            txtPassword.Enabled = false;
            txtPassword.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtPassword.Location = new Point(324, 269);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(252, 27);
            txtPassword.TabIndex = 4;
            // 
            // iconPictureBox1
            // 
            iconPictureBox1.BackColor = Color.FromArgb(255, 255, 128);
            iconPictureBox1.ForeColor = SystemColors.ControlText;
            iconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.Copyright;
            iconPictureBox1.IconColor = SystemColors.ControlText;
            iconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox1.IconSize = 25;
            iconPictureBox1.Location = new Point(141, 47);
            iconPictureBox1.Name = "iconPictureBox1";
            iconPictureBox1.Size = new Size(25, 26);
            iconPictureBox1.TabIndex = 7;
            iconPictureBox1.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(3, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(132, 73);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(172, 52);
            label10.Name = "label10";
            label10.Size = new Size(238, 17);
            label10.TabIndex = 9;
            label10.Text = "Copyright ISAD_M3_25_Group(Roza)";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Times New Roman", 20F, FontStyle.Regular, GraphicsUnit.Point);
            label11.Location = new Point(186, 3);
            label11.Name = "label11";
            label11.Size = new Size(202, 39);
            label11.TabIndex = 9;
            label11.Text = "Ticket's Form";
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(255, 255, 128);
            panel2.Controls.Add(label13);
            panel2.Controls.Add(label12);
            panel2.Controls.Add(iconPictureBox2);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(605, 76);
            panel2.TabIndex = 7;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Times New Roman", 20F, FontStyle.Regular, GraphicsUnit.Point);
            label13.Location = new Point(149, 9);
            label13.Name = "label13";
            label13.Size = new Size(327, 39);
            label13.TabIndex = 2;
            label13.Text = "DatabaseConfiguration";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(195, 56);
            label12.Name = "label12";
            label12.Size = new Size(221, 17);
            label12.TabIndex = 2;
            label12.Text = "Copyright ISAD_M3_Group5(2024)";
            // 
            // iconPictureBox2
            // 
            iconPictureBox2.BackColor = Color.FromArgb(255, 255, 128);
            iconPictureBox2.ForeColor = SystemColors.ControlText;
            iconPictureBox2.IconChar = FontAwesome.Sharp.IconChar.Copyright;
            iconPictureBox2.IconColor = SystemColors.ControlText;
            iconPictureBox2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox2.IconSize = 23;
            iconPictureBox2.Location = new Point(159, 50);
            iconPictureBox2.Name = "iconPictureBox2";
            iconPictureBox2.Size = new Size(30, 23);
            iconPictureBox2.TabIndex = 1;
            iconPictureBox2.TabStop = false;
            // 
            // txtServerName
            // 
            txtServerName.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtServerName.Location = new Point(324, 95);
            txtServerName.Name = "txtServerName";
            txtServerName.Size = new Size(252, 27);
            txtServerName.TabIndex = 13;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(152, 101);
            label3.Name = "label3";
            label3.Size = new Size(106, 19);
            label3.TabIndex = 12;
            label3.Text = "Server Name :";
            // 
            // txtUserName
            // 
            txtUserName.Enabled = false;
            txtUserName.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtUserName.Location = new Point(324, 224);
            txtUserName.Name = "txtUserName";
            txtUserName.Size = new Size(252, 27);
            txtUserName.TabIndex = 27;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(149, 188);
            label2.Name = "label2";
            label2.Size = new Size(114, 19);
            label2.TabIndex = 26;
            label2.Text = "Authentication:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(149, 232);
            label4.Name = "label4";
            label4.Size = new Size(91, 19);
            label4.TabIndex = 28;
            label4.Text = "UserName :";
            // 
            // cbAthor
            // 
            cbAthor.DropDownStyle = ComboBoxStyle.DropDownList;
            cbAthor.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            cbAthor.FormattingEnabled = true;
            cbAthor.Items.AddRange(new object[] { "Windows Authentication ", "SQL Server Authentication" });
            cbAthor.Location = new Point(324, 180);
            cbAthor.Name = "cbAthor";
            cbAthor.Size = new Size(252, 27);
            cbAthor.TabIndex = 31;
            // 
            // txtDatabaseName
            // 
            txtDatabaseName.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtDatabaseName.Location = new Point(324, 137);
            txtDatabaseName.Name = "txtDatabaseName";
            txtDatabaseName.Size = new Size(252, 27);
            txtDatabaseName.TabIndex = 33;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(152, 143);
            label1.Name = "label1";
            label1.Size = new Size(123, 19);
            label1.TabIndex = 32;
            label1.Text = "Database Name :";
            // 
            // DatabaseConfigurationForm
            // 
            AutoScaleDimensions = new SizeF(8F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(605, 384);
            Controls.Add(txtDatabaseName);
            Controls.Add(label1);
            Controls.Add(cbAthor);
            Controls.Add(label4);
            Controls.Add(txtUserName);
            Controls.Add(label2);
            Controls.Add(txtServerName);
            Controls.Add(label3);
            Controls.Add(panel2);
            Controls.Add(txtPassword);
            Controls.Add(btnConnect);
            Controls.Add(label6);
            Font = new Font("Times New Roman", 9F, FontStyle.Regular, GraphicsUnit.Point);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "DatabaseConfigurationForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "DatabaseTool Form";
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private Label label6;
        private Button btnConnect;
        private TextBox txtPassword;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox1;
#pragma warning disable CS0169 // The field 'Ticket.panel1' is never used
#pragma warning restore CS0169 // The field 'Ticket.panel1' is never used
        private Label label10;
        private PictureBox pictureBox1;
        private Label label11;
#pragma warning disable CS0649 // Field 'Ticket.panel1_Paint' is never assigned to, and will always have its default value null
        private Panel panel2;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox2;
        private Label label13;
        private Label label12;
        private TextBox txtServerName;
        private Label label3;
        private TextBox txtUserName;
        private Label label2;
        private Label label4;
        private ComboBox cbAthor;
        private TextBox txtDatabaseName;
        private Label label1;
    }
}