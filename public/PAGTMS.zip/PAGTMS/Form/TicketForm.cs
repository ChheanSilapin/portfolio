﻿using PAGTMS.Models;
using PAGTMS.Ultils;

namespace PAGTMS;

public partial class TicketForm : Form
{
    private MainForm mainFormReference;
    Customer? effectedCustomer = null;
    Staff? effectedStaff = null;
    //Booking? effectedBooking = null;
    Ticket? effectedTicket = null;
    List<DataGridViewRow> Dataticket = new List<DataGridViewRow>();
    int TicketCount = 0;
    int IndexOfUpdateTicket;
    private LoginForm loginFormReference;
    public TicketForm(MainForm mainForm, LoginForm loginForm)
    {
        InitializeComponent();
        mainFormReference = mainForm;
        loginFormReference = loginForm;
        this.FormClosed += new FormClosedEventHandler((_, _) => mainFormReference.Show());
        btnClear.Click += DoClickNewFormInput;
        btnBack.Click += (_, _) => this.Close();
        cbStaffID.SelectedValueChanged += Select_Handling_StaffID;
        cbCustomerID.SelectedValueChanged += Select_Handling_CusID;
        dvgTicket.Click += Select_Handling_Ticket;
        txtSearch.TextChanged += SearchFuntion;
        btnInsert.Click += DoClickInsertTicket;
        btnUpdate.Click += DoClickUpdateTicket;
        dtTicketdate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
        Dataticket.Clear();
        btnLogOut.Click += (_, _) => { this.Hide(); loginFormReference.Show(); };
    }
    private void SearchFuntion(object? sender, EventArgs e)
    {
        if (string.IsNullOrEmpty(txtSearch.Text) == false)
        {
            dvgTicket.Rows.Clear();
            foreach (DataGridViewRow ticket in Dataticket)
            {
                if (ticket.Cells[0].Value.ToString().StartsWith(txtSearch.Text))
                {
                    dvgTicket.Rows.Add(ticket);
                }
            }
        }
        else if (txtSearch.Text == "")
        {
            dvgTicket.Rows.Clear();
            foreach (DataGridViewRow ticket in Dataticket)
            {
                dvgTicket.Rows.Add(ticket);
            }
        }

    }
    private void DoClickUpdateTicket(object? sender, EventArgs e)
    {
        if (effectedTicket != null)
        {
            effectedTicket.TicketID = int.Parse(txtTicketID.Text.Trim());
            effectedTicket.SeatNum = txtSeatNum.Text.Trim();
            effectedTicket.Price = decimal.Parse(txtPrice.Text.Trim());
            effectedTicket.TicketDate = dtTicketdate.Value;
            effectedTicket.CustomerID = int.Parse(cbCustomerID.SelectedValue.ToString().Trim());
            effectedTicket.CusContactInfo = txtCusInfo.Text.Trim();
            effectedTicket.StaffID = int.Parse(cbStaffID.SelectedValue.ToString().Trim());
            effectedTicket.StaffPosition = txtStpos.Text.Trim();
            try
            {
                var result = TicketFunc.UpdateTicket(Program.Connection, effectedTicket);
                if (result == true)
                    MessageBox.Show($"Successfully updated!!", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                
                DataGridViewRow tempDataGridViewRow = new DataGridViewRow();
                tempDataGridViewRow.CreateCells(dvgTicket);
                tempDataGridViewRow.Cells[0].Value = effectedTicket.TicketID;
                tempDataGridViewRow.Cells[1].Value = effectedTicket.SeatNum;
                tempDataGridViewRow.Cells[2].Value = effectedTicket.Price;
                tempDataGridViewRow.Cells[3].Value = effectedTicket.TicketDate;
                tempDataGridViewRow.Cells[4].Value = effectedTicket.CustomerID;
                tempDataGridViewRow.Cells[5].Value = effectedTicket.CusContactInfo;
                tempDataGridViewRow.Cells[6].Value = effectedTicket.StaffID;
                tempDataGridViewRow.Cells[7].Value = effectedTicket.StaffPosition;
                foreach (DataGridViewRow checkTicket in Dataticket)
                {
                    if (int.Parse(checkTicket.Cells[0].Value.ToString()) == effectedTicket.TicketID)
                    {
                        checkTicket.Cells[1].Value = tempDataGridViewRow.Cells[1].Value;
                        checkTicket.Cells[2].Value = tempDataGridViewRow.Cells[2].Value;
                        checkTicket.Cells[3].Value = tempDataGridViewRow.Cells[3].Value;
                        checkTicket.Cells[4].Value = tempDataGridViewRow.Cells[4].Value;
                        checkTicket.Cells[5].Value = tempDataGridViewRow.Cells[5].Value;
                        checkTicket.Cells[6].Value = tempDataGridViewRow.Cells[6].Value;
                        checkTicket.Cells[7].Value = tempDataGridViewRow.Cells[7].Value;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Update Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        LoadingDataTicket();
    }

    private void DoClickInsertTicket(object? sender, EventArgs e)
    {
        if (int.TryParse(txtTicketID.Text, out int ticketID) == false)
        {
            MessageBox.Show("Ticket ID is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (txtSeatNum.Text == "")
        {
            MessageBox.Show("SeatNum is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (decimal.TryParse(txtPrice.Text, out decimal price) == false)
        {
            MessageBox.Show("Price is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (dtTicketdate.Text == "")
        {
            MessageBox.Show("TicketDate is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (cbCustomerID.SelectedItem == null)
        {
            MessageBox.Show("Customer ID is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (cbStaffID.SelectedItem == null)
        {
            MessageBox.Show("Staff ID is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }

        string? customerID = cbCustomerID.SelectedItem.ToString();
        if (customerID == null) return;
        //string? bookingID = cbBookingID.SelectedItem.ToString();
        //if (bookingID == null) return;
        string? staffID = cbStaffID.SelectedItem.ToString();
        if (staffID == null) return;
        Ticket newTicket = new Ticket()
        {
            TicketID = ticketID,
            SeatNum = txtSeatNum.Text.Trim(),
            Price = price,
            TicketDate = dtTicketdate.Value,
            CustomerID = int.Parse(customerID.Trim()),
            CusContactInfo = txtCusInfo.Text.Trim(),
            StaffID = int.Parse(staffID.Trim()),
            StaffPosition = txtStpos.Text.Trim(),
        };
        try
        {
            TicketFunc.AddTicket(Program.Connection, newTicket);
            MessageBox.Show($"Successfully Inserted a New Ticket!", "Ticket", MessageBoxButtons.OK, MessageBoxIcon.Information);
            DataGridViewRow tempDataGridViewRow = new DataGridViewRow();
            tempDataGridViewRow.CreateCells(dvgTicket);
            tempDataGridViewRow.Cells[0].Value = txtTicketID.Text;
            tempDataGridViewRow.Cells[1].Value = newTicket.SeatNum;
            tempDataGridViewRow.Cells[2].Value = newTicket.Price;
            tempDataGridViewRow.Cells[3].Value = newTicket.TicketDate;
            tempDataGridViewRow.Cells[4].Value = cbCustomerID.Text;
            tempDataGridViewRow.Cells[5].Value = newTicket.CusContactInfo;
            tempDataGridViewRow.Cells[6].Value = cbStaffID.Text;
            tempDataGridViewRow.Cells[7].Value = newTicket.StaffPosition;
            Dataticket.Add(tempDataGridViewRow);
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Submitting", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        LoadingDataTicket();
    }

    private void Select_Handling_Ticket(object? sender, EventArgs e)
    {
        if (dvgTicket.CurrentRow == null) return;
        int id = (int)dvgTicket.CurrentRow.Cells[0].Value;
        try
        {

            effectedTicket = TicketFunc.GetOneTicket(Program.Connection, id);

            txtTicketID.Text = effectedTicket.TicketID.ToString();
            txtSeatNum.Text = effectedTicket.SeatNum;
            txtPrice.Text = effectedTicket.Price.ToString();
            dtTicketdate.Value = (DateTime)effectedTicket.TicketDate;
            cbCustomerID.Text = effectedTicket.CustomerID.ToString();
            txtCusInfo.Text = effectedTicket.CusContactInfo;
            cbStaffID.Text = effectedTicket.StaffID.ToString();
            txtStpos.Text = effectedTicket.StaffPosition;
            //cbBookingID.Text = effectedTicket.BookingID.ToString();

        }
        catch (Exception ex)
        {
            MessageBox.Show($"Here: {ex.Message}");
        }
    }

    private void Select_Handling_CusID(object? sender, EventArgs e)
    {
        if (cbCustomerID.SelectedItem != null)
        {
            string? customerID = cbCustomerID.SelectedItem.ToString();
            if (customerID == null) return;
            try
            {
                effectedCustomer = CustomerFunc.GetOneCustomer(Program.Connection, int.Parse(customerID.Trim()));

                txtCusInfo.Text = effectedCustomer.CustomerContactInfo;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}");
            }
        }
    }

    private void Select_Handling_StaffID(object? sender, EventArgs e)
    {
        if (cbStaffID.SelectedItem != null)
        {
            string? staffID = cbStaffID.SelectedItem.ToString();
            if (staffID == null) return;
            try
            {
                effectedStaff = StaffFunc.GetOneStaff(Program.Connection, int.Parse(staffID.Trim()));

                txtStpos.Text = effectedStaff.StaffPosition;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}");
            }
        }
    }

    //private void Select_Handling_BookingID(object? sender, EventArgs e)
    //{
    //    if (cbBookingID.SelectedItem != null)
    //    {
    //        string? bookingID = cbBookingID.SelectedItem.ToString();
    //        if (bookingID == null) return;
    //        try
    //        {
    //            effectedBooking = BookingFunc.GetOneBooking(Program.Connection, int.Parse(bookingID.Trim()));
    //        }
    //        catch (Exception ex)
    //        {
    //            MessageBox.Show($"{ex.Message}");
    //        }
    //    }
    //}
    private void DoClickNewFormInput(object? sender, EventArgs e)
    {
        txtTicketID.Text = (TicketCount + 1).ToString();
        dtTicketdate.ResetText();
        txtSeatNum.Clear();
        txtPrice.Clear();
        cbCustomerID.SelectedItem = null;
        txtCusInfo.Clear();
        cbStaffID.SelectedItem = null;
        txtStpos.Clear();
    }

    //private void LoadDataBooking()
    //{
    //    try
    //    {
    //        var result = BookingFunc.GetAllBooking(Program.Connection);
    //        List<string> ls = new List<string>();
    //        foreach (var booking in result)
    //        {
    //            ls.Add(booking.BookingID.ToString());

    //        }
    //        cbBookingID.DataSource = ls;
    //        cbBookingID.SelectedIndex = -1;
    //    }
    //    catch (Exception ex)
    //    {
    //        MessageBox.Show(ex.Message, "Retriving Staff", MessageBoxButtons.OK, MessageBoxIcon.Error);
    //    }
    //}
    private void LoadingDataStaffID()
    {
        try
        {
            var result = StaffFunc.GetAllStaff(Program.Connection);
            List<string> ls = new List<string>();
            foreach (var staff in result)
            {
                ls.Add(staff.StaffID.ToString());

            }
            cbStaffID.DataSource = ls;
            cbStaffID.SelectedIndex = -1;
            txtStpos.Clear();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Retriving Staff", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void LoadingDataCustomerID()
    {
        try
        {
            var result = CustomerFunc.GetAllCustomer(Program.Connection);
            List<string> ls = new List<string>();
            foreach (var customer in result)
            {
                ls.Add(customer.CustomerID.ToString());

            }
            cbCustomerID.DataSource = ls;
            cbCustomerID.SelectedIndex = -1;
            txtCusInfo.Clear();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Retriving Customer", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void LoadingDataTicket()
    {
        try
        {

            var result = TicketFunc.GetAllTicket(Program.Connection);
            if (result.LastOrDefault() != null) { TicketCount = result.LastOrDefault().TicketID; }
            else { TicketCount = 0; }
            dvgTicket.Rows.Clear();
            foreach (var ticket in result)
            {
                dvgTicket.Rows.Add(ticket.TicketID, ticket.SeatNum, ticket.Price, ticket.TicketDate,
                    ticket.CustomerID, ticket.CusContactInfo,
                    ticket.StaffID, ticket.StaffPosition);

            }
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Retriving Ticket", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void TicketForm_Load(object sender, EventArgs e)
    {
        LoadingDataCustomerID();
        LoadingDataStaffID();
        LoadingDataTicket();
        txtTicketID.Text = (TicketCount + 1).ToString();
        foreach (DataGridViewRow ticket in dvgTicket.Rows)
        {
            this.Dataticket.Add(ticket);
            txtSearch.CharacterCasing = CharacterCasing.Normal;
        }
    }
}
