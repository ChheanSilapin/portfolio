﻿using PAGTMS.Models;
using PAGTMS.Ultils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Forms;
using CharacterCasing = System.Windows.Forms.CharacterCasing;

namespace PAGTMS;

public partial class RouteForm : Form
{
    Route? effectedRoute = null;
    List<DataGridViewRow> dataGridRoute = new List<DataGridViewRow>();
    int RouteCount = 0;
    private MainForm mainFormReference;
    int IndexOfUpdateRoute;
    private LoginForm loginFormReference;
    
    public RouteForm(MainForm mainForm, LoginForm loginForm)
    {
        InitializeComponent();
        mainFormReference = mainForm;
        loginFormReference = loginForm;
        this.FormClosed += new FormClosedEventHandler((_, _) => mainFormReference.Show());
        btnBack.Click += (_, _) => this.Close();
        btnInsert.Click += DoClickInsertRoute;
        btnUpdate.Click += DoClickUpdateRoute;
        dgvRoute.Click += Select_Handling_Route;
        txtSearch.TextChanged += SearchChangedFunc;
        btnClear.Click += DoClickClear;
        dataGridRoute.Clear();
        btnLogOut.Click += (_, _) => { this.Hide(); loginFormReference.Show(); };
    }

    private void SearchChangedFunc(object? sender, EventArgs e)
    {
        if (string.IsNullOrEmpty(txtSearch.Text) == false)
        {
            dgvRoute.Rows.Clear();
            foreach (DataGridViewRow route in dataGridRoute)
            {
                if (route.Cells[0].Value.ToString().StartsWith(txtSearch.Text))
                {
                    dgvRoute.Rows.Add(route);
                }
            }
        }
        else if (txtSearch.Text == "")
        {
            dgvRoute.Rows.Clear();
            foreach (DataGridViewRow route in dataGridRoute)
            {
                dgvRoute.Rows.Add(route);
            }
        }
    }

    private void DoClickClear(object? sender, EventArgs e)
    {
        txtRid.Text = (RouteCount + 1).ToString();
        txtOrigin.Clear();
        txtDes.Clear();
        txtDis.Clear();
    }

    private void DoClickUpdateRoute(object? sender, EventArgs e)
    {
        if (effectedRoute != null)
        {
            effectedRoute.RouteID = int.Parse(txtRid.Text);
            effectedRoute.Origin = txtOrigin.Text.Trim();
            effectedRoute.Destination = txtDes.Text.Trim();
            effectedRoute.Distance = txtDis.Text.Trim();

            try
            {
                var result = RouteFunc.UpdateRoute(Program.Connection, effectedRoute);
                if (result == true)
                    MessageBox.Show($"Successfully Update!", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                
                DataGridViewRow tempDataGridViewRow = new DataGridViewRow();
                tempDataGridViewRow.CreateCells(dgvRoute);
                tempDataGridViewRow.Cells[0].Value = effectedRoute.RouteID;
                tempDataGridViewRow.Cells[1].Value = effectedRoute.Origin;
                tempDataGridViewRow.Cells[2].Value = effectedRoute.Destination;
                tempDataGridViewRow.Cells[3].Value = effectedRoute.Distance;
                foreach (DataGridViewRow checkRoute in dataGridRoute)
                {
                    if (int.Parse(checkRoute.Cells[0].Value.ToString()) == effectedRoute.RouteID)
                    {
                        checkRoute.Cells[1].Value = tempDataGridViewRow.Cells[1].Value;
                        checkRoute.Cells[2].Value = tempDataGridViewRow.Cells[2].Value;
                        checkRoute.Cells[3].Value = tempDataGridViewRow.Cells[3].Value;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Update Failed ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        LoadingDataRoute();
    }

    private void DoClickInsertRoute(object? sender, EventArgs e)
    {
        if (int.TryParse(txtRid.Text, out int routeID) == false)
        {
            MessageBox.Show("Route Id is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (txtOrigin.Text == "")
        {
            MessageBox.Show("Origin is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (txtDes.Text == "")
        {
            MessageBox.Show("Destination is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (txtDis.Text == "")
        {
            MessageBox.Show("Distance is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        Route newRoute = new Route()
        {
            RouteID = routeID,
            Origin = txtOrigin.Text.Trim(),
            Destination = txtDes.Text.Trim(),
            Distance = txtDis.Text.Trim(),
        };
        try
        {
            RouteFunc.AddRoute(Program.Connection, newRoute);
            MessageBox.Show($"Successfully Insert!", "Inserted", MessageBoxButtons.OK, MessageBoxIcon.Information);
            DataGridViewRow tempDataGridViewRow = new DataGridViewRow();
            tempDataGridViewRow.CreateCells(dgvRoute);
            tempDataGridViewRow.Cells[0].Value = txtRid.Text;
            tempDataGridViewRow.Cells[1].Value = newRoute.Origin;
            tempDataGridViewRow.Cells[2].Value = newRoute.Destination;
            tempDataGridViewRow.Cells[3].Value = newRoute.Distance;
            dataGridRoute.Add(tempDataGridViewRow);
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Submitting", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        LoadingDataRoute();
    }
    private void Select_Handling_Route(object? sender, EventArgs e)
    {
        if (dgvRoute.CurrentRow == null) return;
        int id = (int)dgvRoute.CurrentRow.Cells[0].Value;
        try
        {
            effectedRoute = RouteFunc.GetOneRoute(Program.Connection, id);
            txtRid.Text = effectedRoute.RouteID.ToString();
            txtOrigin.Text = effectedRoute.Origin;
            txtDes.Text = effectedRoute.Destination;
            txtDis.Text = effectedRoute.Distance;
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Here: {ex.Message}");
        }
    }
    private void LoadingDataRoute()
    {
        try
        {

            var result = RouteFunc.GetAllRoute(Program.Connection);
            if (result.LastOrDefault() != null) { RouteCount = result.LastOrDefault().RouteID; }
            else { RouteCount = 0; }
            dgvRoute.Rows.Clear();
            foreach (var route in result)
            {
                dgvRoute.Rows.Add(route.RouteID, route.Origin, route.Destination,
                    route.Distance);
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Retriving Route", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void RouteForm_Load(object sender, EventArgs e)
    {
        LoadingDataRoute();
        txtRid.Text = (RouteCount + 1).ToString();
        foreach (DataGridViewRow route in dgvRoute.Rows)
        {
            dataGridRoute.Add(route);
            txtSearch.CharacterCasing = CharacterCasing.Lower;
        }
    }
}
