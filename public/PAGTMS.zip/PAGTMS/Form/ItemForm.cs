﻿using PAGTMS.Models;
using PAGTMS.Ultils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAGTMS;

public partial class ItemForm : Form
{
    private MainForm mainFormReference;
    Customer? effectedCustomer = null;
    Item? effectedItem = null;
    Transport? effectedTransport = null;
    List<DataGridViewRow> DataItems = new List<DataGridViewRow>();
    int ItemsCount = 0;
    int IndexOfUpdateItems;
    private LoginForm loginFormReference;
    public ItemForm(MainForm mainForm, LoginForm loginForm)
    {
        InitializeComponent();
        mainFormReference = mainForm;
        loginFormReference = loginForm;
        this.FormClosed += new FormClosedEventHandler((_, _) => mainFormReference.Show());
        btnBack.Click += (_, _) => this.Close();
        btnClear.Click += DoClickNewFormInput;
        btnInsert.Click += DoClickInsertSubject;
        btnUpdate.Click += DoClickUpdateItem;
        dgvItem.CellClick += Select_Handling_Item;
        txtSearch.TextChanged += SearchFuntion;
        cbCustomerID.SelectedValueChanged += Select_Handling_CusID;
        cbTransID.SelectedValueChanged += Select_Handling_TransportID;
        dtTd.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
        btnLogOut.Click += (_, _) => { this.Hide(); loginFormReference.Show(); };
    }

    private void SearchFuntion(object? sender, EventArgs e)
    {
        LoadingDataItem();
        if (string.IsNullOrEmpty(txtSearch.Text) == false)
        {
            dgvItem.Rows.Clear();
            foreach (DataGridViewRow items in DataItems)
            {
                if (items.Cells[0].Value.ToString().StartsWith(txtSearch.Text))
                {
                    dgvItem.Rows.Add(items);
                }
            }
        }
        else if (txtSearch.Text == "")
        {
            dgvItem.Rows.Clear();
            foreach (DataGridViewRow vehicle in DataItems)
            {
                dgvItem.Rows.Add(vehicle);
            }
        }

    }

    private void DoClickUpdateItem(object? sender, EventArgs e)
    {
        if (effectedItem != null)
        {
            effectedItem.ItemID = int.Parse(txtItemID.Text.Trim());
            effectedItem.Category = txtCate.Text.Trim();
            effectedItem.Description = txtDescription.Text.Trim();
            effectedItem.Weight = txtWeight.Text.Trim();
            effectedItem.CustomerID = int.Parse(cbCustomerID.SelectedValue.ToString().Trim());
            effectedItem.CustomerName = txtCusname.Text.Trim();
            effectedItem.CustomerContact = txtCusInfo.Text.Trim();
            effectedItem.TransportID = int.Parse(cbTransID.SelectedValue.ToString().Trim());
            effectedItem.TransportDate = dtTd.Value;
            try
            {
                var result = ItemFunc.UpdateItem(Program.Connection, effectedItem);
                if (result == true)
                    MessageBox.Show("Updated!!", "Successfully Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
                
                DataGridViewRow tempDataGridViewRow = new DataGridViewRow();
                tempDataGridViewRow.CreateCells(dgvItem);
                tempDataGridViewRow.Cells[0].Value = effectedItem.ItemID;
                tempDataGridViewRow.Cells[1].Value = effectedItem.Category;
                tempDataGridViewRow.Cells[2].Value = effectedItem.CustomerID;
                tempDataGridViewRow.Cells[3].Value = effectedItem.CustomerName;
                tempDataGridViewRow.Cells[4].Value = effectedItem.TransportID;
                tempDataGridViewRow.Cells[5].Value = effectedItem.TransportDate;
                foreach (DataGridViewRow checkItems in DataItems)
                {
                    if (int.Parse(checkItems.Cells[0].Value.ToString()) == effectedItem.ItemID)
                    {
                        checkItems.Cells[1].Value = tempDataGridViewRow.Cells[1].Value;
                        checkItems.Cells[2].Value = tempDataGridViewRow.Cells[2].Value;
                        checkItems.Cells[3].Value = tempDataGridViewRow.Cells[3].Value;
                        checkItems.Cells[4].Value = tempDataGridViewRow.Cells[4].Value;
                        checkItems.Cells[5].Value = tempDataGridViewRow.Cells[5].Value;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Update Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        LoadingDataItem();

    }

    private void DoClickInsertSubject(object? sender, EventArgs e)
    {
        if (int.TryParse(txtItemID.Text, out int itemID) == false)
        {
            MessageBox.Show("Item Id is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (txtCate.Text == "")
        {
            MessageBox.Show("Catogory is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }

        if (txtDescription.Text == "")
        {
            MessageBox.Show("Descripption is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (txtWeight.Text == "")
        {
            MessageBox.Show("Weight is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (cbCustomerID.SelectedItem == null)
        {
            MessageBox.Show("Customer ID is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (cbTransID.SelectedItem == null)
        {
            MessageBox.Show("Tansport Id is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        string? customerid = cbCustomerID.SelectedItem.ToString();
        string? transportid = cbTransID.SelectedItem.ToString();
        Item newItem = new Item()
        {
            ItemID = itemID,
            Category = txtCate.Text.Trim(),
            Description = txtDescription.Text.Trim(),
            Weight = txtWeight.Text.Trim(),
            CustomerID = int.Parse(customerid.Trim()),
            CustomerName = txtCusname.Text.Trim(),
            CustomerContact = txtCusInfo.Text.Trim(),
            TransportID = int.Parse(transportid.Trim()),
            TransportDate = dtTd.Value,
        };
        try
        {
            ItemFunc.AddItem(Program.Connection, newItem);
            MessageBox.Show("Inserted!!", "Successfully Inserted", MessageBoxButtons.OK, MessageBoxIcon.Information);
            DataGridViewRow tempDataGridViewRow = new DataGridViewRow();
            tempDataGridViewRow.CreateCells(dgvItem);
            tempDataGridViewRow.Cells[0].Value = txtItemID.Text;
            tempDataGridViewRow.Cells[1].Value = newItem.Category;
            tempDataGridViewRow.Cells[2].Value = cbCustomerID.Text;
            tempDataGridViewRow.Cells[3].Value = newItem.CustomerName;
            tempDataGridViewRow.Cells[4].Value = cbTransID.Text;
            tempDataGridViewRow.Cells[5].Value = newItem.TransportDate;
            DataItems.Add(tempDataGridViewRow);
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Submitting", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        LoadingDataItem();
    }
    private void LoadingDataItem()
    {
        try
        {
            dgvItem.Rows.Clear();
            var result = ItemFunc.GetAllItem(Program.Connection);
            if (result.LastOrDefault() != null) { ItemsCount = result.LastOrDefault().ItemID; }
            else { ItemsCount = 0; }
            foreach (var item in result)
            {
                dgvItem.Rows.Add(item.ItemID, item.Category, item.CustomerID, item.CustomerName, item.TransportID, item.TransportDate);
            }

        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Retriving Item", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        LoadingDataCustomerID();
        LoadingDataTransportID();
    }
    private void Select_Handling_Item(object? sender, DataGridViewCellEventArgs e)
    {
        if (dgvItem.CurrentRow == null) return;
        int id = (int)dgvItem.CurrentRow.Cells[0].Value;
        try
        {
            effectedItem = ItemFunc.GetOneItem(Program.Connection, id);
            txtItemID.Text = effectedItem.ItemID.ToString();
            txtCate.Text = effectedItem.Category;
            txtDescription.Text = effectedItem.Description;
            txtWeight.Text = effectedItem.Weight;
            cbCustomerID.SelectedItem = effectedItem.CustomerID.ToString();
            txtCusname.Text = effectedItem.CustomerName;
            txtCusInfo.Text = effectedItem.CustomerContact;
            cbTransID.Text = effectedItem.TransportID.ToString();
            dtTd.Value = (DateTime)effectedItem.TransportDate;

        }
        catch (Exception ex)
        {
            MessageBox.Show($"Here: {ex.Message}");
        }
    }

    private void Select_Handling_CusID(object? sender, EventArgs e)
    {
        if (cbCustomerID.SelectedItem != null)
        {
            string? customerID = cbCustomerID.SelectedItem.ToString();
            if (customerID == null) return;
            try
            {
                effectedCustomer = CustomerFunc.GetOneCustomer(Program.Connection, int.Parse(customerID.Trim()));
                txtCusname.Text = effectedCustomer.CustomerName;
                txtCusInfo.Text = effectedCustomer.CustomerContactInfo;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}");
            }
        }
    }
    private void Select_Handling_TransportID(object? sender, EventArgs e)
    {
        if (cbTransID.SelectedItem != null)
        {
            string? transportID = cbTransID.SelectedItem.ToString();
            if (transportID == null) return;
            try
            {
                effectedTransport = TransportFunc.GetOneTransport(Program.Connection, int.Parse(transportID.Trim()));
                dtTd.Value = effectedTransport.TransportDate;

            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}");
            }
        }
    }
    private void ItemForm_Load(object sender, EventArgs e)
    {
        LoadingDataCustomerID();
        LoadingDataTransportID();
        LoadingDataItem();
        txtItemID.Text = (ItemsCount + 1).ToString();
        foreach (DataGridViewRow items in dgvItem.Rows)
        {
            DataItems.Add(items);
            txtSearch.CharacterCasing = CharacterCasing.Normal;
        }

    }
    private void LoadingDataCustomerID()
    {
        try
        {
            var result = CustomerFunc.GetAllCustomer(Program.Connection);
            List<string> ls = new List<string>();
            foreach (var customer in result)
            {
                ls.Add(customer.CustomerID.ToString());

            }
            cbCustomerID.DataSource = ls;
            cbCustomerID.SelectedIndex = -1;
            txtCusname.Clear();
            txtCusInfo.Clear();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Retriving Customer", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
    private void LoadingDataTransportID()
    {
        try
        {
            var result = TransportFunc.GetAllTransport(Program.Connection);
            List<string> ls = new List<string>();
            foreach (var transport in result)
            {
                ls.Add(transport.TransportID.ToString());

            }
            cbTransID.DataSource = ls;
            cbTransID.SelectedIndex = -1;
            dtTd.ResetText();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Retriving Transport", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
    private void DoClickNewFormInput(object? sender, EventArgs e)
    {
        txtItemID.Text = (ItemsCount + 1).ToString();
        txtCate.Clear();
        txtDescription.Clear();
        txtWeight.Clear();
        cbCustomerID.SelectedItem = null;
        txtCusname.Clear();
        txtCusInfo.Clear();
        cbTransID.SelectedItem = null;
        dtTd.ResetText();
    }


}
