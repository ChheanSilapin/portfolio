﻿using PAGTMS.Models;
using PAGTMS.Ultils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAGTMS;

public partial class VehicleForm : Form
{
    private MainForm mainFormReference;
    Vehicle? effectedVehicle = null;
    List<DataGridViewRow> dataGridVehicle = new List<DataGridViewRow>();
    int VehicleCount = 0;
    int IndexOfUpdateVehicle;
    private LoginForm loginFormReference;
    public VehicleForm(MainForm mainform,LoginForm loginForm)
    {
        InitializeComponent();
        mainFormReference = mainform;
        loginFormReference = loginForm;
        this.FormClosed += new FormClosedEventHandler((_, _) => mainFormReference.Show());
        btnBack.Click += (_, _) => this.Close();
        btnInsert.Click += DoClickInsertVehicle;
        btnUpdate.Click += DoClickUpdateVehicle;
        btnClear.Click += DoClickClear;
        txtSearch.TextChanged += SearchFunction;
        dgvVehicle.Click += Select_Handling_Vehicle;
        btnLogOut.Click += (_, _) => { this.Hide(); loginFormReference.Show(); };
    }
    private void SearchFunction(object? sender, EventArgs e)
    {
        if (string.IsNullOrEmpty(txtSearch.Text) == false)
        {
            dgvVehicle.Rows.Clear();
            foreach (DataGridViewRow route in dataGridVehicle)
            {
                if (route.Cells[0].Value.ToString().StartsWith(txtSearch.Text))
                {
                    dgvVehicle.Rows.Add(route);
                }
            }
        }
        else if (txtSearch.Text == "")
        {
            dgvVehicle.Rows.Clear();
            foreach (DataGridViewRow vehicle in dataGridVehicle)
            {
                dgvVehicle.Rows.Add(vehicle);
            }
        }
    }
    private void DoClickUpdateVehicle(object? sender, EventArgs e)
    {
        if (effectedVehicle != null)
        {
            effectedVehicle.VehicleID = int.Parse(txtVid.Text.Trim());
            effectedVehicle.VehicleType = txtVt.Text.Trim();
            effectedVehicle.Capacity = txtCp.Text.Trim();
            effectedVehicle.LincensePlate = txtLp.Text.Trim();
            effectedVehicle.VehicleStatus = cbSt.Text.Trim();

            try
            {
                var result = VehicleFunc.UpdateVehicle(Program.Connection, effectedVehicle);
                if (result == true)
                    MessageBox.Show($"Successfully updated!", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                
                DataGridViewRow tempDataGridViewRow = new DataGridViewRow();
                tempDataGridViewRow.CreateCells(dgvVehicle);
                tempDataGridViewRow.Cells[0].Value = effectedVehicle.VehicleID;
                tempDataGridViewRow.Cells[1].Value = effectedVehicle.VehicleType;
                tempDataGridViewRow.Cells[2].Value = effectedVehicle.Capacity;
                tempDataGridViewRow.Cells[3].Value = effectedVehicle.LincensePlate;
                tempDataGridViewRow.Cells[4].Value = effectedVehicle.VehicleStatus;
                foreach (DataGridViewRow checkVehicle in dataGridVehicle)
                {
                    if (int.Parse(checkVehicle.Cells[0].Value.ToString()) == effectedVehicle.VehicleID)
                    {
                        checkVehicle.Cells[1].Value = tempDataGridViewRow.Cells[1].Value;
                        checkVehicle.Cells[2].Value = tempDataGridViewRow.Cells[2].Value;
                        checkVehicle.Cells[3].Value = tempDataGridViewRow.Cells[3].Value;
                        checkVehicle.Cells[4].Value = tempDataGridViewRow.Cells[4].Value;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Update Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        LoadingDataVehicle();
    }
    private void DoClickInsertVehicle(object? sender, EventArgs e)
    {
        if (int.TryParse(txtVid.Text, out int vehicleID) == false)
        {
            MessageBox.Show("Vehicle Id is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (txtVt.Text == "")
        {
            MessageBox.Show("VehicleType is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (txtCp.Text == "")
        {
            MessageBox.Show("Capacity is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (txtLp.Text == "")
        {
            MessageBox.Show("Vehicle Status is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (cbSt.Text == "")
        {
            MessageBox.Show("Vehicle Status is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }

        Vehicle newVehicle = new Vehicle()
        {
            VehicleID = vehicleID,
            VehicleType = txtVt.Text.Trim(),
            Capacity = txtCp.Text.Trim(),
            LincensePlate = txtLp.Text.Trim(),
            VehicleStatus = cbSt.Text.Trim(),

        };
        try
        {
            VehicleFunc.AddVehicle(Program.Connection, newVehicle);
            MessageBox.Show($"Successfully Insert!", "Inserted", MessageBoxButtons.OK, MessageBoxIcon.Information);
            DataGridViewRow tempDataGridViewRow = new DataGridViewRow();
            tempDataGridViewRow.CreateCells(dgvVehicle);
            tempDataGridViewRow.Cells[0].Value = txtVid.Text;
            tempDataGridViewRow.Cells[1].Value = newVehicle.VehicleType;
            tempDataGridViewRow.Cells[2].Value = newVehicle.Capacity;
            tempDataGridViewRow.Cells[3].Value = newVehicle.LincensePlate;
            tempDataGridViewRow.Cells[4].Value = newVehicle.VehicleStatus;
            dataGridVehicle.Add(tempDataGridViewRow);
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Submitting", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        LoadingDataVehicle();
    }
    private void Select_Handling_Vehicle(object? sender, EventArgs e)
    {
        if (dgvVehicle.CurrentRow == null) return;
        int id = (int)dgvVehicle.CurrentRow.Cells[0].Value;
        try
        {
            effectedVehicle = VehicleFunc.GetOneVehicle(Program.Connection, id);
            txtVid.Text = effectedVehicle.VehicleID.ToString();
            txtVt.Text = effectedVehicle.VehicleType;
            txtCp.Text = effectedVehicle.Capacity;
            txtLp.Text = effectedVehicle.LincensePlate;
            cbSt.Text = effectedVehicle.VehicleStatus;

        }
        catch (Exception ex)
        {
            MessageBox.Show($"Here: {ex.Message}");
        }
    }
    private void VehicleForm_Load(object sender, EventArgs e)
    {
        LoadingDataVehicle();
        txtVid.Text = (VehicleCount + 1).ToString();
        foreach (DataGridViewRow route in dgvVehicle.Rows)
        {
            dataGridVehicle.Add(route);
            txtSearch.CharacterCasing = CharacterCasing.Lower;
        }
    }
    private void LoadingDataVehicle()
    {
        try
        {
            
            var result = VehicleFunc.GetAllVehicle(Program.Connection);
            if (result.LastOrDefault() != null) { VehicleCount = result.LastOrDefault().VehicleID; }
            else { VehicleCount = 0; }
            dgvVehicle.Rows.Clear();
            foreach (var vehicle in result)
            {
                dgvVehicle.Rows.Add(vehicle.VehicleID, vehicle.VehicleType, vehicle.Capacity,
                    vehicle.LincensePlate, vehicle.VehicleStatus);
            }

        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Retriving Vehciel", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
    private void DoClickClear(object? sender, EventArgs e)
    {
        txtVid.Text = (VehicleCount + 1).ToString();
        txtCp.Clear();
        txtLp.Clear();
        txtVt.Clear();
        cbSt.SelectedItem = null;
    }


}
