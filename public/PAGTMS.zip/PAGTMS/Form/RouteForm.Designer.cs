﻿namespace PAGTMS
{
    partial class RouteForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RouteForm));
            label1 = new Label();
            label5 = new Label();
            dgvRoute = new DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            Column4 = new DataGridViewTextBoxColumn();
            btnLogOut = new Button();
            btnClear = new Button();
            btnUpdate = new Button();
            btnInsert = new Button();
            iconPictureBox1 = new FontAwesome.Sharp.IconPictureBox();
            pictureBox1 = new PictureBox();
            label10 = new Label();
            label11 = new Label();
            panel2 = new Panel();
            label13 = new Label();
            label12 = new Label();
            iconPictureBox2 = new FontAwesome.Sharp.IconPictureBox();
            pictureBox2 = new PictureBox();
            txtOrigin = new TextBox();
            label3 = new Label();
            btnBack = new Button();
            txtDes = new TextBox();
            label2 = new Label();
            txtDis = new TextBox();
            label4 = new Label();
            pictureBox3 = new PictureBox();
            txtRid = new TextBox();
            txtSearch = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dgvRoute).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(13, 296);
            label1.Name = "label1";
            label1.Size = new Size(81, 19);
            label1.TabIndex = 0;
            label1.Text = "Search ID:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(337, 135);
            label5.Name = "label5";
            label5.Size = new Size(80, 19);
            label5.TabIndex = 0;
            label5.Text = "Route ID :";
            // 
            // dgvRoute
            // 
            dgvRoute.AllowUserToAddRows = false;
            dgvRoute.AllowUserToDeleteRows = false;
            dgvRoute.BackgroundColor = SystemColors.ButtonFace;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dgvRoute.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dgvRoute.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvRoute.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column3, Column4 });
            dgvRoute.Location = new Point(13, 369);
            dgvRoute.Name = "dgvRoute";
            dgvRoute.ReadOnly = true;
            dgvRoute.RowHeadersWidth = 51;
            dgvRoute.Size = new Size(748, 173);
            dgvRoute.TabIndex = 1;
            // 
            // Column1
            // 
            Column1.HeaderText = "RouteID";
            Column1.MinimumWidth = 6;
            Column1.Name = "Column1";
            Column1.ReadOnly = true;
            Column1.Width = 125;
            // 
            // Column2
            // 
            Column2.HeaderText = "Origin";
            Column2.MinimumWidth = 6;
            Column2.Name = "Column2";
            Column2.ReadOnly = true;
            Column2.Width = 140;
            // 
            // Column3
            // 
            Column3.HeaderText = "Destination";
            Column3.MinimumWidth = 6;
            Column3.Name = "Column3";
            Column3.ReadOnly = true;
            Column3.Width = 125;
            // 
            // Column4
            // 
            Column4.HeaderText = "Distance";
            Column4.MinimumWidth = 6;
            Column4.Name = "Column4";
            Column4.ReadOnly = true;
            Column4.Width = 120;
            // 
            // btnLogOut
            // 
            btnLogOut.BackColor = Color.FromArgb(128, 255, 255);
            btnLogOut.BackgroundImageLayout = ImageLayout.Center;
            btnLogOut.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnLogOut.ForeColor = Color.Black;
            btnLogOut.Location = new Point(683, 326);
            btnLogOut.Name = "btnLogOut";
            btnLogOut.Size = new Size(94, 37);
            btnLogOut.TabIndex = 3;
            btnLogOut.Text = "Log Out\r\n";
            btnLogOut.UseVisualStyleBackColor = false;
            // 
            // btnClear
            // 
            btnClear.BackColor = Color.FromArgb(128, 255, 255);
            btnClear.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnClear.ForeColor = Color.Black;
            btnClear.Location = new Point(483, 326);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(94, 37);
            btnClear.TabIndex = 3;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = false;
            // 
            // btnUpdate
            // 
            btnUpdate.BackColor = Color.FromArgb(128, 255, 255);
            btnUpdate.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnUpdate.ForeColor = Color.Black;
            btnUpdate.Location = new Point(383, 326);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(94, 37);
            btnUpdate.TabIndex = 3;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = false;
            // 
            // btnInsert
            // 
            btnInsert.BackColor = Color.FromArgb(128, 255, 255);
            btnInsert.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnInsert.ForeColor = Color.Black;
            btnInsert.Location = new Point(283, 326);
            btnInsert.Name = "btnInsert";
            btnInsert.Size = new Size(94, 37);
            btnInsert.TabIndex = 3;
            btnInsert.Text = "Insert";
            btnInsert.UseVisualStyleBackColor = false;
            // 
            // iconPictureBox1
            // 
            iconPictureBox1.BackColor = Color.FromArgb(255, 255, 128);
            iconPictureBox1.ForeColor = SystemColors.ControlText;
            iconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.Copyright;
            iconPictureBox1.IconColor = SystemColors.ControlText;
            iconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox1.IconSize = 25;
            iconPictureBox1.Location = new Point(141, 47);
            iconPictureBox1.Name = "iconPictureBox1";
            iconPictureBox1.Size = new Size(25, 26);
            iconPictureBox1.TabIndex = 7;
            iconPictureBox1.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(3, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(132, 73);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(172, 52);
            label10.Name = "label10";
            label10.Size = new Size(238, 17);
            label10.TabIndex = 9;
            label10.Text = "Copyright ISAD_M3_25_Group(Roza)";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Times New Roman", 20F, FontStyle.Regular, GraphicsUnit.Point);
            label11.Location = new Point(186, 3);
            label11.Name = "label11";
            label11.Size = new Size(202, 39);
            label11.TabIndex = 9;
            label11.Text = "Ticket's Form";
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(255, 255, 128);
            panel2.Controls.Add(label13);
            panel2.Controls.Add(label12);
            panel2.Controls.Add(iconPictureBox2);
            panel2.Controls.Add(pictureBox2);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(793, 76);
            panel2.TabIndex = 7;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Times New Roman", 20F, FontStyle.Regular, GraphicsUnit.Point);
            label13.Location = new Point(195, 9);
            label13.Name = "label13";
            label13.Size = new Size(198, 39);
            label13.TabIndex = 2;
            label13.Text = "Route's Form";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(195, 56);
            label12.Name = "label12";
            label12.Size = new Size(221, 17);
            label12.TabIndex = 2;
            label12.Text = "Copyright ISAD_M3_Group5(2024)";
            // 
            // iconPictureBox2
            // 
            iconPictureBox2.BackColor = Color.FromArgb(255, 255, 128);
            iconPictureBox2.ForeColor = SystemColors.ControlText;
            iconPictureBox2.IconChar = FontAwesome.Sharp.IconChar.Copyright;
            iconPictureBox2.IconColor = SystemColors.ControlText;
            iconPictureBox2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox2.IconSize = 23;
            iconPictureBox2.Location = new Point(159, 50);
            iconPictureBox2.Name = "iconPictureBox2";
            iconPictureBox2.Size = new Size(30, 23);
            iconPictureBox2.TabIndex = 1;
            iconPictureBox2.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.ErrorImage = null;
            pictureBox2.Location = new Point(3, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(150, 73);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 0;
            pictureBox2.TabStop = false;
            // 
            // txtOrigin
            // 
            txtOrigin.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtOrigin.Location = new Point(509, 170);
            txtOrigin.Name = "txtOrigin";
            txtOrigin.Size = new Size(252, 27);
            txtOrigin.TabIndex = 13;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(337, 176);
            label3.Name = "label3";
            label3.Size = new Size(66, 19);
            label3.TabIndex = 12;
            label3.Text = " Origin :";
            // 
            // btnBack
            // 
            btnBack.BackColor = Color.FromArgb(128, 255, 255);
            btnBack.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnBack.ForeColor = Color.Black;
            btnBack.Location = new Point(583, 326);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(94, 37);
            btnBack.TabIndex = 24;
            btnBack.Text = "Back";
            btnBack.UseVisualStyleBackColor = false;
            // 
            // txtDes
            // 
            txtDes.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtDes.Location = new Point(509, 213);
            txtDes.Name = "txtDes";
            txtDes.Size = new Size(252, 27);
            txtDes.TabIndex = 27;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(337, 219);
            label2.Name = "label2";
            label2.Size = new Size(97, 19);
            label2.TabIndex = 26;
            label2.Text = "Destination :";
            // 
            // txtDis
            // 
            txtDis.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtDis.Location = new Point(509, 257);
            txtDis.Name = "txtDis";
            txtDis.Size = new Size(252, 27);
            txtDis.TabIndex = 29;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(337, 257);
            label4.Name = "label4";
            label4.Size = new Size(78, 19);
            label4.TabIndex = 28;
            label4.Text = "Distance :";
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(13, 129);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(291, 153);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 30;
            pictureBox3.TabStop = false;
            // 
            // txtRid
            // 
            txtRid.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtRid.Location = new Point(509, 129);
            txtRid.Name = "txtRid";
            txtRid.ReadOnly = true;
            txtRid.Size = new Size(252, 27);
            txtRid.TabIndex = 31;
            // 
            // txtSearch
            // 
            txtSearch.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtSearch.Location = new Point(13, 326);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(252, 27);
            txtSearch.TabIndex = 32;
            // 
            // RouteForm
            // 
            AutoScaleDimensions = new SizeF(8F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(793, 551);
            Controls.Add(txtSearch);
            Controls.Add(txtRid);
            Controls.Add(pictureBox3);
            Controls.Add(txtDis);
            Controls.Add(label4);
            Controls.Add(txtDes);
            Controls.Add(label2);
            Controls.Add(btnBack);
            Controls.Add(txtOrigin);
            Controls.Add(label3);
            Controls.Add(panel2);
            Controls.Add(dgvRoute);
            Controls.Add(btnInsert);
            Controls.Add(btnUpdate);
            Controls.Add(btnClear);
            Controls.Add(btnLogOut);
            Controls.Add(label5);
            Controls.Add(label1);
            Font = new Font("Times New Roman", 9F, FontStyle.Regular, GraphicsUnit.Point);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "RouteForm";
            Text = "Route's Form";
            Load += RouteForm_Load;
            ((System.ComponentModel.ISupportInitialize)dgvRoute).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private Label label1;
        private Label label5;
        private DataGridView dgvRoute;
        private Button btnLogOut;
        private Button btnClear;
        private Button btnUpdate;
        private Button btnInsert;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox1;
#pragma warning disable CS0169 // The field 'Ticket.panel1' is never used
#pragma warning restore CS0169 // The field 'Ticket.panel1' is never used
        private Label label10;
        private PictureBox pictureBox1;
        private Label label11;
#pragma warning disable CS0649 // Field 'Ticket.panel1_Paint' is never assigned to, and will always have its default value null
        private Panel panel2;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox2;
        private Label label13;
        private Label label12;

        private PictureBox pictureBox2;
        private TextBox txtOrigin;
        private Label label3;
        private Button btnBack;
        private TextBox txtDes;
        private Label label2;
        private TextBox txtDis;
        private Label label4;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column4;
        private PictureBox pictureBox3;
        private TextBox txtRid;
        private TextBox txtSearch;
    }
}