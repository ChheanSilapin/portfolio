﻿using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using PAGTMS.Ultils;
using System.Text.Json;
using System.Xml;

namespace PAGTMS;

public partial class DatabaseConfigurationForm : Form
{
    public static IConfiguration? Configuration { get; set; } = null;
    string? ConnectionStringToDatabase;
    public DatabaseConfigurationForm()
    {
        InitializeComponent();
        cbAthor.SelectedIndex = -1;
        txtUserName.Enabled = false;
        txtPassword.Enabled = false;
        cbAthor.SelectedValueChanged += Select_Handling_Authentication;
        LoadConfiguration("DBConnectionFormat.json");
        btnConnect.Click += DoClickConnect;


    }
    private void DoClickConnect(object? sender, EventArgs e)
    {
        if (txtServerName.Text == "") { MessageBox.Show("Server name is required!!!"); return; }
        if (txtDatabaseName.Text == "") { MessageBox.Show("Database name is required!!!"); return; }
        if (cbAthor.SelectedItem == null) { MessageBox.Show("Authentication is required!!!"); return; }

        if (cbAthor.SelectedItem.ToString().Equals("SQL Server Authentication"))
        {
            if (txtUserName.Text == "") { MessageBox.Show("User is required!!!"); return; }
            if (txtPassword.Text == "") { MessageBox.Show("Password is required!!!"); return; }
            ConnectionStringToDatabase = string.Format(ConnectionStringToDatabase, txtServerName.Text, txtDatabaseName.Text, txtUserName.Text, txtPassword.Text);
        }
        else
        {
            ConnectionStringToDatabase = string.Format(ConnectionStringToDatabase, txtServerName.Text, txtDatabaseName.Text);
        }
        DBConnection dBConnection = new DBConnection();
        dBConnection.DBConnectionString = ConnectionStringToDatabase;
        string dbJsonData = JsonConvert.SerializeObject(dBConnection);
        File.WriteAllText($"{Environment.CurrentDirectory}/appSettings.json", dbJsonData);
        LoginForm loginForm = new LoginForm(this);
        loginForm.Show();
        this.Hide();
    }
    private void Select_Handling_Authentication(object? sender, EventArgs e)
    {
        if (cbAthor.SelectedItem != null)
        {
            string? authentication = cbAthor.SelectedItem.ToString();
            if (authentication == null) return;
            if (authentication.Equals("SQL Server Authentication"))
            {
                txtUserName.Enabled = true;
                txtPassword.Enabled = true;
                ConnectionStringToDatabase = GetDBConnectionSetting("DBConnectionStringServerAuth");
            }
            else
            {
                txtUserName.Enabled = false;
                txtPassword.Enabled = false;
                txtUserName.Clear();
                txtPassword.Clear();
                ConnectionStringToDatabase = GetDBConnectionSetting("DBConnectionStringWindowAuth");
            }
        }
    }

    public static void LoadConfiguration(string jsonFile)
    {
        var builder = new ConfigurationBuilder()
          .AddJsonFile(jsonFile, optional: false, reloadOnChange: true);
        Configuration = builder.Build();
    }

    private static string GetDBConnectionSetting(string connectionType)
    {
        var procSettingSection = Configuration.GetRequiredSection($"{connectionType}");
        string? procSetting = procSettingSection.Value;
        return procSetting;
    }
    class DBConnection
    {
        public string? DBConnectionString { get; set; }
    }
}
