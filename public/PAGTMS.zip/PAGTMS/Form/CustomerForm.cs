﻿using PAGTMS.Models;
using PAGTMS.Ultils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAGTMS;

public partial class CustomerForm : Form
{
    Customer? effectedCustomer = null;
    List<string> ListCustomer = new List<string>();
    int CustomerCount = 0;
    int IndexOfUpdateCustomer;
    private MainForm mainFormReference;
    private LoginForm loginFormReference;
    public CustomerForm(MainForm mainform,LoginForm loginForm)
    {
        InitializeComponent();
        mainFormReference = mainform;
        loginFormReference = loginForm;
        this.FormClosed += new FormClosedEventHandler((_, _) => mainFormReference.Show());
        btnInsert.Click += DoClickInsertCustomer;
        btnUpdate.Click += DoClickUpdateCustomer;
        btnClear.Click += DoClickClear;
        btnBack.Click += (_, _) => this.Close();
        LsCustomer.SelectedIndexChanged += Select_Handling_Customer;
        txtSearch.TextChanged += SearchFunction;
        ListCustomer.Clear();
        btnLogOut.Click += (_, _) => { this.Hide();  loginFormReference.Show(); };
    }

    private void SearchFunction(object? sender, EventArgs e)
    {
        if (string.IsNullOrEmpty(txtSearch.Text) == false)
        {
            LsCustomer.Items.Clear();
            foreach (string customer in ListCustomer)

            {
                string[] splitText = customer.Split('.');
                if (splitText[1].Trim().StartsWith(txtSearch.Text, StringComparison.OrdinalIgnoreCase))
                {
                    LsCustomer.Items.Add(customer);
                }
            }
        }
        else if (txtSearch.Text == "")
        {
            LsCustomer.Items.Clear();
            foreach (string customer in ListCustomer)
            {
                LsCustomer.Items.Add(customer);
            }
        }
    }

    private void DoClickUpdateCustomer(object? sender, EventArgs e)
    {
        if (effectedCustomer != null)
        {
            effectedCustomer.CustomerID = int.Parse(txtCid.Text.Trim());
            effectedCustomer.CustomerName = txtCusName.Text.Trim();
            effectedCustomer.Gender = cbSex.SelectedItem.ToString();
            effectedCustomer.CusAge = Int16.Parse(txtCusAge.Text);
            effectedCustomer.CustomerContactInfo = txtCusInfo.Text.Trim();

            try
            {
                var result = CustomerFunc.UpdateCustomer(Program.Connection, effectedCustomer);
                if (result == true)
                    MessageBox.Show($"Successfully updated an existing Customer with the id : {effectedCustomer.CustomerID} Updated!", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                foreach (string checkcustomer in ListCustomer)
                {
                    string[] splitText = checkcustomer.Split('.');
                    if (splitText[0].Trim().Equals(effectedCustomer.CustomerID.ToString()))
                    {
                        IndexOfUpdateCustomer = ListCustomer.IndexOf(checkcustomer);
                        ListCustomer.Remove(checkcustomer);
                        break;
                    }
                }
                ListCustomer.Insert(IndexOfUpdateCustomer, $"{effectedCustomer.CustomerID}.{effectedCustomer.CustomerName}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to update Updated! {ex.Message}", "Updating", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
        LoadingDataCustomer();

    }
    private void DoClickInsertCustomer(object? sender, EventArgs e)
    {
        if (int.TryParse(txtCid.Text, out int customerID) == false)
        {
            MessageBox.Show("Customer ID is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (txtCusName.Text == "")
        {
            MessageBox.Show("CustomerName is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }

        if (cbSex.Text == "")
        {
            MessageBox.Show("Customer Gender is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (Int16.TryParse(txtCusAge.Text, out Int16 cusAge) == false)
        {
            MessageBox.Show("Customer ID is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (txtCusInfo.Text == "")
        {
            MessageBox.Show("Customer ContactInfo is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        Customer newCustomer = new Customer()
        {
            CustomerID = customerID,
            CustomerName = txtCusName.Text.Trim(),
            Gender = cbSex.Text.Trim(),
            CusAge = cusAge,
            CustomerContactInfo = txtCusInfo.Text.Trim(),
        };
        try
        {
            CustomerFunc.AddCustomer(Program.Connection, newCustomer);
            MessageBox.Show($"Successfully Inserted an New Customer!", "Inserted", MessageBoxButtons.OK, MessageBoxIcon.Information);
            ListCustomer.Add($"{txtCid.Text}.{newCustomer.CustomerName}");
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Submitting", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        LoadingDataCustomer();
    }
    private void Select_Handling_Customer(object? sender, EventArgs e)
    {

        if (LsCustomer.SelectedItem != null)
        {
            string? customerData = LsCustomer.SelectedItems[0].ToString();
            if (customerData == null) return;
            string[] tempData = customerData.Split('.');
            try
            {
                effectedCustomer = CustomerFunc.GetOneCustomer(Program.Connection, int.Parse(tempData[0].Trim()));
                txtCid.Text = effectedCustomer.CustomerID.ToString();
                txtCusName.Text = effectedCustomer.CustomerName;
                cbSex.Text = effectedCustomer.Gender;
                txtCusAge.Text = effectedCustomer.CusAge.ToString();
                txtCusInfo.Text = effectedCustomer.CustomerContactInfo;

            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}");
            }

        }
    }
    private void DoClickClear(object? sender, EventArgs e)
    {

        txtCid.Text = (CustomerCount + 1).ToString();
        txtCusName.Clear();
        txtCusAge.Clear();
        cbSex.SelectedItem = null;
        txtCusInfo.Clear();
    }
    private void CustomerForm_Load(object sender, EventArgs e)
    {
        LoadingDataCustomer();
        txtCid.Text = (CustomerCount + 1).ToString();
        foreach (string customer in LsCustomer.Items)
        {
            ListCustomer.Add(customer);
            txtSearch.CharacterCasing = CharacterCasing.Normal;
        }
    }
    private void LoadingDataCustomer()
    {
        try
        {
            var result = CustomerFunc.GetAllCustomer(Program.Connection);
            if (result.LastOrDefault() != null) { CustomerCount = result.LastOrDefault().CustomerID; }
            else { CustomerCount = 0; }
            LsCustomer.Items.Clear();
            foreach (var customer in result)
            {

                LsCustomer.Items.Add($"{customer.CustomerID}. {customer.CustomerName}");

            }
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Retriving customer", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

}
