﻿namespace PAGTMS
{
    partial class InvoiceForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InvoiceForm));
            label1 = new Label();
            label5 = new Label();
            label6 = new Label();
            btnLogOut = new Button();
            btnClear = new Button();
            btnUpdate = new Button();
            btnInsert = new Button();
            iconPictureBox1 = new FontAwesome.Sharp.IconPictureBox();
            pictureBox1 = new PictureBox();
            label10 = new Label();
            label11 = new Label();
            panel2 = new Panel();
            pictureBox2 = new PictureBox();
            label13 = new Label();
            label12 = new Label();
            iconPictureBox2 = new FontAwesome.Sharp.IconPictureBox();
            cbCustomerID = new ComboBox();
            label3 = new Label();
            btnBack = new Button();
            txtCusInfo = new TextBox();
            label2 = new Label();
            txtTamt = new TextBox();
            label4 = new Label();
            dtId = new DateTimePicker();
            txtCusname = new TextBox();
            label7 = new Label();
            txtStna = new TextBox();
            label8 = new Label();
            label9 = new Label();
            txtStpos = new TextBox();
            cbStaffID = new ComboBox();
            label14 = new Label();
            txtPamt = new TextBox();
            label15 = new Label();
            LsInvoice = new ListBox();
            txtSearch = new TextBox();
            txtInid = new TextBox();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(12, 87);
            label1.Name = "label1";
            label1.Size = new Size(175, 19);
            label1.TabIndex = 0;
            label1.Text = "Search CustomerName :";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(286, 93);
            label5.Name = "label5";
            label5.Size = new Size(85, 19);
            label5.TabIndex = 0;
            label5.Text = "InvoiceID :";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(284, 279);
            label6.Name = "label6";
            label6.Size = new Size(166, 19);
            label6.TabIndex = 0;
            label6.Text = "Customer ContactInfo:";
            // 
            // btnLogOut
            // 
            btnLogOut.BackColor = Color.FromArgb(128, 255, 255);
            btnLogOut.BackgroundImageLayout = ImageLayout.Center;
            btnLogOut.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnLogOut.ForeColor = Color.Black;
            btnLogOut.Location = new Point(644, 452);
            btnLogOut.Name = "btnLogOut";
            btnLogOut.Size = new Size(94, 37);
            btnLogOut.TabIndex = 3;
            btnLogOut.Text = "Log Out\r\n";
            btnLogOut.UseVisualStyleBackColor = false;
            // 
            // btnClear
            // 
            btnClear.BackColor = Color.FromArgb(128, 255, 255);
            btnClear.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnClear.ForeColor = Color.Black;
            btnClear.Location = new Point(315, 452);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(94, 37);
            btnClear.TabIndex = 3;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = false;
            // 
            // btnUpdate
            // 
            btnUpdate.BackColor = Color.FromArgb(128, 255, 255);
            btnUpdate.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnUpdate.ForeColor = Color.Black;
            btnUpdate.Location = new Point(159, 452);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(94, 37);
            btnUpdate.TabIndex = 3;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = false;
            // 
            // btnInsert
            // 
            btnInsert.BackColor = Color.FromArgb(128, 255, 255);
            btnInsert.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnInsert.ForeColor = Color.Black;
            btnInsert.Location = new Point(12, 452);
            btnInsert.Name = "btnInsert";
            btnInsert.Size = new Size(94, 37);
            btnInsert.TabIndex = 3;
            btnInsert.Text = "Insert";
            btnInsert.UseVisualStyleBackColor = false;
            // 
            // iconPictureBox1
            // 
            iconPictureBox1.BackColor = Color.FromArgb(255, 255, 128);
            iconPictureBox1.ForeColor = SystemColors.ControlText;
            iconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.Copyright;
            iconPictureBox1.IconColor = SystemColors.ControlText;
            iconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox1.IconSize = 25;
            iconPictureBox1.Location = new Point(141, 47);
            iconPictureBox1.Name = "iconPictureBox1";
            iconPictureBox1.Size = new Size(25, 26);
            iconPictureBox1.TabIndex = 7;
            iconPictureBox1.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(3, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(132, 73);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(172, 52);
            label10.Name = "label10";
            label10.Size = new Size(238, 17);
            label10.TabIndex = 9;
            label10.Text = "Copyright ISAD_M3_25_Group(Roza)";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Times New Roman", 20F, FontStyle.Regular, GraphicsUnit.Point);
            label11.Location = new Point(186, 3);
            label11.Name = "label11";
            label11.Size = new Size(202, 39);
            label11.TabIndex = 9;
            label11.Text = "Ticket's Form";
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(255, 255, 128);
            panel2.Controls.Add(pictureBox2);
            panel2.Controls.Add(label13);
            panel2.Controls.Add(label12);
            panel2.Controls.Add(iconPictureBox2);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(777, 76);
            panel2.TabIndex = 7;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(0, 3);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(153, 73);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 31;
            pictureBox2.TabStop = false;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Times New Roman", 20F, FontStyle.Regular, GraphicsUnit.Point);
            label13.Location = new Point(195, 9);
            label13.Name = "label13";
            label13.Size = new Size(216, 39);
            label13.TabIndex = 2;
            label13.Text = "Invoice's Form";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(195, 56);
            label12.Name = "label12";
            label12.Size = new Size(221, 17);
            label12.TabIndex = 2;
            label12.Text = "Copyright ISAD_M3_Group5(2024)";
            // 
            // iconPictureBox2
            // 
            iconPictureBox2.BackColor = Color.FromArgb(255, 255, 128);
            iconPictureBox2.ForeColor = SystemColors.ControlText;
            iconPictureBox2.IconChar = FontAwesome.Sharp.IconChar.Copyright;
            iconPictureBox2.IconColor = SystemColors.ControlText;
            iconPictureBox2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox2.IconSize = 23;
            iconPictureBox2.Location = new Point(159, 50);
            iconPictureBox2.Name = "iconPictureBox2";
            iconPictureBox2.Size = new Size(30, 23);
            iconPictureBox2.TabIndex = 1;
            iconPictureBox2.TabStop = false;
            // 
            // cbCustomerID
            // 
            cbCustomerID.DropDownStyle = ComboBoxStyle.DropDownList;
            cbCustomerID.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            cbCustomerID.FormattingEnabled = true;
            cbCustomerID.Location = new Point(479, 211);
            cbCustomerID.Name = "cbCustomerID";
            cbCustomerID.Size = new Size(259, 27);
            cbCustomerID.TabIndex = 8;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(286, 124);
            label3.Name = "label3";
            label3.Size = new Size(100, 19);
            label3.TabIndex = 12;
            label3.Text = "InvoiceDate :";
            // 
            // btnBack
            // 
            btnBack.BackColor = Color.FromArgb(128, 255, 255);
            btnBack.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnBack.ForeColor = Color.Black;
            btnBack.Location = new Point(479, 452);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(94, 37);
            btnBack.TabIndex = 24;
            btnBack.Text = "Back";
            btnBack.UseVisualStyleBackColor = false;
            // 
            // txtCusInfo
            // 
            txtCusInfo.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtCusInfo.Location = new Point(479, 273);
            txtCusInfo.Name = "txtCusInfo";
            txtCusInfo.ReadOnly = true;
            txtCusInfo.Size = new Size(259, 27);
            txtCusInfo.TabIndex = 27;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(286, 155);
            label2.Name = "label2";
            label2.Size = new Size(121, 19);
            label2.TabIndex = 26;
            label2.Text = "Invoice Amount:";
            // 
            // txtTamt
            // 
            txtTamt.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtTamt.Location = new Point(479, 149);
            txtTamt.Name = "txtTamt";
            txtTamt.Size = new Size(259, 27);
            txtTamt.TabIndex = 29;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(284, 217);
            label4.Name = "label4";
            label4.Size = new Size(106, 19);
            label4.TabIndex = 28;
            label4.Text = "CustomerID  :";
            // 
            // dtId
            // 
            dtId.CustomFormat = "yyyy/MM/dd";
            dtId.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            dtId.Location = new Point(479, 118);
            dtId.Name = "dtId";
            dtId.Size = new Size(259, 27);
            dtId.TabIndex = 30;
            // 
            // txtCusname
            // 
            txtCusname.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtCusname.Location = new Point(479, 242);
            txtCusname.Name = "txtCusname";
            txtCusname.ReadOnly = true;
            txtCusname.Size = new Size(259, 27);
            txtCusname.TabIndex = 32;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label7.Location = new Point(284, 248);
            label7.Name = "label7";
            label7.Size = new Size(125, 19);
            label7.TabIndex = 31;
            label7.Text = "CustomerName :";
            // 
            // txtStna
            // 
            txtStna.Font = new Font("Khmer OS Siemreap", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtStna.Location = new Point(479, 335);
            txtStna.Name = "txtStna";
            txtStna.ReadOnly = true;
            txtStna.Size = new Size(259, 35);
            txtStna.TabIndex = 39;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label8.Location = new Point(285, 351);
            label8.Name = "label8";
            label8.Size = new Size(111, 19);
            label8.TabIndex = 38;
            label8.Text = "StaffNameKh :";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label9.Location = new Point(285, 310);
            label9.Name = "label9";
            label9.Size = new Size(72, 19);
            label9.TabIndex = 37;
            label9.Text = "StaffID  :";
            // 
            // txtStpos
            // 
            txtStpos.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtStpos.Location = new Point(479, 376);
            txtStpos.Name = "txtStpos";
            txtStpos.ReadOnly = true;
            txtStpos.Size = new Size(259, 27);
            txtStpos.TabIndex = 36;
            // 
            // cbStaffID
            // 
            cbStaffID.DropDownStyle = ComboBoxStyle.DropDownList;
            cbStaffID.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            cbStaffID.FormattingEnabled = true;
            cbStaffID.Location = new Point(479, 304);
            cbStaffID.Name = "cbStaffID";
            cbStaffID.Size = new Size(259, 27);
            cbStaffID.TabIndex = 35;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label14.Location = new Point(284, 382);
            label14.Name = "label14";
            label14.Size = new Size(109, 19);
            label14.TabIndex = 33;
            label14.Text = "StaffPosition :";
            // 
            // txtPamt
            // 
            txtPamt.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtPamt.Location = new Point(479, 180);
            txtPamt.Name = "txtPamt";
            txtPamt.Size = new Size(259, 27);
            txtPamt.TabIndex = 41;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label15.Location = new Point(284, 186);
            label15.Name = "label15";
            label15.Size = new Size(101, 19);
            label15.TabIndex = 40;
            label15.Text = "Paid Amount:";
            // 
            // LsInvoice
            // 
            LsInvoice.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            LsInvoice.FormattingEnabled = true;
            LsInvoice.ItemHeight = 19;
            LsInvoice.Location = new Point(12, 160);
            LsInvoice.Name = "LsInvoice";
            LsInvoice.Size = new Size(249, 270);
            LsInvoice.TabIndex = 42;
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(12, 119);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(249, 25);
            txtSearch.TabIndex = 43;
            // 
            // txtInid
            // 
            txtInid.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtInid.Location = new Point(479, 87);
            txtInid.Name = "txtInid";
            txtInid.ReadOnly = true;
            txtInid.Size = new Size(259, 27);
            txtInid.TabIndex = 44;
            // 
            // InvoiceForm
            // 
            AutoScaleDimensions = new SizeF(8F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(777, 501);
            Controls.Add(txtInid);
            Controls.Add(txtSearch);
            Controls.Add(LsInvoice);
            Controls.Add(txtPamt);
            Controls.Add(label15);
            Controls.Add(txtStna);
            Controls.Add(label8);
            Controls.Add(label9);
            Controls.Add(txtStpos);
            Controls.Add(cbStaffID);
            Controls.Add(label14);
            Controls.Add(txtCusname);
            Controls.Add(label7);
            Controls.Add(dtId);
            Controls.Add(txtTamt);
            Controls.Add(label4);
            Controls.Add(txtCusInfo);
            Controls.Add(label2);
            Controls.Add(btnBack);
            Controls.Add(label3);
            Controls.Add(cbCustomerID);
            Controls.Add(panel2);
            Controls.Add(btnInsert);
            Controls.Add(btnUpdate);
            Controls.Add(btnClear);
            Controls.Add(btnLogOut);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label1);
            Font = new Font("Times New Roman", 9F, FontStyle.Regular, GraphicsUnit.Point);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "InvoiceForm";
            Text = "Invoice's Form";
            Load += InvoiceForm_Load;
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private Label label1;
        private Label label5;
        private Label label6;
        private Button btnLogOut;
        private Button btnClear;
        private Button btnUpdate;
        private Button btnInsert;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox1;
#pragma warning disable CS0169 // The field 'Ticket.panel1' is never used
#pragma warning restore CS0169 // The field 'Ticket.panel1' is never used
        private Label label10;
        private PictureBox pictureBox1;
        private Label label11;
#pragma warning disable CS0649 // Field 'Ticket.panel1_Paint' is never assigned to, and will always have its default value null
        private Panel panel2;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox2;
        private Label label13;
        private Label label12;
        private ComboBox cbCustomerID;
        private Label label3;
        private Button btnBack;
        private TextBox txtCusInfo;
        private Label label2;
        private TextBox txtTamt;
        private Label label4;
        private DateTimePicker dtId;
        private TextBox txtCusname;
        private Label label7;
        private TextBox txtStna;
        private Label label8;
        private Label label9;
        private TextBox txtStpos;
        private ComboBox cbStaffID;
        private Label label14;
        private PictureBox pictureBox2;
        private TextBox txtPamt;
        private Label label15;
        private ListBox LsInvoice;
        private TextBox txtSearch;
        private TextBox txtInid;
    }
}