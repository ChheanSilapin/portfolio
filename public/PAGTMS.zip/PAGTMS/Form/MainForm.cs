namespace PAGTMS;

public partial class MainForm : Form
{
    private LoginForm loginFormReference;
    private DatabaseConfigurationForm databaseConfigurationFormReference;
    public MainForm(DatabaseConfigurationForm databaseConfigurationForm, LoginForm login)
    {
        InitializeComponent();
        loginFormReference = login;
        databaseConfigurationFormReference = databaseConfigurationForm;
        this.FormClosed += new FormClosedEventHandler(MainForm_FormClosed);
        btnCus.Click += (_, _) => { this.Hide(); new CustomerForm(this,login).Show(); };
        btnStaff.Click += (_, _) => { this.Hide(); new StaffForm(this,login).Show(); };
        btnVehicle.Click += (_, _) => { this.Hide(); new VehicleForm(this,login).Show(); };
        btnRoute.Click += (_, _) => { this.Hide(); new RouteForm(this,login).Show(); };
        btnBooking.Click += (_, _) => { this.Hide(); new BookingForm(this,login).Show(); };
        btnTransport.Click += (_, _) => { this.Hide(); new TransportForm(this,login).Show(); };
        btnItem.Click += (_, _) => { this.Hide(); new ItemForm(this, login).Show(); };
        btnPayment.Click += (_, _) => { this.Hide(); new PaymentForm(this,login).Show(); };
        btnInvoice.Click += (_, _) => { this.Hide(); new InvoiceForm(this,login).Show(); };
        btnTicket.Click += (_, _) => { this.Hide(); new TicketForm(this,login).Show(); };
        btnUser.Click += (_, _) => { this.Hide(); new UserForm(this,login).Show(); };
        btnLogOut.Click += (_, _) => { this.Hide(); loginFormReference.Show(); };
    }
    private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
    {
        loginFormReference.Close();
        databaseConfigurationFormReference.Close();
    }
}