﻿using PAGTMS.Models;
using PAGTMS.Ultils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAGTMS;

public partial class InvoiceForm : Form
{
    private MainForm mainFormReference;
    Customer? effectedCustomer = null;
    Staff? effectedStaff = null;
    Invoice? effectedInvoice = null;
    List<string> ListInvoice = new List<string>();
    int InvoiceCount = 0;
    int IndexOfUpdateInvoice;
    private LoginForm loginFormReference;
    public InvoiceForm(MainForm mainForm,LoginForm loginForm)
    {
        InitializeComponent();
        mainFormReference = mainForm;
        loginFormReference = loginForm;
        this.FormClosed += new FormClosedEventHandler((_, _) => mainFormReference.Show());
        btnClear.Click += DoClickNewFormInput;
        btnBack.Click += (_, _) => this.Close();
        cbStaffID.SelectedValueChanged += Select_Handling_StaffID;
        cbCustomerID.SelectedValueChanged += Select_Handling_CusID;
        LsInvoice.SelectedValueChanged += Select_Handling_Invoice;
        btnInsert.Click += DoClickInsertInvoice;
        btnUpdate.Click += DoClickUpdateInvoice;
        txtSearch.TextChanged += SearchFunction;
        ListInvoice.Clear();
        dtId.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
        btnLogOut.Click += (_, _) => { this.Hide(); loginFormReference.Show(); };
    }

    private void SearchFunction(object? sender, EventArgs e)
    {
        if (string.IsNullOrEmpty(txtSearch.Text) == false)
        {
            LsInvoice.Items.Clear();
            foreach (string invoice in ListInvoice)

            {
                string[] splitText = invoice.Split('.');
                if (splitText[1].Trim().StartsWith(txtSearch.Text, StringComparison.OrdinalIgnoreCase))
                {
                    LsInvoice.Items.Add(invoice);
                }
            }
        }
        else if (txtSearch.Text == "")
        {
            LsInvoice.Items.Clear();
            foreach (string invoice in ListInvoice)
            {
                LsInvoice.Items.Add(invoice);
            }
        }
    }

    private void DoClickUpdateInvoice(object? sender, EventArgs e)
    {
        if (effectedInvoice != null)
        {
            effectedInvoice.InvoiceID = int.Parse(txtInid.Text.Trim());
            effectedInvoice.InvoiceDate = dtId.Value;
            effectedInvoice.TotalAmount = decimal.Parse(txtTamt.Text.Trim());
            effectedInvoice.PaidAmount = decimal.Parse(txtPamt.Text.Trim());
            effectedInvoice.CustomerID = int.Parse(cbCustomerID.SelectedValue.ToString().Trim());
            effectedInvoice.CustomerName = txtCusname.Text.Trim();
            effectedInvoice.CustomerContactInfo = txtCusInfo.Text.Trim();
            effectedInvoice.StaffID = int.Parse(cbStaffID.SelectedValue.ToString().Trim());
            effectedInvoice.StaffNameKh = txtStna.Text.Trim();
            effectedInvoice.StaffPosition = txtStpos.Text.Trim();
            try
            {
                var result = InvoiceFunc.UpdateInvoice(Program.Connection, effectedInvoice);
                if (result == true)
                    MessageBox.Show($"Successfully updated!!", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                foreach (string checkinvoice in ListInvoice)
                {
                    string[] splitText = checkinvoice.Split('.');
                    if (splitText[0].Trim().Equals(effectedInvoice.InvoiceID.ToString()))
                    {
                        IndexOfUpdateInvoice = ListInvoice.IndexOf(checkinvoice);
                        ListInvoice.Remove(checkinvoice);
                        break;
                    }
                }
                ListInvoice.Insert(IndexOfUpdateInvoice, $"{effectedInvoice.InvoiceID}.{effectedInvoice.CustomerName}");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Update Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        LoadingDataInvoice();
    }

    private void DoClickInsertInvoice(object? sender, EventArgs e)
    {
        if (int.TryParse(txtInid.Text, out int invoiceID) == false)
        {
            MessageBox.Show("Inovice ID is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (dtId.Text == "")
        {
            MessageBox.Show("InvoiceDate is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (decimal.TryParse(txtTamt.Text, out decimal totalAmount) == false)
        {
            MessageBox.Show("TotalAmount is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
        }
        if (decimal.TryParse(txtPamt.Text, out decimal paidAmount) == false)
        {
            MessageBox.Show("PaidAmount is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
        }
        if (cbCustomerID.SelectedItem == null)
        {
            MessageBox.Show("Customer ID is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }
        if (cbStaffID.SelectedItem == null)
        {
            MessageBox.Show("Staff ID is required", "Creating",
            MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }

        string? customerID = cbCustomerID.SelectedItem.ToString();
        if (customerID == null) return;
        string? staffID = cbStaffID.SelectedItem.ToString();
        if (staffID == null) return;
        Invoice newInvoice = new Invoice()
        {
            InvoiceID = invoiceID,
            InvoiceDate = dtId.Value,
            TotalAmount = totalAmount,
            PaidAmount = paidAmount,
            CustomerID = int.Parse(customerID.Trim()),
            CustomerName = txtCusname.Text.Trim(),
            CustomerContactInfo = txtCusInfo.Text.Trim(),
            StaffID = int.Parse(staffID.Trim()),
            StaffNameKh = txtStna.Text.Trim(),
            StaffPosition = txtStpos.Text.Trim(),
        };
        try
        {
            InvoiceFunc.AddInvoice(Program.Connection, newInvoice);
            MessageBox.Show($"Inserted!!", "Add New Invoice", MessageBoxButtons.OK, MessageBoxIcon.Information);
            ListInvoice.Add($"{txtInid.Text}.{newInvoice.CustomerName}");
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Submitting", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        LoadingDataInvoice();
    }
    private void Select_Handling_Invoice(object? sender, EventArgs e)
    {
        if (LsInvoice.SelectedItem != null)
        {
            string? invoiceData = LsInvoice.SelectedItems[0].ToString();
            if (invoiceData == null) return;
            string[] tempData = invoiceData.Split('.');
            try
            {
                effectedInvoice = InvoiceFunc.GetOneInvoice(Program.Connection, int.Parse(tempData[0].Trim()));
                txtInid.Text = effectedInvoice.InvoiceID.ToString();
                dtId.Value = (DateTime)effectedInvoice.InvoiceDate;
                txtTamt.Text = effectedInvoice.TotalAmount.ToString();
                txtPamt.Text = effectedInvoice.PaidAmount.ToString();
                cbCustomerID.SelectedItem = effectedInvoice.CustomerID.ToString();
                txtCusname.Text = effectedInvoice.CustomerName;
                txtCusInfo.Text = effectedInvoice.CustomerContactInfo;
                cbStaffID.SelectedItem = effectedInvoice.StaffID.ToString();
                txtStna.Text = effectedInvoice.StaffNameKh;
                txtStpos.Text = effectedInvoice.StaffPosition;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}");
            }
        }
    }

    private void Select_Handling_CusID(object? sender, EventArgs e)
    {
        if (cbCustomerID.SelectedItem != null)
        {
            string? customerID = cbCustomerID.SelectedItem.ToString();
            if (customerID == null) return;
            try
            {
                effectedCustomer = CustomerFunc.GetOneCustomer(Program.Connection, int.Parse(customerID.Trim()));
                txtCusname.Text = effectedCustomer.CustomerName;
                txtCusInfo.Text = effectedCustomer.CustomerContactInfo;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}");
            }
        }
    }

    private void Select_Handling_StaffID(object? sender, EventArgs e)
    {
        if (cbStaffID.SelectedItem != null)
        {
            string? staffID = cbStaffID.SelectedItem.ToString();
            if (staffID == null) return;
            try
            {
                effectedStaff = StaffFunc.GetOneStaff(Program.Connection, int.Parse(staffID.Trim()));
                txtStna.Text = effectedStaff.StaffNameKH;
                txtStpos.Text = effectedStaff.StaffPosition;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}");
            }
        }
    }

    private void DoClickNewFormInput(object? sender, EventArgs e)
    {
        txtInid.Text = (InvoiceCount + 1).ToString();
        dtId.ResetText();
        txtTamt.Clear();
        txtPamt.Clear();
        cbCustomerID.SelectedItem = null;
        txtCusname.Clear();
        txtCusInfo.Clear();
        cbStaffID.SelectedItem = null;
        txtStna.Clear();
        txtStpos.Clear();
    }

    private void InvoiceForm_Load(object sender, EventArgs e)
    {
        LoadingDataCustomerID();
        LoadingDataStaffID();
        LoadingDataInvoice();
        txtInid.Text = (InvoiceCount + 1).ToString();
        foreach (string invoice in LsInvoice.Items)
        {
            ListInvoice.Add(invoice);
            txtSearch.CharacterCasing = CharacterCasing.Normal;
        }

    }
    private void LoadingDataStaffID()
    {
        try
        {
            var result = StaffFunc.GetAllStaff(Program.Connection);
            List<string> ls = new List<string>();
            foreach (var staff in result)
            {
                ls.Add(staff.StaffID.ToString());

            }
            cbStaffID.DataSource = ls;
            cbStaffID.SelectedIndex = -1;
            txtStna.Clear();
            txtStpos.Clear();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Retriving Staff", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void LoadingDataCustomerID()
    {
        try
        {
            var result = CustomerFunc.GetAllCustomer(Program.Connection);
            List<string> ls = new List<string>();
            foreach (var customer in result)
            {
                ls.Add(customer.CustomerID.ToString());

            }
            cbCustomerID.DataSource = ls;
            cbCustomerID.SelectedIndex = -1;
            txtCusname.Clear();
            txtCusInfo.Clear();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Retriving User", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void LoadingDataInvoice()
    {
        try
        {
            var result = InvoiceFunc.GetAllInvoice(Program.Connection);
            if (result.LastOrDefault() != null) { InvoiceCount = result.LastOrDefault().InvoiceID; }
            else { InvoiceCount = 0; }
            LsInvoice.Items.Clear();
            foreach (var invoice in result)
            {

                LsInvoice.Items.Add($"{invoice.InvoiceID}.{invoice.CustomerName}");

            }
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Retriving Payment", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }


}
