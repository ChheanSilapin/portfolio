﻿namespace PAGTMS
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            iconPictureBox1 = new FontAwesome.Sharp.IconPictureBox();
            pictureBox1 = new PictureBox();
            label10 = new Label();
            label11 = new Label();
            panel2 = new Panel();
            pictureBox14 = new PictureBox();
            label13 = new Label();
            label12 = new Label();
            iconPictureBox2 = new FontAwesome.Sharp.IconPictureBox();
            pictureBox3 = new PictureBox();
            btnCus = new Button();
            btnStaff = new Button();
            pictureBox2 = new PictureBox();
            btnVehicle = new Button();
            pictureBox4 = new PictureBox();
            btnRoute = new Button();
            pictureBox5 = new PictureBox();
            btnBooking = new Button();
            pictureBox6 = new PictureBox();
            btnTransport = new Button();
            pictureBox7 = new PictureBox();
            btnItem = new Button();
            pictureBox8 = new PictureBox();
            btnPayment = new Button();
            pictureBox9 = new PictureBox();
            btnInvoice = new Button();
            pictureBox10 = new PictureBox();
            btnTicket = new Button();
            btnUser = new Button();
            pictureBox12 = new PictureBox();
            pictureBox13 = new PictureBox();
            btnLogOut = new Button();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).BeginInit();
            SuspendLayout();
            // 
            // iconPictureBox1
            // 
            iconPictureBox1.BackColor = Color.FromArgb(255, 255, 128);
            iconPictureBox1.ForeColor = SystemColors.ControlText;
            iconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.Copyright;
            iconPictureBox1.IconColor = SystemColors.ControlText;
            iconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox1.IconSize = 25;
            iconPictureBox1.Location = new Point(141, 47);
            iconPictureBox1.Name = "iconPictureBox1";
            iconPictureBox1.Size = new Size(25, 26);
            iconPictureBox1.TabIndex = 7;
            iconPictureBox1.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(3, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(132, 73);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(172, 52);
            label10.Name = "label10";
            label10.Size = new Size(238, 17);
            label10.TabIndex = 9;
            label10.Text = "Copyright ISAD_M3_25_Group(Roza)";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Times New Roman", 20F, FontStyle.Regular, GraphicsUnit.Point);
            label11.Location = new Point(186, 3);
            label11.Name = "label11";
            label11.Size = new Size(202, 39);
            label11.TabIndex = 9;
            label11.Text = "Ticket's Form";
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(255, 255, 128);
            panel2.Controls.Add(pictureBox14);
            panel2.Controls.Add(label13);
            panel2.Controls.Add(label12);
            panel2.Controls.Add(iconPictureBox2);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(1424, 76);
            panel2.TabIndex = 7;
            // 
            // pictureBox14
            // 
            pictureBox14.Image = (Image)resources.GetObject("pictureBox14.Image");
            pictureBox14.Location = new Point(0, 0);
            pictureBox14.Name = "pictureBox14";
            pictureBox14.Size = new Size(165, 76);
            pictureBox14.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox14.TabIndex = 27;
            pictureBox14.TabStop = false;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Times New Roman", 20F, FontStyle.Regular, GraphicsUnit.Point);
            label13.Location = new Point(374, 9);
            label13.Name = "label13";
            label13.Size = new Size(722, 39);
            label13.TabIndex = 2;
            label13.Text = "PASSENGER AND GOODS TRANSPORTATION";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(651, 59);
            label12.Name = "label12";
            label12.Size = new Size(221, 17);
            label12.TabIndex = 2;
            label12.Text = "Copyright ISAD_M3_Group5(2024)";
            // 
            // iconPictureBox2
            // 
            iconPictureBox2.BackColor = Color.FromArgb(255, 255, 128);
            iconPictureBox2.ForeColor = SystemColors.ControlText;
            iconPictureBox2.IconChar = FontAwesome.Sharp.IconChar.Copyright;
            iconPictureBox2.IconColor = SystemColors.ControlText;
            iconPictureBox2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox2.IconSize = 23;
            iconPictureBox2.Location = new Point(615, 53);
            iconPictureBox2.Name = "iconPictureBox2";
            iconPictureBox2.Size = new Size(30, 23);
            iconPictureBox2.TabIndex = 1;
            iconPictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(21, 95);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(120, 120);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 25;
            pictureBox3.TabStop = false;
            // 
            // btnCus
            // 
            btnCus.BackColor = SystemColors.Info;
            btnCus.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnCus.Location = new Point(21, 221);
            btnCus.Name = "btnCus";
            btnCus.Size = new Size(120, 40);
            btnCus.TabIndex = 26;
            btnCus.Text = "CUSTOMER";
            btnCus.UseVisualStyleBackColor = false;
            // 
            // btnStaff
            // 
            btnStaff.BackColor = SystemColors.Info;
            btnStaff.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnStaff.Location = new Point(147, 221);
            btnStaff.Name = "btnStaff";
            btnStaff.Size = new Size(120, 40);
            btnStaff.TabIndex = 28;
            btnStaff.Text = "STAFF";
            btnStaff.UseVisualStyleBackColor = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(147, 95);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(120, 120);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 27;
            pictureBox2.TabStop = false;
            // 
            // btnVehicle
            // 
            btnVehicle.BackColor = SystemColors.Info;
            btnVehicle.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnVehicle.Location = new Point(273, 221);
            btnVehicle.Name = "btnVehicle";
            btnVehicle.Size = new Size(120, 40);
            btnVehicle.TabIndex = 30;
            btnVehicle.Text = "VEHICLE";
            btnVehicle.UseVisualStyleBackColor = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(273, 95);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(120, 120);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 29;
            pictureBox4.TabStop = false;
            // 
            // btnRoute
            // 
            btnRoute.BackColor = SystemColors.Info;
            btnRoute.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnRoute.Location = new Point(399, 221);
            btnRoute.Name = "btnRoute";
            btnRoute.Size = new Size(120, 40);
            btnRoute.TabIndex = 32;
            btnRoute.Text = "ROUTE";
            btnRoute.UseVisualStyleBackColor = false;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(399, 95);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(120, 120);
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 31;
            pictureBox5.TabStop = false;
            // 
            // btnBooking
            // 
            btnBooking.BackColor = SystemColors.Info;
            btnBooking.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnBooking.Location = new Point(525, 221);
            btnBooking.Name = "btnBooking";
            btnBooking.Size = new Size(120, 40);
            btnBooking.TabIndex = 34;
            btnBooking.Text = "BOOKING";
            btnBooking.UseVisualStyleBackColor = false;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = (Image)resources.GetObject("pictureBox6.Image");
            pictureBox6.Location = new Point(525, 95);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(120, 120);
            pictureBox6.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox6.TabIndex = 33;
            pictureBox6.TabStop = false;
            // 
            // btnTransport
            // 
            btnTransport.BackColor = SystemColors.Info;
            btnTransport.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnTransport.Location = new Point(651, 221);
            btnTransport.Name = "btnTransport";
            btnTransport.Size = new Size(120, 40);
            btnTransport.TabIndex = 36;
            btnTransport.Text = "TRANSPORT";
            btnTransport.UseVisualStyleBackColor = false;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = (Image)resources.GetObject("pictureBox7.Image");
            pictureBox7.Location = new Point(651, 95);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(120, 120);
            pictureBox7.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox7.TabIndex = 35;
            pictureBox7.TabStop = false;
            // 
            // btnItem
            // 
            btnItem.BackColor = SystemColors.Info;
            btnItem.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnItem.Location = new Point(777, 221);
            btnItem.Name = "btnItem";
            btnItem.Size = new Size(120, 40);
            btnItem.TabIndex = 38;
            btnItem.Text = "ITEMS";
            btnItem.UseVisualStyleBackColor = false;
            // 
            // pictureBox8
            // 
            pictureBox8.Image = (Image)resources.GetObject("pictureBox8.Image");
            pictureBox8.Location = new Point(777, 95);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(120, 120);
            pictureBox8.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox8.TabIndex = 37;
            pictureBox8.TabStop = false;
            // 
            // btnPayment
            // 
            btnPayment.BackColor = SystemColors.Info;
            btnPayment.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnPayment.Location = new Point(903, 221);
            btnPayment.Name = "btnPayment";
            btnPayment.Size = new Size(120, 40);
            btnPayment.TabIndex = 40;
            btnPayment.Text = "PAYMENT";
            btnPayment.UseVisualStyleBackColor = false;
            // 
            // pictureBox9
            // 
            pictureBox9.Image = (Image)resources.GetObject("pictureBox9.Image");
            pictureBox9.Location = new Point(903, 95);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(120, 120);
            pictureBox9.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox9.TabIndex = 39;
            pictureBox9.TabStop = false;
            // 
            // btnInvoice
            // 
            btnInvoice.BackColor = SystemColors.Info;
            btnInvoice.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnInvoice.Location = new Point(1029, 221);
            btnInvoice.Name = "btnInvoice";
            btnInvoice.Size = new Size(120, 40);
            btnInvoice.TabIndex = 42;
            btnInvoice.Text = "INVOICE";
            btnInvoice.UseVisualStyleBackColor = false;
            // 
            // pictureBox10
            // 
            pictureBox10.Image = (Image)resources.GetObject("pictureBox10.Image");
            pictureBox10.Location = new Point(1029, 95);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(120, 120);
            pictureBox10.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox10.TabIndex = 41;
            pictureBox10.TabStop = false;
            // 
            // btnTicket
            // 
            btnTicket.BackColor = SystemColors.Info;
            btnTicket.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnTicket.Location = new Point(1155, 221);
            btnTicket.Name = "btnTicket";
            btnTicket.Size = new Size(120, 40);
            btnTicket.TabIndex = 44;
            btnTicket.Text = "TICKET";
            btnTicket.UseVisualStyleBackColor = false;
            // 
            // btnUser
            // 
            btnUser.BackColor = SystemColors.Info;
            btnUser.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnUser.Location = new Point(1281, 221);
            btnUser.Name = "btnUser";
            btnUser.Size = new Size(120, 40);
            btnUser.TabIndex = 46;
            btnUser.Text = "USER";
            btnUser.UseVisualStyleBackColor = false;
            // 
            // pictureBox12
            // 
            pictureBox12.Image = (Image)resources.GetObject("pictureBox12.Image");
            pictureBox12.Location = new Point(1281, 95);
            pictureBox12.Name = "pictureBox12";
            pictureBox12.Size = new Size(120, 120);
            pictureBox12.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox12.TabIndex = 45;
            pictureBox12.TabStop = false;
            // 
            // pictureBox13
            // 
            pictureBox13.Image = (Image)resources.GetObject("pictureBox13.Image");
            pictureBox13.Location = new Point(1155, 95);
            pictureBox13.Name = "pictureBox13";
            pictureBox13.Size = new Size(120, 120);
            pictureBox13.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox13.TabIndex = 47;
            pictureBox13.TabStop = false;
            // 
            // btnLogOut
            // 
            btnLogOut.BackColor = SystemColors.Info;
            btnLogOut.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnLogOut.Location = new Point(1281, 481);
            btnLogOut.Name = "btnLogOut";
            btnLogOut.Size = new Size(120, 40);
            btnLogOut.TabIndex = 48;
            btnLogOut.Text = "Log Out";
            btnLogOut.UseVisualStyleBackColor = false;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(8F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1424, 563);
            Controls.Add(btnLogOut);
            Controls.Add(pictureBox13);
            Controls.Add(btnUser);
            Controls.Add(pictureBox12);
            Controls.Add(btnTicket);
            Controls.Add(btnInvoice);
            Controls.Add(pictureBox10);
            Controls.Add(btnPayment);
            Controls.Add(pictureBox9);
            Controls.Add(btnItem);
            Controls.Add(pictureBox8);
            Controls.Add(btnTransport);
            Controls.Add(pictureBox7);
            Controls.Add(btnBooking);
            Controls.Add(pictureBox6);
            Controls.Add(btnRoute);
            Controls.Add(pictureBox5);
            Controls.Add(btnVehicle);
            Controls.Add(pictureBox4);
            Controls.Add(btnStaff);
            Controls.Add(pictureBox2);
            Controls.Add(btnCus);
            Controls.Add(panel2);
            Controls.Add(pictureBox3);
            Font = new Font("Times New Roman", 9F, FontStyle.Regular, GraphicsUnit.Point);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "MainForm";
            Text = "Mian Form";
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).EndInit();
            ResumeLayout(false);
        }

        private FontAwesome.Sharp.IconPictureBox iconPictureBox1;
#pragma warning disable CS0169 // The field 'Ticket.panel1' is never used
#pragma warning restore CS0169 // The field 'Ticket.panel1' is never used
        private Label label10;
        private PictureBox pictureBox1;
        private Label label11;
#pragma warning disable CS0649 // Field 'Ticket.panel1_Paint' is never assigned to, and will always have its default value null
        private Panel panel2;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox2;
        private Label label13;
        private Label label12;
        private PictureBox pictureBox3;
        private Button btnCus;
        private Button btnStaff;
        private PictureBox pictureBox2;
        private Button btnVehicle;
        private PictureBox pictureBox4;
        private Button btnRoute;
        private PictureBox pictureBox5;
        private Button btnBooking;
        private PictureBox pictureBox6;
        private Button btnTransport;
        private PictureBox pictureBox7;
        private Button btnItem;
        private PictureBox pictureBox8;
        private Button btnPayment;
        private PictureBox pictureBox9;
        private Button btnInvoice;
        private PictureBox pictureBox10;
        private Button btnTicket;
        private Button btnUser;
        private PictureBox pictureBox12;
        private PictureBox pictureBox14;
        private PictureBox pictureBox13;
        private Button btnLogOut;
    }
}