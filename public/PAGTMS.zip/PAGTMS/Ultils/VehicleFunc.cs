﻿using Microsoft.Data.SqlClient;
using PAGTMS.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAGTMS.Ultils;

public static class VehicleFunc
{
    public static IEnumerable<Vehicle> GetAllVehicle(SqlConnection con)
    {
        SqlCommand cmd = new SqlCommand("spReadAllVehicle", con);
        SqlDataReader? reader = null;
        try
        {
            reader = cmd.ExecuteReader();
        }
        catch (Exception ex)
        {
            throw new Exception($"Error in getting all Vehicle > {ex.Message}");
        }
        finally
        {
            cmd.Dispose();
        }
        if (reader != null && reader.HasRows == true)
        {
            var queryAbles = reader.Cast<IDataRecord>().AsQueryable();
            foreach (var record in queryAbles)
            {
                yield return reader.ToVehicleAllData();
            }
        }
        reader?.Close();
    }
    public static Vehicle GetOneVehicle(SqlConnection con, int id)
    {
        SqlCommand cmd = new SqlCommand("spReadOneVehicle", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@vid", id);
        SqlDataReader? reader = null;
        try
        {
            reader = cmd.ExecuteReader();
        }
        catch (Exception ex)
        {
            throw new Exception($"Error in getting vehicle with id, {id} > {ex.Message}");
        }
        finally
        {
            cmd.Dispose();
        }
        Vehicle? result = null;
        if (reader != null && reader.HasRows == true)
        {
            if (reader.Read() == true)
            {
                result = reader.ToVehicleAllData();
            }
        }
        reader?.Close();
        //Console.WriteLine(result);
        return result;
    }
    public static int AddVehicle(SqlConnection con, Vehicle vehicle)
    {
        SqlCommand cmd = new SqlCommand("spInsertVehicle", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@vid", vehicle.VehicleID);
        cmd.Parameters.AddWithValue("@vt", vehicle.VehicleType);
        cmd.Parameters.AddWithValue("@cp", vehicle.Capacity);
        cmd.Parameters.AddWithValue("@lp", vehicle.LincensePlate);
        cmd.Parameters.AddWithValue("@vs", vehicle.VehicleStatus);
        try
        {
            int effected = cmd.ExecuteNonQuery();
            /*if (effected > 0) Added?.Invoke(null, new EntityEventArgs() { Id = student.Id, Entity = EntityTypes.Students });*/
            return effected > 0 ? vehicle.VehicleID : 0;
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed in adding new vehicle > {ex.Message}");

        }
        finally
        {
            cmd.Dispose();
        }
    }
    public static bool UpdateVehicle(SqlConnection con, Vehicle vehicle)
    {
        SqlCommand cmd = new SqlCommand("spUpdateVehicle", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@vid", vehicle.VehicleID);
        cmd.Parameters.AddWithValue("@vt", vehicle.VehicleType);
        cmd.Parameters.AddWithValue("@cp", vehicle.Capacity);
        cmd.Parameters.AddWithValue("@lp",vehicle.LincensePlate);
        cmd.Parameters.AddWithValue("@vs", vehicle.VehicleStatus);
        try
        {
            int effected = cmd.ExecuteNonQuery();
            //if (effected > 0) Updated?.Invoke(null, new EntityEventArgs() { Id = student.Id, Entity = EntityTypes.Students });
            return (effected > 0);
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed in updating existing vehicle > {ex.Message}");
        }
        finally
        {
            cmd.Dispose();
        }
    }
}
