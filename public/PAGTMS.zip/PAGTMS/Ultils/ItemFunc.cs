﻿using Microsoft.Data.SqlClient;
using PAGTMS.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAGTMS.Ultils;

public static class ItemFunc
{
    public static IEnumerable<Item> GetAllItem(SqlConnection con)
    {

        SqlCommand cmd = new SqlCommand("spReadALLItem", con);
        SqlDataReader? reader = null;
        try
        {
            reader = cmd.ExecuteReader();
        }
        catch (Exception ex)
        {
            throw new Exception($"Error in getting all Item > {ex.Message}");
        }
        finally
        {
            cmd.Dispose();
        }
        if (reader != null && reader.HasRows == true)
        {
            var queryAbles = reader.Cast<IDataRecord>().AsQueryable();
            foreach (var record in queryAbles)
            {
                yield return reader.ToDisplayItem();
            }
        }
        reader?.Close();
    }

    public static Item GetOneItem(SqlConnection con, int id)
    {
        SqlCommand cmd = new SqlCommand("spReadOneItem", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@itid", id);
        SqlDataReader? reader = null;
        try
        {
            reader = cmd.ExecuteReader();
        }
        catch (Exception ex)
        {
            throw new Exception($"Error in getting Item with id, {id} > {ex.Message}");
        }
        finally
        {
            cmd.Dispose();
        }
        Item? result = null;
        if (reader != null && reader.HasRows == true)
        {
            if (reader.Read() == true)
            {
                result = reader.ToDisplayItem();
            }
        }
        reader?.Close();
        return result;
    }
    public static int AddItem(SqlConnection con, Item item)
    {
        SqlCommand cmd = new SqlCommand("spInsertItem", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@itid", item.ItemID);
        cmd.Parameters.AddWithValue("@cate", item.Category);
        cmd.Parameters.AddWithValue("@des", item.Description);
        cmd.Parameters.AddWithValue("@wei", item.Weight);
        cmd.Parameters.AddWithValue("@cusid", item.CustomerID);
        cmd.Parameters.AddWithValue("@cusna", item.CustomerName);
        cmd.Parameters.AddWithValue("@cusco", item.CustomerContact);
        cmd.Parameters.AddWithValue("@tid", item.TransportID);
        cmd.Parameters.AddWithValue("@td", item.TransportDate);
        try
        {
            int effected = cmd.ExecuteNonQuery();
            /*if (effected > 0) Added?.Invoke(null, new EntityEventArgs() { Id = student.Id, Entity = EntityTypes.Students });*/
            return effected > 0 ? item.ItemID : 0;
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed in adding new Item > {ex.Message}");

        }
        finally
        {
            cmd.Dispose();
        }


    }
    public static bool UpdateItem(SqlConnection con, Item item)
    {
        SqlCommand cmd = new SqlCommand("spUpdateItem", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@itid", item.ItemID);
        cmd.Parameters.AddWithValue("@cate", item.Category);
        cmd.Parameters.AddWithValue("@des", item.Description);
        cmd.Parameters.AddWithValue("@wei", item.Weight);
        cmd.Parameters.AddWithValue("@cusid", item.CustomerID);
        cmd.Parameters.AddWithValue("@cusna", item.CustomerName);
        cmd.Parameters.AddWithValue("@cusco", item.CustomerContact);
        cmd.Parameters.AddWithValue("@tid", item.TransportID);
        cmd.Parameters.AddWithValue("@td", item.TransportDate);
        try
        {
            int effected = cmd.ExecuteNonQuery();
            //if (effected > 0) Updated?.Invoke(null, new EntityEventArgs() { Id = student.Id, Entity = EntityTypes.Students });
            return (effected > 0);
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed in updating existing Item > {ex.Message}");
        }
        finally
        {
            cmd.Dispose();
        }
    }
}
