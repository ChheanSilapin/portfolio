﻿using Microsoft.Data.SqlClient;
using PAGTMS.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAGTMS.Ultils;

public static class TransportFunc
{
    public static IEnumerable<Transport> GetAllTransport(SqlConnection con)
    {
        SqlCommand cmd = new SqlCommand("spReadALLTransport", con);
        SqlDataReader? reader = null;
        try
        {
            reader = cmd.ExecuteReader();
        }
        catch (Exception ex)
        {
            throw new Exception($"Error in getting all Payment > {ex.Message}");
        }
        finally
        {
            cmd.Dispose();
        }
        if (reader != null && reader.HasRows == true)
        {
            var queryAbles = reader.Cast<IDataRecord>().AsQueryable();
            foreach (var record in queryAbles)
            {
                yield return reader.ToTransportAllData();
            }
        }
        reader?.Close();
    }

    public static Transport GetOneTransport(SqlConnection con, int id)
    {
        SqlCommand cmd = new SqlCommand("spReadOneTransport", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@tranid", id);
        SqlDataReader? reader = null;
        try
        {
            reader = cmd.ExecuteReader();
        }
        catch (Exception ex)
        {
            throw new Exception($"Error in getting user with id, {id} > {ex.Message}");
        }
        finally
        {
            cmd.Dispose();
        }
        Transport? result = null;
        if (reader != null && reader.HasRows == true)
        {
            if (reader.Read() == true)
            {
                result = reader.ToTransportAllData();
            }
        }
        reader?.Close();
        return result;
    }
    public static int AddTransport(SqlConnection con, Transport transport)
    {
        SqlCommand cmd = new SqlCommand("spInsertTransport", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@tranid", transport.TransportID);
        cmd.Parameters.AddWithValue("@trandate", transport.TransportDate);
        cmd.Parameters.AddWithValue("@transtatus", transport.TransportStatus);
        cmd.Parameters.AddWithValue("@cusid", transport.CustomerID);
        cmd.Parameters.AddWithValue("@cusinfo", transport.CustomerContactInfo);
        cmd.Parameters.AddWithValue("@routeid", transport.RouteID);
        cmd.Parameters.AddWithValue("@rdes", transport.Destination);
        cmd.Parameters.AddWithValue("@stid", transport.StaffID);
        cmd.Parameters.AddWithValue("@stpos", transport.StaffPosition);
        try
        {
            int effected = cmd.ExecuteNonQuery();
            /*if (effected > 0) Added?.Invoke(null, new EntityEventArgs() { Id = student.Id, Entity = EntityTypes.Students });*/
            return effected > 0 ? transport.TransportID : 0;
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed in adding new transport > {ex.Message}");

        }
        finally
        {
            cmd.Dispose();
        }

    }
    public static bool UpdateTransport(SqlConnection con, Transport transport)
    {
        SqlCommand cmd = new SqlCommand("spUpdateTransport", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@tranid", transport.TransportID);
        cmd.Parameters.AddWithValue("@trandate", transport.TransportDate);
        cmd.Parameters.AddWithValue("@transtatus", transport.TransportStatus);
        cmd.Parameters.AddWithValue("@cusid", transport.CustomerID);
        cmd.Parameters.AddWithValue("@cusinfo", transport.CustomerContactInfo);
        cmd.Parameters.AddWithValue("@routeid", transport.RouteID);
        cmd.Parameters.AddWithValue("@rdes", transport.Destination);
        cmd.Parameters.AddWithValue("@stid", transport.StaffID);
        cmd.Parameters.AddWithValue("@stpos", transport.StaffPosition);
        try
        {
            int effected = cmd.ExecuteNonQuery();
            //if (effected > 0) Updated?.Invoke(null, new EntityEventArgs() { Id = student.Id, Entity = EntityTypes.Students });
            return (effected > 0);
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed in updating existing transport > {ex.Message}");
        }
        finally
        {
            cmd.Dispose();
        }
    }
}
