﻿using Microsoft.Data.SqlClient;
using PAGTMS.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAGTMS.Ultils;

public static class CustomerFunc
{
    public static IEnumerable<Customer> GetAllCustomer(SqlConnection con)
    {
        SqlCommand cmd = new SqlCommand("spReadAllCustomer", con);
        SqlDataReader? reader = null;
        try
        {
            reader = cmd.ExecuteReader();
        }
        catch (Exception ex)
        {
            throw new Exception($"Error in getting all Customer > {ex.Message}");
        }
        finally
        {
            cmd.Dispose();
        }
        if (reader != null && reader.HasRows == true)
        {
            var queryAbles = reader.Cast<IDataRecord>().AsQueryable();
            foreach (var record in queryAbles)
            {
                yield return reader.ToCustomer();
            }
        }
        reader?.Close();
    }
    public static Customer GetOneCustomer(SqlConnection con ,int id)
    {
        SqlCommand cmd = new SqlCommand("spReadOneCustomer", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@cid", id);
        SqlDataReader? reader = null;
        try
        {
            reader = cmd.ExecuteReader();
        }
        catch (Exception ex)
        {
            throw new Exception($"Error in getting customer with id, {id} > {ex.Message}");
        }
        finally
        {
            cmd.Dispose();
        }
        Customer? result = null;
        if (reader != null && reader.HasRows == true)
        {
            if (reader.Read() == true)
            {
                result = reader.ToCustomerAllData();
            }
        }
        reader?.Close();
        return result;
    }
    public static int AddCustomer(SqlConnection con, Customer customer)
    {
        SqlCommand cmd = new SqlCommand("spInsertCustomer", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@cid", customer.CustomerID);
        cmd.Parameters.AddWithValue("@cn", customer.CustomerName);
        cmd.Parameters.AddWithValue("@cg", customer.Gender);
        cmd.Parameters.AddWithValue("@ca", customer.CusAge);
        cmd.Parameters.AddWithValue("@cci", customer.CustomerContactInfo);
        try
        {
            int effected = cmd.ExecuteNonQuery();
            /*if (effected > 0) Added?.Invoke(null, new EntityEventArgs() { Id = student.Id, Entity = EntityTypes.Students });*/
            return effected > 0 ? customer.CustomerID : 0;
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed in adding new Customer > {ex.Message}");

        }
        finally
        {
            cmd.Dispose();
        }
    }
    public static bool UpdateCustomer(SqlConnection con,Customer customer)
    {
        SqlCommand cmd = new SqlCommand("spUpdateCustomer", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@cid", customer.CustomerID);
        cmd.Parameters.AddWithValue("@cn", customer.CustomerName);
        cmd.Parameters.AddWithValue("@cg", customer.Gender);
        cmd.Parameters.AddWithValue("@ca", customer.CusAge);
        cmd.Parameters.AddWithValue("@cci", customer.CustomerContactInfo);
        try
        {
            int effected = cmd.ExecuteNonQuery();
            
            return (effected > 0);
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed in updating existing customer > {ex.Message}");
        }
        finally
        {
            cmd.Dispose();
        }
    }
}
