﻿using Microsoft.Data.SqlClient;
using PAGTMS.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAGTMS.Ultils;

public static class RouteFunc
{
    public static IEnumerable<Route> GetAllRoute(SqlConnection con)
    {
        SqlCommand cmd = new SqlCommand("spReadAllRoute", con);
        SqlDataReader? reader = null;
        try
        {
            reader = cmd.ExecuteReader();
        }
        catch (Exception ex)
        {
            throw new Exception($"Error in getting all Route > {ex.Message}");
        }
        finally
        {
            cmd.Dispose();
        }
        if (reader != null && reader.HasRows == true)
        {
            var queryAbles = reader.Cast<IDataRecord>().AsQueryable();
            foreach (var record in queryAbles)
            {
                yield return reader.ToRouteAllData();
            }
        }
        reader?.Close();
    }
    public static Route GetOneRoute(SqlConnection con, int id)
    {
        SqlCommand cmd = new SqlCommand("spReadOneRoute", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@rid", id);
        SqlDataReader? reader = null;
        try
        {
            reader = cmd.ExecuteReader();
        }
        catch (Exception ex)
        {
            throw new Exception($"Error in getting Route with id, {id} > {ex.Message}");
        }
        finally
        {
            cmd.Dispose();
        }
        Route? result = null;
        if (reader != null && reader.HasRows == true)
        {
            if (reader.Read() == true)
            {
                result = reader.ToRouteAllData();
            }
        }
        reader?.Close();
        return result;
    }
    public static int AddRoute(SqlConnection con, Route route)
    {
        SqlCommand cmd = new SqlCommand("spInsertRoute", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@rid", route.RouteID);
        cmd.Parameters.AddWithValue("@ori", route.Origin);
        cmd.Parameters.AddWithValue("@des", route.Destination);
        cmd.Parameters.AddWithValue("@dis", route.Distance);
        
        try
        {
            int effected = cmd.ExecuteNonQuery();
            /*if (effected > 0) Added?.Invoke(null, new EntityEventArgs() { Id = student.Id, Entity = EntityTypes.Students });*/
            return effected > 0 ? route.RouteID : 0;
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed in adding new vehicle > {ex.Message}");

        }
        finally
        {
            cmd.Dispose();
        }
    }
    public static bool UpdateRoute(SqlConnection con, Route route)
    {
        SqlCommand cmd = new SqlCommand("spUpdateRoute", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@rid", route.RouteID);
        cmd.Parameters.AddWithValue("@ori", route.Origin);
        cmd.Parameters.AddWithValue("@des", route.Destination);
        cmd.Parameters.AddWithValue("@dis", route.Distance);
        
        try
        {
            int effected = cmd.ExecuteNonQuery();
            //if (effected > 0) Updated?.Invoke(null, new EntityEventArgs() { Id = student.Id, Entity = EntityTypes.Students });
            return (effected > 0);
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed in updating existing vehicle > {ex.Message}");
        }
        finally
        {
            cmd.Dispose();
        }
    }
}
