﻿using Microsoft.Data.SqlClient;
using PAGTMS.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAGTMS.Ultils
{
    public static class TicketFunc
    {
        public static IEnumerable<Ticket> GetAllTicket(SqlConnection con)
        {
            SqlCommand cmd = new SqlCommand("spReadALLTicket", con);
            SqlDataReader? reader = null;
            try
            {
                reader = cmd.ExecuteReader();
            }
            catch (Exception ex)
            {
                throw new Exception($"Error in getting all ticket > {ex.Message}");
            }
            finally
            {
                cmd.Dispose();
            }
            if (reader != null && reader.HasRows == true)
            {
                var queryAbles = reader.Cast<IDataRecord>().AsQueryable();
                foreach (var record in queryAbles)
                {
                    yield return reader.ToTicketAllData();
                }
            }
            reader?.Close();
        }

        public static Ticket GetOneTicket(SqlConnection con, int id)
        {
            SqlCommand cmd = new SqlCommand("spReadOneTicket", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@ticketid", id);
            SqlDataReader? reader = null;
            try
            {
                reader = cmd.ExecuteReader();
            }
            catch (Exception ex)
            {
                throw new Exception($"Error in getting ticket with id, {id} > {ex.Message}");
            }
            finally
            {
                cmd.Dispose();
            }
            Ticket? result = null;
            if (reader != null && reader.HasRows == true)
            {
                if (reader.Read() == true)
                {
                    result = reader.ToTicketAllData();
                }
            }
            reader?.Close();
            return result;
        }
        public static int AddTicket(SqlConnection con, Ticket ticket)
        {
            SqlCommand cmd = new SqlCommand("spInsertTicket", con); 
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@ticketid", ticket.TicketID);
            cmd.Parameters.AddWithValue("@price", ticket.Price);
            cmd.Parameters.AddWithValue("@seatnum", ticket.SeatNum);
            cmd.Parameters.AddWithValue("@ticketdate", ticket.TicketDate);
            cmd.Parameters.AddWithValue("@cusid", ticket.CustomerID);
            cmd.Parameters.AddWithValue("@cusinfo", ticket.CusContactInfo);
            cmd.Parameters.AddWithValue("@stid", ticket.StaffID);
            cmd.Parameters.AddWithValue("@stpos", ticket.StaffPosition);
            //cmd.Parameters.AddWithValue("@bookingid", ticket.BookingID);
            try
            {
                int effected = cmd.ExecuteNonQuery();
                /*if (effected > 0) Added?.Invoke(null, new EntityEventArgs() { Id = student.Id, Entity = EntityTypes.Students });*/
                return effected > 0 ? ticket.TicketID : 0;
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed in adding new ticket > {ex.Message}");

            }
            finally
            {
                cmd.Dispose();
            }

        }
        public static bool UpdateTicket(SqlConnection con, Ticket ticket)
        {
            SqlCommand cmd = new SqlCommand("spUpdateTicket", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@ticketid", ticket.TicketID);
            cmd.Parameters.AddWithValue("@seatnum", ticket.SeatNum);
            cmd.Parameters.AddWithValue("@price", ticket.Price);
            cmd.Parameters.AddWithValue("@ticketdate", ticket.TicketDate);
            cmd.Parameters.AddWithValue("@cusid", ticket.CustomerID);
            cmd.Parameters.AddWithValue("@cusinfo", ticket.CusContactInfo);
            cmd.Parameters.AddWithValue("@stid", ticket.StaffID);
            cmd.Parameters.AddWithValue("@stpos", ticket.StaffPosition);
            try
            {
                int effected = cmd.ExecuteNonQuery();
                //if (effected > 0) Updated?.Invoke(null, new EntityEventArgs() { Id = student.Id, Entity = EntityTypes.Students });
                return (effected > 0);
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed in updating existing tikcket > {ex.Message}");
            }
            finally
            {
                cmd.Dispose();
            }
        }
    }
}
