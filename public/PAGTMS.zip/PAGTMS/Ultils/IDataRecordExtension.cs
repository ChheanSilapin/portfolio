﻿using System.Data;
using PAGTMS.Models;
namespace PAGTMS.Ultils;

public static class IDataRecordExtension

{
    public static Staff ToStaff(this IDataReader record)
    {
        int index = record.GetOrdinal("StaffID");
        int id = record.GetInt32(index);

        index = record.GetOrdinal("StaffNameKH");
        string? staffnameKH = record.GetString(index);
        return new Staff()
        {
            StaffID =  id,
            StaffNameKH = staffnameKH,
        };
    }
    public static Staff ToStaffAllData(this IDataReader record)
    {
        int index = record.GetOrdinal("StaffID");
        int id = record.GetInt32(index);

        index = record.GetOrdinal("StaffNameKH");
        string? staffnameKH = record.GetString(index);

        index = record.GetOrdinal("StaffNameEN");
        string? staffnameEN = record.GetString(index);

        index = record.GetOrdinal("Gender");
        string? gender = record.GetString(index);

        index = record.GetOrdinal("BirthDate");
        DateTime birthdate = record.GetDateTime(index);

        index = record.GetOrdinal("StaffPosition");
        string? staffposition = record.GetString(index);

        index = record.GetOrdinal("HouseNo");
        string? houseno = record.GetString(index);
        
        index = record.GetOrdinal("StreetNo");
        string? streetno = record.GetString(index);

        index = record.GetOrdinal("Khann");
        string? Khann = record.GetString(index);

        index = record.GetOrdinal("Sangkat");
        string? sangkat = record.GetString(index);

        index = record.GetOrdinal("Province");
        string? province = record.GetString(index);

        index = record.GetOrdinal("ContactNumber");
        string? contactnumber = record.GetString(index);

        index = record.GetOrdinal("PersonalNumber");
        string? personalnumber = record.GetString(index);
        if (!record.IsDBNull(index)) personalnumber = record.GetString(index);

        index = record.GetOrdinal("Salary");
        decimal? salary = record.GetDecimal(index);

        index = record.GetOrdinal("HiredDate");
        DateTime hireddate = record.GetDateTime(index);

        index = record.GetOrdinal("Photo");
        byte[]? photo = null;
        if (!record.IsDBNull(index)) photo = (byte[])record[index];
        index = record.GetOrdinal("StopWork");
        bool stopwork = record.GetBoolean(index);
        
        
        return new Staff()
        {
            StaffID = id,
            StaffNameKH = staffnameKH,
            StaffNameEN = staffnameEN,
            Gender = gender,
            BirthDate = birthdate,
            StaffPosition = staffposition,
            HouseNo = houseno,
            StreetNo = streetno,
            Sangkat = sangkat,
            Khann = Khann,
            Province = province,
            ContactNumber = contactnumber,
            PersonalNumber = personalnumber,
            Salary = salary,
            HiredDate = hireddate,
            Photo = photo,
            StopWork = stopwork,
        };
    }
    public static Customer ToCustomer(this IDataReader record)
    {
        int index = record.GetOrdinal("CusID");
        int id = record.GetInt32(index);

        index = record.GetOrdinal("CusName");
        string? customerName = record.GetString(index);
        return new Customer()
        {
            CustomerID = id,
            CustomerName = customerName,
        };
    }
    public static Customer ToCustomerAllData(this IDataReader record)
    {
        int index = record.GetOrdinal("CusID");
        int id = record.GetInt32(index);

        index = record.GetOrdinal("CusName");
        string? customerName = record.GetString(index);

        index = record.GetOrdinal("CusAge");
        Int16 cusAge = record.GetInt16(index);
        index = record.GetOrdinal("CusGender");
        string? cusGender = record.GetString(index);
        index = record.GetOrdinal("CusContactInfo");
        string cusContact  = record.GetString(index);
        return new Customer()
        {
            CustomerID = id,
            CustomerName = customerName,
            Gender = cusGender,
            CusAge = cusAge,
            CustomerContactInfo = cusContact,

        };
    }
    public static Vehicle ToVehicleAllData(this IDataReader record)
    {
        int index = record.GetOrdinal("VehicleID");
        int id = record.GetInt32(index);

        index = record.GetOrdinal("VType");
        string? vehicleType = record.GetString(index);

        index = record.GetOrdinal("Capacity");
        string? capacity= record.GetString(index);

        index = record.GetOrdinal("Lincense_Plate");
        string? lincensPlaste = record.GetString(index);

        index = record.GetOrdinal("VStatus");
        string? vehicleStatus = record.GetString(index);
        return new Vehicle()
        {
            VehicleID = id,
            VehicleType = vehicleType,
            Capacity = capacity,
            LincensePlate = lincensPlaste,
            VehicleStatus = vehicleStatus,
        };
    }
    public static Route ToRouteAllData(this IDataReader record)
    {
        int index = record.GetOrdinal("RouteID");
        int id = record.GetInt32(index);

        index = record.GetOrdinal("Origin");
        string? origin = record.GetString(index);

        index = record.GetOrdinal("Destination");
        string? destination = record.GetString(index);

        index = record.GetOrdinal("Distance");
        string? distance = record.GetString(index);
        return new Route()
        {
            RouteID = id,
            Origin = origin,
            Destination = destination,
            Distance = distance,
        };
    } 
    public static Booking ToBookingAllData(this IDataReader record)
    {
        int index = record.GetOrdinal("BookingID");
        int id = record.GetInt32(index);

        index = record.GetOrdinal("BookingDate");
        DateTime bookingdate = record.GetDateTime(index);

        index = record.GetOrdinal("TotalPaid");
        decimal? totalpaid = record.GetDecimal(index);

        index = record.GetOrdinal("CusID");
        int cusid = record.GetInt32(index);

        index = record.GetOrdinal("CusName");
        string? cusname = record.GetString(index);

        index = record.GetOrdinal("CusContactInfo");
        string? cusinfo = record.GetString(index);

        index = record.GetOrdinal("RouteID");
        int routeid = record.GetInt32(index);
        index = record.GetOrdinal("Destination");
        string? destination = record.GetString(index);

        index = record.GetOrdinal("VehicleID");
        int vehicleid = record.GetInt32(index);

        index = record.GetOrdinal("VType");
        string? vehicleType = record.GetString(index);
        index = record.GetOrdinal("VStatus");
        string? vehicleStatus = record.GetString(index);

        index = record.GetOrdinal("StaffID");
        int staffID = record.GetInt32(index);

        index = record.GetOrdinal("StaffNameKh");
        string? staffnameKH = record.GetString(index);

        index = record.GetOrdinal("StaffPosition");
        string? staffposition = record.GetString(index);
        return new Booking()
        {
            BookingID = id,
            BookingDate = bookingdate,
            TotalPaid = totalpaid,
            CustomerID = cusid,
            CustomerName = cusname,
            CustomerContactInfo = cusinfo,
            RouteID = routeid,     
            Destination = destination,
            VehicleID = vehicleid,
            VehicleType = vehicleType,
            VehicleStatus = vehicleStatus,
            StaffID = staffID,
            StaffNameKh = staffnameKH,
            StaffPosition = staffposition,
        };
    }   
    public static Transport ToTransportAllData(this IDataReader record)
    {
        int index = record.GetOrdinal("TransportID");
        int id = record.GetInt32(index);

        index = record.GetOrdinal("TransportDate");
        DateTime transportdate = record.GetDateTime(index);

        index = record.GetOrdinal("TStatus");
        string? transportstatus = record.GetString(index);

        index = record.GetOrdinal("CusID");
        int cusid = record.GetInt32(index);

        index = record.GetOrdinal("CusContactInfo");
        string? cusinfo = record.GetString(index);

        index = record.GetOrdinal("RouteID");
        int routeid = record.GetInt32(index);
        index = record.GetOrdinal("Destination");
        string? destination = record.GetString(index);

        index = record.GetOrdinal("StaffID");
        int staffID = record.GetInt32(index);

        index = record.GetOrdinal("StaffPosition");
        string? staffposition = record.GetString(index);

        return new Transport()
        {
            TransportID = id,
            TransportDate = transportdate,
            TransportStatus = transportstatus,
            CustomerID = cusid,
            CustomerContactInfo = cusinfo,
            RouteID = routeid,
            Destination = destination,
            StaffID = staffID,
            StaffPosition = staffposition,
        };
    }
    public static Item ToDisplayItem(this IDataReader record)
    {
        int index = record.GetOrdinal("ItemID");
        int itemid = record.GetInt32(index);

        index = record.GetOrdinal("Category");
        string? category = record.GetString(index);
        index = record.GetOrdinal("IDescription");
        string? description = record.GetString(index);
        index = record.GetOrdinal("IWeight");
        string? weight = record.GetString(index);

        index = record.GetOrdinal("CusID");
        int customerid = record.GetInt32(index);

        index = record.GetOrdinal("CusName");
        string? customername = record.GetString(index);

        index = record.GetOrdinal("CusContactInfo");
        string? cuscontactinfo = record.GetString(index);

        index = record.GetOrdinal("TransportID");
        int transportid = record.GetInt32(index);

        index = record.GetOrdinal("TransportDate");
        DateTime transportdate = record.GetDateTime(index);

        return new Item()
        {
            ItemID = itemid,
            Category = category,
            Description = description,
            Weight = weight,
            CustomerID = customerid,
            CustomerName = customername,
            CustomerContact =cuscontactinfo,
            TransportID = transportid,
            TransportDate = transportdate,

        };

    }
    public static Payment ToPayment(this IDataReader record)
    {
        int index = record.GetOrdinal("PaymentID");
        int id = record.GetInt32(index);

        index = record.GetOrdinal("Cusname");
        string? cusname = record.GetString(index);
        return new Payment()
        {
            PaymentID = id,
            CustomerName = cusname,
        };
    }
    public static Payment ToPaymentAllData(this IDataReader record)
    {
        int index = record.GetOrdinal("PaymentID");
        int id = record.GetInt32(index);
        index = record.GetOrdinal("PayDate");
        DateTime paydate = record.GetDateTime(index);
        index = record.GetOrdinal("PaidAmount");
        decimal? paidamout = record.GetDecimal(index);

        index = record.GetOrdinal("CusID");
        int cusid = record.GetInt32(index);

        index = record.GetOrdinal("CusName");
        string? cusname = record.GetString(index);

        index = record.GetOrdinal("CusContactInfo");
        string? cusinfo = record.GetString(index);

        index = record.GetOrdinal("StaffID");
        int staffID = record.GetInt32(index);

        index = record.GetOrdinal("StaffNameKh");
        string? staffnameKH = record.GetString(index);

        index = record.GetOrdinal("StaffPosition");
        string? staffposition = record.GetString(index);

        return new Payment()
        {
            PaymentID = id,
            PayDate= paydate,
            PaidAmount = paidamout,
            CustomerID = cusid,
            CustomerName = cusname,
            CustomerContactInfo = cusinfo,
            StaffID = staffID,
            StaffNameKh = staffnameKH,
            StaffPosition = staffposition,
        };
    }
    public static Invoice ToInvoice(this IDataReader record)
    {
        int index = record.GetOrdinal("InvoiceID");
        int id = record.GetInt32(index);

        index = record.GetOrdinal("Cusname");
        string? cusname = record.GetString(index);
        return new Invoice()
        {
            InvoiceID = id,
            CustomerName = cusname,
        };
    }
    public static Invoice ToInvoiceAllData(this IDataReader record)
    {
        int index = record.GetOrdinal("InvoiceID");
        int id = record.GetInt32(index);

        index = record.GetOrdinal("InvoiceDate");
        DateTime invoicedate = record.GetDateTime(index);

        index = record.GetOrdinal("TotalAmount");
        decimal? totalamount = record.GetDecimal(index);

        index = record.GetOrdinal("PaidAmount");
        decimal? paidamout = record.GetDecimal(index);

        index = record.GetOrdinal("CusID");
        int cusid = record.GetInt32(index);

        index = record.GetOrdinal("CusName");
        string? cusname = record.GetString(index);

        index = record.GetOrdinal("CusContactInfo");
        string? cusinfo = record.GetString(index);

        index = record.GetOrdinal("StaffID");
        int staffID = record.GetInt32(index);

        index = record.GetOrdinal("StaffNameKh");
        string? staffnameKH = record.GetString(index);

        index = record.GetOrdinal("StaffPosition");
        string? staffposition = record.GetString(index);

        return new Invoice()
        {
            InvoiceID = id,
            InvoiceDate = invoicedate,
            TotalAmount = totalamount,
            PaidAmount = paidamout,
            CustomerID = cusid,
            CustomerName = cusname,
            CustomerContactInfo = cusinfo,
            StaffID = staffID,
            StaffNameKh = staffnameKH,
            StaffPosition = staffposition,
        };
    }  
    public static Ticket ToTicketAllData(this IDataReader record)
    {
        int index = record.GetOrdinal("TicketID");
        int id = record.GetInt32(index);
        index = record.GetOrdinal("Price");
        decimal? price = record.GetDecimal(index);
        index = record.GetOrdinal("SeatNumber");
        string? seatnum = record.GetString(index);
        index = record.GetOrdinal("TDate");
        DateTime ticketdate = record.GetDateTime(index);
        

        index = record.GetOrdinal("CusID");
        int cusid = record.GetInt32(index);

        index = record.GetOrdinal("CusContactInfo");
        string? cusinfo = record.GetString(index);

        index = record.GetOrdinal("StaffID");
        int staffID = record.GetInt32(index);

        index = record.GetOrdinal("StaffPosition");
        string? staffnameKH = record.GetString(index);

        //index = record.GetOrdinal("BookingID");
        //int bookingid = record.GetInt32(index);
        return new Ticket()
        {
            TicketID = id,
            Price = price,
            SeatNum = seatnum,
            TicketDate = ticketdate,
            CustomerID = cusid,
            CusContactInfo =cusinfo,
            StaffID = staffID,
            StaffPosition = staffnameKH,
            //BookingID = bookingid,
        };
    }
    public static User ToUser(this IDataReader record)
    {
        int index = record.GetOrdinal("UserID");
        int id = record.GetInt32(index);

        index = record.GetOrdinal("Username");
        string? username = record.GetString(index);
        return new User()
        {
            UserID = id,
            Username = username,
        };
    }
    public static User ToUserAllData(this IDataReader record)
    {
        int index = record.GetOrdinal("UserID");
        int id = record.GetInt32(index);

        index = record.GetOrdinal("Username");
        string? username = record.GetString(index);

        index = record.GetOrdinal("UserPassword");
        string? password = record.GetString(index);

        index = record.GetOrdinal("StaffID");
        int staffID = record.GetInt32(index);

        index = record.GetOrdinal("StaffNameKh");
        string? staffnameKH = record.GetString(index);

        index = record.GetOrdinal("StaffPosition");
        string? staffposition = record.GetString(index);

        return new User()
        {
            UserID = id,
            Username = username,
            UserPassword = password,
            StaffID = staffID,
            StaffNameKh = staffnameKH,
            StaffPosition = staffposition,
        };
    }
}
