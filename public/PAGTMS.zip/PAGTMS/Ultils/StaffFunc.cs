﻿using Microsoft.Data.SqlClient;
using System.Data;
using PAGTMS.Models;
namespace PAGTMS.Ultils;

public static class StaffFunc
{
    public static IEnumerable<Staff> GetAllStaff(SqlConnection con)
    {
        SqlCommand cmd = new SqlCommand("spReadALLStaff", con);
        SqlDataReader? reader = null;
        try
        {
            reader = cmd.ExecuteReader();
        }
        catch (Exception ex)
        {
            throw new Exception($"Error in getting all Staff > {ex.Message}");
        }
        finally
        {
            cmd.Dispose();
        }
        if (reader != null && reader.HasRows == true)
        {
            var queryAbles = reader.Cast<IDataRecord>().AsQueryable();
            foreach (var record in queryAbles)
            {
                yield return reader.ToStaff();
            }
        }
        reader?.Close();
    }

    public static Staff GetOneStaff(SqlConnection con, int id)

    {
        SqlCommand cmd = new SqlCommand("spReadOneStaff", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@sid", id);
        SqlDataReader? reader = null;
        try
        {
            reader = cmd.ExecuteReader();
        }
        catch (Exception ex)
        {
            throw new Exception($"Error in getting staff with id, {id} > {ex.Message}");
        }
        finally
        {
            cmd.Dispose();
        }
        Staff? result = null;
        if (reader != null && reader.HasRows == true)
        {
            if (reader.Read() == true)
            {
                result = reader.ToStaffAllData();
            }
        }
        reader?.Close();
        return result;
    }
    public static bool AddStaff(SqlConnection con, Staff staff)
    {
        SqlCommand cmd = new SqlCommand("spInsertStaff", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@sid", staff.StaffID);
        cmd.Parameters.AddWithValue("@snKH", staff.StaffNameKH);
        cmd.Parameters.AddWithValue("@snEN", staff.StaffNameEN);
        cmd.Parameters.AddWithValue("@gen", staff.Gender);
        cmd.Parameters.AddWithValue("@bd", staff.BirthDate);
        cmd.Parameters.AddWithValue("@pos", staff.StaffPosition);
        cmd.Parameters.AddWithValue("@sn", staff.StreetNo);
        cmd.Parameters.AddWithValue("@hn", staff.HouseNo);
        cmd.Parameters.AddWithValue("@khn", staff.Khann);
        cmd.Parameters.AddWithValue("@sk", staff.Sangkat);
        cmd.Parameters.AddWithValue("@pro", staff.Province);
        cmd.Parameters.AddWithValue("@cn", staff.ContactNumber);
        cmd.Parameters.AddWithValue("@pn", staff.PersonalNumber);
        cmd.Parameters.AddWithValue("@sa", staff.Salary);
        cmd.Parameters.AddWithValue("@hd", staff.HiredDate);
        cmd.Parameters.AddWithValue("@ph", staff.Photo);
        cmd.Parameters.AddWithValue("@spw", staff.StopWork);
        try
        {
            int effected = cmd.ExecuteNonQuery();
            /*if (effected > 0) Added?.Invoke(null, new EntityEventArgs() { Id = student.Id, Entity = EntityTypes.Students });*/
            return effected > 0;
            //return effected > 0 ? staff.StaffID : 0;
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed in adding new staff > {ex.Message}");

        }
        finally
        {
            cmd.Dispose();
        }
    }
    public static bool UpdateStaff(SqlConnection con, Staff staff)
    {
        SqlCommand cmd = new SqlCommand("spUpdateStaff", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@sid", staff.StaffID);
        cmd.Parameters.AddWithValue("@snKH", staff.StaffNameKH);
        cmd.Parameters.AddWithValue("@snEN", staff.StaffNameEN);
        cmd.Parameters.AddWithValue("@gen", staff.Gender);
        cmd.Parameters.AddWithValue("@bd", staff.BirthDate);
        cmd.Parameters.AddWithValue("@pos", staff.StaffPosition);
        cmd.Parameters.AddWithValue("@hn", staff.HouseNo);
        cmd.Parameters.AddWithValue("@sn", staff.StreetNo);
        cmd.Parameters.AddWithValue("@sk", staff.Sangkat);
        cmd.Parameters.AddWithValue("@khn", staff.Khann);
        cmd.Parameters.AddWithValue("@pro", staff.Province);
        cmd.Parameters.AddWithValue("@cn", staff.ContactNumber);
        cmd.Parameters.AddWithValue("@pn", staff.PersonalNumber);
        cmd.Parameters.AddWithValue("@sa", staff.Salary);
        cmd.Parameters.AddWithValue("@hd", staff.HiredDate);
        cmd.Parameters.AddWithValue("@ph", staff.Photo);
        cmd.Parameters.AddWithValue("@spw", staff.StopWork);
        try
        {
            int effected = cmd.ExecuteNonQuery();
            //if (effected > 0) Updated?.Invoke(null, new EntityEventArgs() { Id = student.Id, Entity = EntityTypes.Students });
            return (effected > 0);
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed in updating existing staff > {ex.Message}");
        }
        finally
        {
            cmd.Dispose();
        }
    }
}


