﻿using Microsoft.Data.SqlClient;
using PAGTMS.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAGTMS.Ultils;

public static class UserFunc
{
    public static IEnumerable<User> GetAllUser(SqlConnection con)
    {
        SqlCommand cmd = new SqlCommand("spReadALLUser", con);
        SqlDataReader? reader = null;
        try
        {
            reader = cmd.ExecuteReader();
        }
        catch (Exception ex)
        {
            throw new Exception($"Error in getting all User > {ex.Message}");
        }
        finally
        {
            cmd.Dispose();
        }
        if (reader != null && reader.HasRows == true)
        {
            var queryAbles = reader.Cast<IDataRecord>().AsQueryable();
            foreach (var record in queryAbles)
            {
                yield return reader.ToUser();
            }
        }
        reader?.Close();
    }

    public static User GetOneUser(SqlConnection con, int id)
    {
        SqlCommand cmd = new SqlCommand("spReadOneUser", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@uid", id);
        SqlDataReader? reader = null;
        try
        {
            reader = cmd.ExecuteReader();
        }
        catch (Exception ex)
        {
            throw new Exception($"Error in getting user with id, {id} > {ex.Message}");
        }
        finally
        {
            cmd.Dispose();
        }
        User? result = null;
        if (reader != null && reader.HasRows == true)
        {
            if (reader.Read() == true)
            {
                result = reader.ToUserAllData();
            }
        }
        reader?.Close();
        return result;
    }

    public static int AddUser(SqlConnection con, User user)
    {
        SqlCommand cmd = new SqlCommand("spInsertUser", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@uid", user.UserID);
        cmd.Parameters.AddWithValue("@uname", user.Username);
        cmd.Parameters.AddWithValue("@upass", user.UserPassword);
        cmd.Parameters.AddWithValue("@stid", user.StaffID);
        cmd.Parameters.AddWithValue("@stkh", user.StaffNameKh);
        cmd.Parameters.AddWithValue("@stpos", user.StaffPosition);
        try
        {
            int effected = cmd.ExecuteNonQuery();
            /*if (effected > 0) Added?.Invoke(null, new EntityEventArgs() { Id = student.Id, Entity = EntityTypes.Students });*/
            return effected > 0 ? user.UserID : 0;
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed in adding new staff > {ex.Message}");

        }
        finally
        {
            cmd.Dispose();
        }

    }

    public static bool UpdateUser(SqlConnection con, User user)
    {
        SqlCommand cmd = new SqlCommand("spUpdateUser", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@uid", user.UserID);
        cmd.Parameters.AddWithValue("@uname", user.Username);
        cmd.Parameters.AddWithValue("@upass", user.UserPassword);
        cmd.Parameters.AddWithValue("@stid", user.StaffID);
        cmd.Parameters.AddWithValue("@stkh", user.StaffNameKh);
        cmd.Parameters.AddWithValue("@stpos", user.StaffPosition);
        try
        {
            int effected = cmd.ExecuteNonQuery();
            //if (effected > 0) Updated?.Invoke(null, new EntityEventArgs() { Id = student.Id, Entity = EntityTypes.Students });
            return (effected > 0);
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed in updating existing user > {ex.Message}");
        }
        finally
        {
            cmd.Dispose();
        }
    }
}
