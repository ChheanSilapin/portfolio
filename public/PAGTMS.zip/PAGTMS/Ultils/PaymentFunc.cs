﻿using Microsoft.Data.SqlClient;
using PAGTMS.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAGTMS.Ultils;

public static class PaymentFunc
{
    public static IEnumerable<Payment> GetAllPayment(SqlConnection con)
    {
        SqlCommand cmd = new SqlCommand("spReadALLPayment", con);
        SqlDataReader? reader = null;
        try
        {
            reader = cmd.ExecuteReader();
        }
        catch (Exception ex)
        {
            throw new Exception($"Error in getting all Payment > {ex.Message}");
        }
        finally
        {
            cmd.Dispose();
        }
        if (reader != null && reader.HasRows == true)
        {
            var queryAbles = reader.Cast<IDataRecord>().AsQueryable();
            foreach (var record in queryAbles)
            {
                yield return reader.ToPayment();
            }
        }
        reader?.Close();
    }

    public static Payment GetOnePayment(SqlConnection con, int id)
    {
        SqlCommand cmd = new SqlCommand("spReadOnePayment", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pid", id);
        SqlDataReader? reader = null;
        try
        {
            reader = cmd.ExecuteReader();
        }
        catch (Exception ex)
        {
            throw new Exception($"Error in getting user with id, {id} > {ex.Message}");
        }
        finally
        {
            cmd.Dispose();
        }
        Payment? result = null;
        if (reader != null && reader.HasRows == true)
        {
            if (reader.Read() == true)
            {
                result = reader.ToPaymentAllData();
            }
        }
        reader?.Close();
        return result;
    }

    public static int AddPayment(SqlConnection con, Payment payment)
    {
        SqlCommand cmd = new SqlCommand("spInsertPayment", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pid", payment.PaymentID);
        cmd.Parameters.AddWithValue("@pdate", payment.PayDate);
        cmd.Parameters.AddWithValue("@paidamount", payment.PaidAmount);
        cmd.Parameters.AddWithValue("@cusid", payment.CustomerID);
        cmd.Parameters.AddWithValue("@cusname", payment.CustomerName);
        cmd.Parameters.AddWithValue("@cusinfo", payment.CustomerContactInfo);
        cmd.Parameters.AddWithValue("@stid", payment.StaffID);
        cmd.Parameters.AddWithValue("@stkh", payment.StaffNameKh);
        cmd.Parameters.AddWithValue("@stpos", payment.StaffPosition);
        try
        {
            int effected = cmd.ExecuteNonQuery();
            /*if (effected > 0) Added?.Invoke(null, new EntityEventArgs() { Id = student.Id, Entity = EntityTypes.Students });*/
            return effected > 0 ? payment.PaymentID : 0;
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed in adding new payment > {ex.Message}");

        }
        finally
        {
            cmd.Dispose();
        }

    }

    public static bool UpdatePayment(SqlConnection con, Payment payment)
    {
        SqlCommand cmd = new SqlCommand("spUpdatePayment", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pid", payment.PaymentID);
        cmd.Parameters.AddWithValue("@pdate", payment.PayDate);
        cmd.Parameters.AddWithValue("@paidamount", payment.PaidAmount);
        cmd.Parameters.AddWithValue("@cusid", payment.CustomerID);
        cmd.Parameters.AddWithValue("@cusname", payment.CustomerName);
        cmd.Parameters.AddWithValue("@cusinfo", payment.CustomerContactInfo);
        cmd.Parameters.AddWithValue("@stid", payment.StaffID);
        cmd.Parameters.AddWithValue("@stkh", payment.StaffNameKh);
        cmd.Parameters.AddWithValue("@stpos", payment.StaffPosition);
        try
        {
            int effected = cmd.ExecuteNonQuery();
            //if (effected > 0) Updated?.Invoke(null, new EntityEventArgs() { Id = student.Id, Entity = EntityTypes.Students });
            return (effected > 0);
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed in updating existing payment > {ex.Message}");
        }
        finally
        {
            cmd.Dispose();
        }
    }
}
