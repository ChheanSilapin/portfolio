﻿using Microsoft.Data.SqlClient;
using PAGTMS.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAGTMS.Ultils;

public static class BookingFunc
{
    public static IEnumerable<Booking> GetAllBooking(SqlConnection con)
    {
        SqlCommand cmd = new SqlCommand("spReadALLBooking", con);
        SqlDataReader? reader = null;
        try
        {
            reader = cmd.ExecuteReader();
        }
        catch (Exception ex)
        {
            throw new Exception($"Error in getting all Payment > {ex.Message}");
        }
        finally
        {
            cmd.Dispose();
        }
        if (reader != null && reader.HasRows == true)
        {
            var queryAbles = reader.Cast<IDataRecord>().AsQueryable();
            foreach (var record in queryAbles)
            {
                yield return reader.ToBookingAllData();
            }
        }
        reader?.Close();
    }

    public static Booking GetOneBooking(SqlConnection con, int id)
    {
        SqlCommand cmd = new SqlCommand("spReadOneBooking", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@bookingid", id);
        SqlDataReader? reader = null;
        try
        {
            reader = cmd.ExecuteReader();
        }
        catch (Exception ex)
        {
            throw new Exception($"Error in getting user with id, {id} > {ex.Message}");
        }
        finally
        {
            cmd.Dispose();
        }
        Booking? result = null;
        if (reader != null && reader.HasRows == true)
        {
            if (reader.Read() == true)
            {
                result = reader.ToBookingAllData();
            }
        }
        reader?.Close();
        return result;
    }
    public static int AddBooking(SqlConnection con, Booking booking)
    {
        SqlCommand cmd = new SqlCommand("spInsertBooking", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@bookingid", booking.BookingID);
        cmd.Parameters.AddWithValue("@bookingdate", booking.BookingDate);
        cmd.Parameters.AddWithValue("@totalpaid", booking.TotalPaid);
        cmd.Parameters.AddWithValue("@cusid", booking.CustomerID);
        cmd.Parameters.AddWithValue("@cusname", booking.CustomerName);
        cmd.Parameters.AddWithValue("@cusinfo", booking.CustomerContactInfo);
        cmd.Parameters.AddWithValue("@routeid", booking.RouteID);
        cmd.Parameters.AddWithValue("@des", booking.Destination);
        cmd.Parameters.AddWithValue("@vehicleid", booking.VehicleID);
        cmd.Parameters.AddWithValue("@vehicletype", booking.VehicleType);
        cmd.Parameters.AddWithValue("@vehiclestatus", booking.VehicleStatus);
        cmd.Parameters.AddWithValue("@stid", booking.StaffID);
        cmd.Parameters.AddWithValue("@stkh", booking.StaffNameKh);
        cmd.Parameters.AddWithValue("@stpos", booking.StaffPosition);
        try
        {
            int effected = cmd.ExecuteNonQuery();
            /*if (effected > 0) Added?.Invoke(null, new EntityEventArgs() { Id = student.Id, Entity = EntityTypes.Students });*/
            return effected > 0 ? booking.BookingID : 0;
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed in adding new payment > {ex.Message}");

        }
        finally
        {
            cmd.Dispose();
        }

    }
    public static bool UpdateBooking(SqlConnection con, Booking booking)
    {
        SqlCommand cmd = new SqlCommand("spUpdateBooking", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@bookingid", booking.BookingID);
        cmd.Parameters.AddWithValue("@bookingdate", booking.BookingDate);
        cmd.Parameters.AddWithValue("@totalpaid", booking.TotalPaid);
        cmd.Parameters.AddWithValue("@cusid", booking.CustomerID);
        cmd.Parameters.AddWithValue("@cusname", booking.CustomerName);
        cmd.Parameters.AddWithValue("@cusinfo", booking.CustomerContactInfo);
        cmd.Parameters.AddWithValue("@routeid", booking.RouteID);
        cmd.Parameters.AddWithValue("@des", booking.Destination);
        cmd.Parameters.AddWithValue("@vehicleid", booking.VehicleID);
        cmd.Parameters.AddWithValue("@vehicletype", booking.VehicleType);
        cmd.Parameters.AddWithValue("@vehiclestatus", booking.VehicleStatus);
        cmd.Parameters.AddWithValue("@stid", booking.StaffID);
        cmd.Parameters.AddWithValue("@stkh", booking.StaffNameKh);
        cmd.Parameters.AddWithValue("@stpos", booking.StaffPosition);
        try
        {
            int effected = cmd.ExecuteNonQuery();
            //if (effected > 0) Updated?.Invoke(null, new EntityEventArgs() { Id = student.Id, Entity = EntityTypes.Students });
            return (effected > 0);
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed in updating existing payment > {ex.Message}");
        }
        finally
        {
            cmd.Dispose();
        }
    }
}
