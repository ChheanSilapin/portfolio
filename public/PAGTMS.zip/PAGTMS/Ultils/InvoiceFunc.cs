﻿using Microsoft.Data.SqlClient;
using PAGTMS.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAGTMS.Ultils;

public static class InvoiceFunc
{
    public static IEnumerable<Invoice> GetAllInvoice(SqlConnection con)
    {
        SqlCommand cmd = new SqlCommand("spReadALLInvoice", con);
        SqlDataReader? reader = null;
        try
        {
            reader = cmd.ExecuteReader();
        }
        catch (Exception ex)
        {
            throw new Exception($"Error in getting all Invoice > {ex.Message}");
        }
        finally
        {
            cmd.Dispose();
        }
        if (reader != null && reader.HasRows == true)
        {
            var queryAbles = reader.Cast<IDataRecord>().AsQueryable();
            foreach (var record in queryAbles)
            {
                yield return reader.ToInvoice();
            }
        }
        reader?.Close();
    }

    public static Invoice GetOneInvoice(SqlConnection con, int id)
    {
        SqlCommand cmd = new SqlCommand("spReadOneInvoice", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@iid", id);
        SqlDataReader? reader = null;
        try
        {
            reader = cmd.ExecuteReader();
        }
        catch (Exception ex)
        {
            throw new Exception($"Error in getting user with id, {id} > {ex.Message}");
        }
        finally
        {
            cmd.Dispose();
        }
        Invoice? result = null;
        if (reader != null && reader.HasRows == true)
        {
            if (reader.Read() == true)
            {
                result = reader.ToInvoiceAllData();
            }
        }
        reader?.Close();
        return result;
    }
    public static int AddInvoice(SqlConnection con, Invoice invoice)
    {
        SqlCommand cmd = new SqlCommand("spInsertInvoice", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@iid", invoice.InvoiceID);
        cmd.Parameters.AddWithValue("@idate", invoice.InvoiceDate);
        cmd.Parameters.AddWithValue("@totalamount", invoice.TotalAmount);
        cmd.Parameters.AddWithValue("@paidamount", invoice.PaidAmount);
        cmd.Parameters.AddWithValue("@cusid", invoice.CustomerID);
        cmd.Parameters.AddWithValue("@cusname", invoice.CustomerName);
        cmd.Parameters.AddWithValue("@cusinfo", invoice.CustomerContactInfo);
        cmd.Parameters.AddWithValue("@stid", invoice.StaffID);
        cmd.Parameters.AddWithValue("@stkh", invoice.StaffNameKh);
        cmd.Parameters.AddWithValue("@stpos", invoice.StaffPosition);
        try
        {
            int effected = cmd.ExecuteNonQuery();
            /*if (effected > 0) Added?.Invoke(null, new EntityEventArgs() { Id = student.Id, Entity = EntityTypes.Students });*/
            return effected > 0 ? invoice.InvoiceID : 0;
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed in adding new payment > {ex.Message}");

        }
        finally
        {
            cmd.Dispose();
        }
    }

    public static bool UpdateInvoice(SqlConnection con, Invoice invoice)
    {
        SqlCommand cmd = new SqlCommand("spUpdateInvoice", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@iid", invoice.InvoiceID);
        cmd.Parameters.AddWithValue("@idate", invoice.InvoiceDate);
        cmd.Parameters.AddWithValue("@totalamount", invoice.TotalAmount);
        cmd.Parameters.AddWithValue("@paidamount", invoice.PaidAmount);
        cmd.Parameters.AddWithValue("@cusid", invoice.CustomerID);
        cmd.Parameters.AddWithValue("@cusname", invoice.CustomerName);
        cmd.Parameters.AddWithValue("@cusinfo", invoice.CustomerContactInfo);
        cmd.Parameters.AddWithValue("@stid", invoice.StaffID);
        cmd.Parameters.AddWithValue("@stkh", invoice.StaffNameKh);
        cmd.Parameters.AddWithValue("@stpos", invoice.StaffPosition);
        try
        {
            int effected = cmd.ExecuteNonQuery();
            //if (effected > 0) Updated?.Invoke(null, new EntityEventArgs() { Id = student.Id, Entity = EntityTypes.Students });
            return (effected > 0);
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed in updating existing payment > {ex.Message}");
        }
        finally
        {
            cmd.Dispose();
        }
    }
}
